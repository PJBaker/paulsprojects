//////////////////////////////////////////////////////////////////////////////////////////
//	Main.cpp
//	Direct3D Project Template
//	Downloaded from: www.paulsprojects.net
//	Created:	26th November 2002
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <D3DX8.h>
#include "Log/LOG.h"
#include "Timer/TIMER.h"
#include "Fps Counter/FPS_COUNTER.h"
#include "Window/WINDOW.h"
#include "Bitmap Font/BITMAP_FONT.h"
#include "Main.h"

//link to libraries
#pragma comment(lib, "winmm.lib")
#pragma comment(lib, "d3d8.lib")
#pragma comment(lib, "d3dx8.lib")

TIMER timer;
FPS_COUNTER fpsCounter;
BITMAP_FONT font;

//Main D3D interface
LPDIRECT3D8 d3d=NULL;

//D3D device
IDirect3DDevice8 * d3dDevice=NULL;

//Tetrahedron vertices
SIMPLE_VERTEX tetraVertices[6];

//Tetrahedron vertex buffer
IDirect3DVertexBuffer8 * tetraVB=NULL;

//Set up D3D
bool D3DInit()
{
	//Init window
	if(!WINDOW::Instance()->Init("Project Template", 640, 480, D3DFMT_A8R8G8B8, D3DFMT_X8R8G8B8,
								 D3DFMT_D24S8, false, &d3d, &d3dDevice))
	{
		return false;
	}
	
	//Check for caps


	//Init font
	if(!font.Init(d3dDevice))
		return false;

	//Enable z buffer
	d3dDevice->SetRenderState(D3DRS_ZENABLE, true);

	//Cull CW since using a RH coordinate system
	d3dDevice->SetRenderState(D3DRS_CULLMODE, D3DCULL_CW);

	//Disable Lighting
	d3dDevice->SetRenderState(D3DRS_LIGHTING, false);

	//Set up projection matrix
	D3DXMATRIX projectionMatrix;
	D3DXMatrixPerspectiveFovRH(	&projectionMatrix,
								D3DX_PI/4,
							(float)WINDOW::Instance()->width/(float)WINDOW::Instance()->height,
								1.0f,
								100.0f);
	d3dDevice->SetTransform(D3DTS_PROJECTION, &projectionMatrix);

	//Set up view matrix
	D3DXMATRIX viewMatrix;
	D3DXMatrixTranslation(&viewMatrix, 0.0f, 0.0f, -5.0f);
	d3dDevice->SetTransform(D3DTS_VIEW, &viewMatrix);

	return true;
}

//Set up variables
bool DemoInit()
{
	//Init vertices
	tetraVertices[0].color=D3DCOLOR_XRGB(255, 0, 0);
	tetraVertices[0].position=D3DXVECTOR3( 0.0f, 1.0f, 0.0f);

	tetraVertices[1].color=D3DCOLOR_XRGB(0, 255, 0);
	tetraVertices[1].position=D3DXVECTOR3( 1.0f,-1.0f, 1.0f);

	tetraVertices[2].color=D3DCOLOR_XRGB(0, 0, 255);
	tetraVertices[2].position=D3DXVECTOR3( 1.0f,-1.0f,-1.0f);

	tetraVertices[3].color=D3DCOLOR_XRGB(0, 255, 0);
	tetraVertices[3].position=D3DXVECTOR3(-1.0f,-1.0f,-1.0f);

	tetraVertices[4].color=D3DCOLOR_XRGB(0, 0, 255);
	tetraVertices[4].position=D3DXVECTOR3(-1.0f,-1.0f, 1.0f);

	tetraVertices[5].color=D3DCOLOR_XRGB(0, 255, 0);
	tetraVertices[5].position=D3DXVECTOR3( 1.0f,-1.0f, 1.0f);

	//Put these into the vertex buffer

	//Create the vertex buffer
	HRESULT hr;
	hr=d3dDevice->CreateVertexBuffer(	7*sizeof(SIMPLE_VERTEX),
										D3DUSAGE_WRITEONLY,
										SIMPLE_VERTEX_FVF,
										D3DPOOL_MANAGED,
										&tetraVB);
	if(FAILED(hr))
	{
		LOG::Instance()->OutputError("Unable to Create tetrahedron vertex buffer");
		return false;
	}

	//Lock the vertex buffer
	unsigned char * bytePtr;
	hr=tetraVB->Lock(0, 0, &bytePtr, 0);
	if(FAILED(hr))
	{
		LOG::Instance()->OutputError("Unable to lock vertex buffer");
		return false;
	}

	//Copy in the vertices
	memcpy(bytePtr, tetraVertices, 7*sizeof(SIMPLE_VERTEX));

	//Unlock vertex buffer
	tetraVB->Unlock();


	//reset timer
	timer.Reset();

	return true;
}

//Perform per-frame updates
void UpdateFrame()
{
	//set currentTime and timePassed
	static double lastTime=timer.GetTime();
	double currentTime=timer.GetTime();
	double timePassed=currentTime-lastTime;
	lastTime=currentTime;

	//Update window
	WINDOW::Instance()->Update();


	
	//Render frame
	RenderFrame(currentTime, timePassed);
}

//Render a frame
void RenderFrame(double currentTime, double timePassed)
{
	//Clear buffers
	d3dDevice->Clear(	0,
						NULL,
						D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER,	//which buffers to clear
						D3DCOLOR_XRGB(0, 0, 0),				//color to clear to
						1.0f, 0);							//depth & stencil values

	//Set world matrix for tetrahedron
	D3DXMATRIX worldMatrix;
	D3DXMatrixRotationY(&worldMatrix, (float)currentTime/600);
	d3dDevice->SetTransform(D3DTS_WORLD, &worldMatrix);


	//Draw scene
	if(SUCCEEDED(d3dDevice->BeginScene()))
	{
		//Set vertex shader (FVF)
		d3dDevice->SetVertexShader(SIMPLE_VERTEX_FVF);

		//Set stream source
		d3dDevice->SetStreamSource(0, tetraVB, sizeof(SIMPLE_VERTEX));

		//Draw tetrahedron
		d3dDevice->DrawPrimitive(D3DPT_TRIANGLEFAN, 0, 4);

		//End Drawing
		d3dDevice->EndScene();
	}

	fpsCounter.Update();

	//Print text
	if(SUCCEEDED(d3dDevice->BeginScene()))
	{
		font.StartTextMode();
		font.Print(0, 8, 0xFFFFFF00, "FPS: %.2f", fpsCounter.GetFps());
		font.EndTextMode();

		//End Drawing
		d3dDevice->EndScene();
	}


	//Swap buffers
	d3dDevice->Present(NULL, NULL, NULL, NULL);

	//Save a screenshot
	if(WINDOW::Instance()->IsKeyPressed(VK_F1))
	{
		WINDOW::Instance()->SaveScreenshot(d3dDevice);
		WINDOW::Instance()->SetKeyReleased(VK_F1);
	}

	//quit if necessary
	if(WINDOW::Instance()->IsKeyPressed(VK_ESCAPE))
		PostQuitMessage(0);
}

//Shut down demo
void DemoShutdown()
{
	if(tetraVB)
		tetraVB->Release();
	tetraVB=NULL;

	//Shut down D3D objects
	if(d3dDevice)
		d3dDevice->Release();
	d3dDevice=NULL;

	if(d3d)
		d3d->Release();
	d3d=NULL;

	font.Shutdown();
	WINDOW::Instance()->Shutdown();
}

//WinMain
int WINAPI WinMain(	HINSTANCE	hInstance,			//Instance
					HINSTANCE	hPrevInstance,		//Previous Instance
					LPSTR		lpCmdLine,			//Command line params
					int			nShowCmd)			//Window show state
{
	//Save hInstance
	WINDOW::Instance()->hInstance=hInstance;

	//Init D3D and variables
	if(!D3DInit())
	{
		LOG::Instance()->OutputError("Direct3D Initiation Failed");
		return false;
	}
	else
		LOG::Instance()->OutputSuccess("Direct3D Initiation Successful");

	if(!DemoInit())
	{
		LOG::Instance()->OutputError("Demo Initiation Failed");
		return false;
	}
	else
		LOG::Instance()->OutputSuccess("Demo Initiation Successful");

	//Main Loop
	for(;;)
	{
		if(!(WINDOW::Instance()->HandleMessages()))	//quit if HandleMessages returns false
			break;

		UpdateFrame();
	}

	//Shutdown
	DemoShutdown();

	//Exit program
	LOG::Instance()->OutputSuccess("Exiting...");
	return 0;
}
