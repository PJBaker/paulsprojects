**************************************************************************
**	Project Template
**
**	www.paulsprojects.net
**
**	paul@paulsprojects.net
**************************************************************************

Description:

This is a template project, which creates a Direct3D window containing a simple rotating tetrahedron. A dialog box will appear allowing you to select resolution, fullscreen etc. If supported, this dialog box will also allow you to select a degree of multisample antialiasing.

The template includes:

Bitmap Font    Font for on-screen drawing, using ID3DXFont
Fps Counter    Simple frames per second counter, using timeGetTime()
Log            Singleton error log class
Timer          Timer
Window         Singleton class which creates and destroys the window. This also handles input.


Requirements:

DirectX 8.1 Drivers. If you do not have them, visit www.microsoft.com/windows/directx/


References:

Window creation code is derived from that at www.drunkenhyena.com


Keys:

F1	-	Take a screenshot
Escape	-	Quit
