//	Metaballs II
//	www.paulsprojects.net
//
//	Copyright (c) 2008, Paul Baker
//	All rights reserved.
//
//	Redistribution and use in source and binary forms, with or without modification,
//	are permitted provided that the following conditions are met:
//
//	    * Redistributions of source code must retain the above copyright notice,
//	      this list of conditions and the following disclaimer.
//	    * Redistributions in binary form must reproduce the above copyright notice,
//	      this list of conditions and the following disclaimer in the documentation
//	      and/or other materials provided with the distribution.
//	    * Neither the name of paulsprojects.net nor the names of its contributors
//	      may be used to endorse or promote products derived from this software
//	      without specific prior written permission.
//
//	THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
//	ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
//	WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
//	DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
//	ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
//	(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
//	LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
//	ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
//	(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
//	SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;

using SlimDX;
using SlimDX.Direct3D;
using SlimDX.Direct3D9;

namespace Metaballs_II
{
    class Renderer : IDisposable
    {
		private float aspectRatio;

		private PresentParameters presentParams;
		private Device device;
		private bool deviceLost = false;

		private Mesh skySphere;

		private Metaball[] metaballs = new Metaball[3];
		private AABoundingBox boundingBox = new AABoundingBox();

		private CubeGrid[] cubeGrids = {new CubeGrid(), new CubeGrid()};
		private const float threshold = 1.0f;

		private CubeTexture cubeMap;

		private Effect skyEffect, metaballEffect;
#if PROFILE
		private Graph graph;
#endif
		public Renderer(int formWidth, int formHeight, IntPtr formHandle)
		{
			aspectRatio = (float)formWidth / formHeight;

			presentParams = new PresentParameters();
			presentParams.BackBufferWidth = formWidth;
			presentParams.BackBufferHeight = formHeight;
			presentParams.DeviceWindowHandle = formHandle;
			presentParams.Multisample = MultisampleType.FourSamples;
			presentParams.PresentationInterval = PresentInterval.Immediate;
			presentParams.SwapEffect = SwapEffect.Discard;
			presentParams.Windowed = true;

			device = new Device(0, DeviceType.Hardware, formHandle, CreateFlags.HardwareVertexProcessing, presentParams);
			SetDeviceState();
				
			skySphere = Mesh.CreateSphere(device, 10.0f, 24, 12);

			cubeMap = CubeTexture.FromFile(device, "CubeMap.dds");

			skyEffect = Effect.FromFile(device, "Sky.fx", null, null, ShaderFlags.None, null);
			metaballEffect = Effect.FromFile(device, "Metaball.fx", null, null, ShaderFlags.None, null);
#if PROFILE
			graph = new Graph(formWidth, formHeight);
#endif
		}

		/// <summary>
		/// Set the Direct3D device's state
		/// </summary>
		private void SetDeviceState()
		{
			device.SetSamplerState(0, SamplerState.MagFilter, TextureFilter.Linear);
			device.SetSamplerState(0, SamplerState.MinFilter, TextureFilter.Linear);
			device.SetSamplerState(0, SamplerState.MipFilter, TextureFilter.Linear);
#if PROFILE
			device.SetTextureStageState(0, TextureStage.ColorOperation, TextureOperation.Disable);
#endif
		}

		private bool disposed = false;

		public void Dispose()
		{
			Dispose(true);
		}

		protected virtual void Dispose(bool disposing)
		{
			if(!disposed)
			{
				if(disposing)
				{
					if(metaballEffect != null)	metaballEffect.Dispose();
					if(skyEffect != null)		skyEffect.Dispose();
					if(cubeMap != null)			cubeMap.Dispose();
					if(cubeGrids[0] != null)	cubeGrids[0].Dispose();
					if(cubeGrids[1] != null)	cubeGrids[1].Dispose();
					if(skySphere != null)		skySphere.Dispose();
					if(device != null)			device.Dispose();
				}

				disposed = true;
			}
		}

		/// <summary>
		/// Render a frame
		/// </summary>
		public void RenderFrame()
        {
#if PROFILE
			Program.profiler.BeginFrame();
#endif
			float time = Environment.TickCount;

			UpdateFrame(time);

			if(deviceLost)
			{
				AttemptDeviceRecovery();
			}

			if(!deviceLost)
			{
				Matrix worldMatrix = Matrix.RotationAxis(new Vector3(-1.0f, 0.0f, 1.0f), time * ((float)Math.PI / 180.0f) / 30.0f) * Matrix.RotationY(-0.9f);
				Matrix viewMatrix = Matrix.RotationY(0.9f) * Matrix.Translation(new Vector3(0.0f, 0.0f, 20.0f));
				
				const float fov = (float)Math.PI / 3;
				Matrix projectionMatrix = Matrix.PerspectiveFovLH(fov, aspectRatio, 1.0f, 100.0f);
				
				device.Clear( ClearFlags.Target | ClearFlags.ZBuffer, new ColorValue(0.0f, 0.0f, 0.0f).ToArgb(), 1.0f, 0 );
				device.BeginScene();

				RenderSky(viewMatrix, projectionMatrix);

				RenderMetaballs(worldMatrix, viewMatrix, projectionMatrix);
#if PROFILE
				device.SetPixelShader(null);

				graph.RenderBarGraph(device);
				graph.RenderLineGraph(device);
#endif
				device.EndScene();
		
				try
				{
					device.Present();
				}
				catch(DeviceLostException)
				{
					deviceLost = true;
	
					cubeGrids[0].ReleaseDefaultPoolResources();
					cubeGrids[1].ReleaseDefaultPoolResources();
				}
			}
#if PROFILE
			Program.profiler.EndFrame();

			graph.Update(	Program.profiler.FrameTime, Program.profiler.GetSectionTime("CalculateVertexValues"),
							Program.profiler.GetSectionTime("CalculateSurfaceVertices"));
#endif
        }

		private void UpdateFrame(float time)
		{
			Metaball[] previousMetaballs = metaballs;

			float offset = 2.0f * (float)Math.Cos(time / 600.0f);
			metaballs = new Metaball[]
			{
				new Metaball(new Vector3(-4.0f * (float)Math.Cos(time / 700.0f) - offset,
										 4.0f * (float)Math.Sin(time / 600.0f) - offset,
										 0.0f), 5.0f),
				new Metaball(new Vector3(5.0f * (float)Math.Sin(time / 400.0f) + offset,
										 5.0f * (float)Math.Cos(time / 400.0f) - offset,
										 0.0f), 6.0f),
				new Metaball(new Vector3(-5.0f * (float)Math.Cos(time / 400.0f) - 0.2f * (float)Math.Sin(time / 600.0f),
										 5.0f * (float)Math.Sin(time / 500.0f) - 0.2f * (float)Math.Sin(time / 400.0f),
										 0.0f), 7.0f)
			};

			boundingBox = new AABoundingBox(new Vector3(float.PositiveInfinity, float.PositiveInfinity, float.PositiveInfinity),
											new Vector3(float.NegativeInfinity, float.NegativeInfinity, float.NegativeInfinity));

			float maxRadius =
				(float)Math.Sqrt((metaballs[0].radiusSquared + metaballs[1].radiusSquared + metaballs[2].radiusSquared) / threshold);

			foreach(Metaball metaball in metaballs)
			{
				float radius = (float)Math.Sqrt(metaball.radiusSquared);

				boundingBox.min.X = Math.Min(boundingBox.min.X, metaball.position.X - maxRadius);
				boundingBox.min.Y = Math.Min(boundingBox.min.Y, metaball.position.Y - maxRadius);
				boundingBox.min.Z = Math.Min(boundingBox.min.Z, metaball.position.Z - maxRadius);

				boundingBox.max.X = Math.Max(boundingBox.max.X, metaball.position.X + maxRadius);
				boundingBox.max.Y = Math.Max(boundingBox.max.Y, metaball.position.Y + maxRadius);
				boundingBox.max.Z = Math.Max(boundingBox.max.Z, metaball.position.Z + maxRadius);
			}

			CubeGrid temp = cubeGrids[0];
			cubeGrids[0] = cubeGrids[1];
			cubeGrids[1] = temp;

			ManualResetEvent[] doneEvents = { new ManualResetEvent(false), new ManualResetEvent(false) };

			ThreadPool.QueueUserWorkItem(cubeGrids[0].CalculateVertexValues,
											new CubeGrid.CalculateVertexValuesStartData(metaballs, boundingBox, doneEvents[0]));
			ThreadPool.QueueUserWorkItem(cubeGrids[1].CalculateSurfaceVertices,
											new CubeGrid.CalculateSurfaceVerticesStartData(previousMetaballs, threshold, doneEvents[1]));

			doneEvents[0].WaitOne();
			doneEvents[1].WaitOne();
		}

		private void AttemptDeviceRecovery()
		{
			try
			{
				device.TestCooperativeLevel();
			}
			catch (DeviceLostException)
			{
			}
			catch (DeviceNotResetException)
			{
				try
				{
					device.Reset(presentParams);
					SetDeviceState();

					deviceLost = false;
				}
				catch (DeviceLostException)
				{
				}
			}
		}

		private void RenderSky(Matrix viewMatrix, Matrix projectionMatrix)
		{
			device.SetRenderState(RenderState.CullMode, Cull.Clockwise);
			device.SetRenderState(RenderState.ZEnable, false);

			skyEffect.SetValue("viewMatrix", viewMatrix);
			skyEffect.SetValue("projectionMatrix", projectionMatrix);
			skyEffect.SetValue("cubeMap", cubeMap);

			int numPasses = skyEffect.Begin(FX.DoNotSaveState);
			Debug.Assert(numPasses == 1);
			skyEffect.BeginPass(0);

			skySphere.DrawSubset(0);

			skyEffect.EndPass();
			skyEffect.End();
		}

		private void RenderMetaballs(Matrix worldMatrix, Matrix viewMatrix, Matrix projectionMatrix)
		{
			device.SetRenderState(RenderState.CullMode, Cull.CounterClockwise);
			device.SetRenderState(RenderState.ZEnable, true);

			metaballEffect.SetValue("worldView", worldMatrix * viewMatrix);
			metaballEffect.SetValue("worldViewIT", Matrix.Transpose(Matrix.Invert(worldMatrix * viewMatrix)));
			metaballEffect.SetValue("viewInverse", Matrix.Invert(viewMatrix));
			metaballEffect.SetValue("worldViewProjection", worldMatrix * viewMatrix * projectionMatrix);
			metaballEffect.SetValue("cubeMap", cubeMap);

			int numPasses = metaballEffect.Begin(FX.DoNotSaveState);
			Debug.Assert(numPasses == 1);
			metaballEffect.BeginPass(0);

			cubeGrids[1].RenderSurface(device);

			metaballEffect.EndPass();
			metaballEffect.End();
		}
    }
}