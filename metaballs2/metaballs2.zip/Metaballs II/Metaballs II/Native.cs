//	Metaballs II
//	www.paulsprojects.net
//
//	Copyright (c) 2008, Paul Baker
//	All rights reserved.
//
//	Redistribution and use in source and binary forms, with or without modification,
//	are permitted provided that the following conditions are met:
//
//	    * Redistributions of source code must retain the above copyright notice,
//	      this list of conditions and the following disclaimer.
//	    * Redistributions in binary form must reproduce the above copyright notice,
//	      this list of conditions and the following disclaimer in the documentation
//	      and/or other materials provided with the distribution.
//	    * Neither the name of paulsprojects.net nor the names of its contributors
//	      may be used to endorse or promote products derived from this software
//	      without specific prior written permission.
//
//	THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
//	ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
//	WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
//	DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
//	ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
//	(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
//	LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
//	ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
//	(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
//	SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

using System;
using System.Runtime.InteropServices;

namespace Metaballs_II
{
    class Native
    {
		[StructLayout(LayoutKind.Sequential)]
        public struct MSG
        {
            public IntPtr hWnd;
            public uint msg;
            public IntPtr wParam;
            public IntPtr lParam;
            public uint time;
            public System.Drawing.Point p;
        }

        [System.Security.SuppressUnmanagedCodeSecurity]
        [DllImport("User32.dll", CharSet = CharSet.Auto)]
        public static extern bool PeekMessage(out MSG msg, IntPtr hWnd, uint messageFilterMin,
                                              uint messageFilterMax, uint flags);

		public const uint PAGE_NOACCESS				= 0x01;
		public const uint PAGE_READONLY				= 0x02;
		public const uint PAGE_READWRITE			= 0x04;
		public const uint PAGE_WRITECOPY			= 0x08;
		public const uint PAGE_EXECUTE				= 0x10;
		public const uint PAGE_EXECUTE_READ			= 0x20;
		public const uint PAGE_EXECUTE_READWRITE	= 0x40;
		public const uint PAGE_EXECUTE_WRITECOPY	= 0x80;
		public const uint PAGE_GUARD				= 0x100;
		public const uint PAGE_NOCACHE				= 0x200;
		public const uint PAGE_WRITECOMBINE			= 0x400;
		public const uint MEM_COMMIT				= 0x1000;
		public const uint MEM_RESERVE				= 0x2000;
		public const uint MEM_DECOMMIT				= 0x4000;
		public const uint MEM_RELEASE				= 0x8000;
		public const uint MEM_FREE					= 0x10000;
		public const uint MEM_PRIVATE				= 0x20000;
		public const uint MEM_MAPPED				= 0x40000;
		public const uint MEM_RESET					= 0x80000;
		public const uint MEM_TOP_DOWN				= 0x100000;
		public const uint MEM_WRITE_WATCH			= 0x200000;
		public const uint MEM_PHYSICAL				= 0x400000;
		public const uint MEM_LARGE_PAGES			= 0x20000000;
		public const uint MEM_4MB_PAGES				= 0x80000000;

		[System.Security.SuppressUnmanagedCodeSecurity]
		[DllImport("kernel32.dll")]
		public static extern IntPtr VirtualAlloc(IntPtr lpAddress, UIntPtr dwSize, uint flAllocationType, uint flProtect);

		[System.Security.SuppressUnmanagedCodeSecurity]
		[DllImport("kernel32.dll")]
		public static extern bool VirtualFree(IntPtr lpAddress, UIntPtr dwSize, uint dwFreeType);
	}
}