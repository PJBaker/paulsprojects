//	Metaballs II
//	www.paulsprojects.net
//
//	Copyright (c) 2008, Paul Baker
//	All rights reserved.
//
//	Redistribution and use in source and binary forms, with or without modification,
//	are permitted provided that the following conditions are met:
//
//	    * Redistributions of source code must retain the above copyright notice,
//	      this list of conditions and the following disclaimer.
//	    * Redistributions in binary form must reproduce the above copyright notice,
//	      this list of conditions and the following disclaimer in the documentation
//	      and/or other materials provided with the distribution.
//	    * Neither the name of paulsprojects.net nor the names of its contributors
//	      may be used to endorse or promote products derived from this software
//	      without specific prior written permission.
//
//	THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
//	ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
//	WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
//	DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
//	ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
//	(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
//	LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
//	ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
//	(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
//	SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

using System;
using System.Collections.Generic;
using System.Diagnostics;

namespace Metaballs_II
{
#if PROFILE
	class Profiler
	{
		private readonly float ticksPerMs = Stopwatch.Frequency / 1000.0f;

		private Stopwatch frameStopwatch = new Stopwatch();
		private Dictionary<string, Stopwatch> sectionStopwatches = new Dictionary<string, Stopwatch>();

		/// <summary>
		/// Called to notify the profiler of the beginning of a frame
		/// </summary>
		public void BeginFrame()
		{
			Debug.Assert(!frameStopwatch.IsRunning);

			frameStopwatch.Reset();

			foreach(Stopwatch sectionStopwatch in sectionStopwatches.Values)
			{
				Debug.Assert(!sectionStopwatch.IsRunning);

				sectionStopwatch.Reset();
			}
			
			frameStopwatch.Start();
		}

		/// <summary>
		/// Called to notify the profiler of the end of a frame
		/// </summary>
		public void EndFrame()
		{
			Debug.Assert(frameStopwatch.IsRunning);

			frameStopwatch.Stop();
		}

		/// <summary>
		/// Called on entry to a profiled section
		/// </summary>
		/// <param name="name">The name of the section</param>
		public void BeginSection(string name)
		{
			lock(sectionStopwatches)
			{
				if(!sectionStopwatches.ContainsKey(name))
				{
					sectionStopwatches.Add(name, new Stopwatch());
				}

				Debug.Assert(!sectionStopwatches[name].IsRunning);

				sectionStopwatches[name].Start();
			}
		}

		/// <summary>
		/// Called on exiting a profiled section
		/// </summary>
		/// <param name="name">The name of the section</param>
		public void EndSection(string name)
		{
			lock(sectionStopwatches)
			{
				Debug.Assert(sectionStopwatches.ContainsKey(name));
				Debug.Assert(sectionStopwatches[name].IsRunning);

				sectionStopwatches[name].Stop();
			}
		}

		public float FrameTime
		{
			get
			{
				Debug.Assert(!frameStopwatch.IsRunning);

				return frameStopwatch.ElapsedTicks / ticksPerMs;
			}
		}

		/// <summary>
		/// Called to get the time spent in a given profiled section
		/// </summary>
		/// <param name="name">The name of the section</param>
		/// <returns>The time in milliseconds</returns>
		public float GetSectionTime(string name)
		{
			if(sectionStopwatches.ContainsKey(name))
			{
				Debug.Assert(!sectionStopwatches[name].IsRunning);

				return sectionStopwatches[name].ElapsedTicks / ticksPerMs;
			}

			return 0.0f;
		}
	}
#endif
}
