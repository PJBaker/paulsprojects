//	Metaballs II
//	www.paulsprojects.net
//
//	Copyright (c) 2008, Paul Baker
//	All rights reserved.
//
//	Redistribution and use in source and binary forms, with or without modification,
//	are permitted provided that the following conditions are met:
//
//	    * Redistributions of source code must retain the above copyright notice,
//	      this list of conditions and the following disclaimer.
//	    * Redistributions in binary form must reproduce the above copyright notice,
//	      this list of conditions and the following disclaimer in the documentation
//	      and/or other materials provided with the distribution.
//	    * Neither the name of paulsprojects.net nor the names of its contributors
//	      may be used to endorse or promote products derived from this software
//	      without specific prior written permission.
//
//	THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
//	ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
//	WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
//	DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
//	ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
//	(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
//	LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
//	ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
//	(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
//	SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

using System;
using System.Windows.Forms;

using SlimDX;
using SlimDX.Direct3D;
using SlimDX.Direct3D9;

namespace Metaballs_II
{
	static class Program
	{
		private static MainForm mainForm;
		private static Renderer renderer;

		private static FpsCounter fpsCounter = new FpsCounter();
		private static int fpsInTitle = 0;
#if PROFILE
		public static Profiler profiler = new Profiler();
#endif
		/// <summary>
		/// Application entry point
		/// </summary>
		[STAThread]
		public static void Main()
		{
#if !DEBUG
			try
#endif
			{
				Direct3D.Initialize();

				Application.EnableVisualStyles();
				Application.SetCompatibleTextRenderingDefault(false);

				using(mainForm = new MainForm())
				{
#if !DEBUG
					try
#endif
					{
						renderer = new Renderer(mainForm.ClientSize.Width, mainForm.ClientSize.Height, mainForm.Handle);
					}
#if !DEBUG
					catch(DirectXException ex)
					{
						string text = "DirectX \"" + ex.Message + "\" exception caught.";
						text += Environment.NewLine + Environment.NewLine;
						text += "Please ensure your system meets the requirements for running Metaballs II.";
						MessageBox.Show(text, ex.Message, MessageBoxButtons.OK, MessageBoxIcon.Error);

						return;
					}
#endif
					using(renderer)
					{
						Application.Idle += new EventHandler(ApplicationIdle);
						Application.Run(mainForm);
						Application.Idle -= new EventHandler(ApplicationIdle);
					}
				}

				Direct3D.Terminate();
			}
#if !DEBUG
			catch(DirectXException ex)
			{
				string text = "DirectX \"" + ex.Message + "\" exception caught.";
				text += Environment.NewLine + Environment.NewLine;
				text += "Metaballs II will now exit.";
				MessageBox.Show(text, ex.Message, MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
			catch
			{
				string text = "Unknown exception caught.";
				text += Environment.NewLine + Environment.NewLine;
				text += "Metaballs II will now exit.";
				MessageBox.Show(text, "Unknown exception", MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
#endif
		}

		/// <summary>
		/// Application idle loop
		/// </summary>
		private static void ApplicationIdle(object sender, EventArgs e)
        {
            while(ApplicationStillIdle)
            {
                renderer.RenderFrame();

				fpsCounter.FrameRendered();
				if(fpsCounter.Fps != fpsInTitle)
				{
					mainForm.Text = "Metaballs II - www.paulsprojects.net - " + fpsCounter.Fps.ToString() + " fps";
					fpsInTitle = fpsCounter.Fps;
				}
            }
        }

		/// <summary>
		/// Return whether or not to continue the idle loop
		/// </summary>
		private static bool ApplicationStillIdle
        {
            get
            {
                Native.MSG msg;
                return !Native.PeekMessage(out msg, IntPtr.Zero, 0, 0, 0);
            }
        }
	}
}