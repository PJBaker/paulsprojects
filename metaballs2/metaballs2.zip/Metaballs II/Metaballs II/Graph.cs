//	Metaballs II
//	www.paulsprojects.net
//
//	Copyright (c) 2008, Paul Baker
//	All rights reserved.
//
//	Redistribution and use in source and binary forms, with or without modification,
//	are permitted provided that the following conditions are met:
//
//	    * Redistributions of source code must retain the above copyright notice,
//	      this list of conditions and the following disclaimer.
//	    * Redistributions in binary form must reproduce the above copyright notice,
//	      this list of conditions and the following disclaimer in the documentation
//	      and/or other materials provided with the distribution.
//	    * Neither the name of paulsprojects.net nor the names of its contributors
//	      may be used to endorse or promote products derived from this software
//	      without specific prior written permission.
//
//	THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
//	ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
//	WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
//	DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
//	ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
//	(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
//	LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
//	ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
//	(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
//	SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

using System;
using System.Diagnostics;
using System.Runtime.InteropServices;

using SlimDX;
using SlimDX.Direct3D;
using SlimDX.Direct3D9;

namespace Metaballs_II
{
#if PROFILE
	class Graph
	{
		[StructLayout(LayoutKind.Sequential)]
		private struct GraphVertex
		{
			public Vector4 positionRhw;
			public uint diffuse;

			public static VertexFormat Format
			{
				get
				{
					return VertexFormat.PositionRhw | VertexFormat.Diffuse;
				}
			}
		}

		private readonly float windowWidth, windowHeight;

		private const int maxValues = 8;
		
		GraphVertex[][] barVertices = new GraphVertex[maxValues][];

		private const int numLineVertices = 256;
		GraphVertex[][] lineVertices = new GraphVertex[maxValues][];

		/// <summary>
		/// Constructor
		/// </summary>
		/// <param name="windowWidth_">The width of the window on which the graph will be rendered</param>
		/// <param name="windowHeight_">The height of the window on which the graph will be rendered</param>
		public Graph(float windowWidth_, float windowHeight_)
		{
			windowWidth = windowWidth_;
			windowHeight = windowHeight_;

			uint[] colors = new uint[maxValues]
				{0x00ff0000, 0x0000ff00, 0x000000ff, 0x00ffff00, 0x00ff00ff, 0x0000ffff, 0x00ffffff, 0x00000000};

			for(int i = 0; i < maxValues; ++i)
			{
				barVertices[i] = new GraphVertex[4];

				barVertices[i][0].positionRhw = new Vector4(12.0f, (i * 2 + 1) * 12.0f, 0.0f, 1.0f);
				barVertices[i][0].diffuse = colors[i];
				barVertices[i][1].positionRhw = new Vector4(12.0f, (i * 2 + 1) * 12.0f, 0.0f, 1.0f);
				barVertices[i][1].diffuse = colors[i];
				barVertices[i][2].positionRhw = new Vector4(12.0f, (i * 2 + 2) * 12.0f, 0.0f, 1.0f);
				barVertices[i][2].diffuse = colors[i];
				barVertices[i][3].positionRhw = new Vector4(12.0f, (i * 2 + 2) * 12.0f, 0.0f, 1.0f);
				barVertices[i][3].diffuse = colors[i];

				lineVertices[i] = new GraphVertex[numLineVertices];

				for(int j = 0; j < numLineVertices; ++j)
				{
					lineVertices[i][j].positionRhw = new Vector4(j * (windowWidth / numLineVertices) + 1.0f, windowHeight - 1.0f, 0.0f, 1.0f);
					lineVertices[i][j].diffuse = colors[i];
				}
			}
		}

		/// <summary>
		/// Update the graph
		/// </summary>
		/// <param name="values">The new data values</param>
		public void Update(params float[] values)
		{
			Debug.Assert(values.Length <= maxValues);

			for(int i = 0; i < values.Length; ++i)
			{
				barVertices[i][1].positionRhw.X = barVertices[i][2].positionRhw.X = values[i] * 5.0f + 12.0f;

				for(int j = 0; j < numLineVertices - 1; ++j)
				{
					lineVertices[i][j].positionRhw.Y = lineVertices[i][j + 1].positionRhw.Y;
				}

				lineVertices[i][numLineVertices - 1].positionRhw.Y = (windowHeight - 1.0f) - values[i] * 2.0f;
			}
		}

		/// <summary>
		/// Render a bar graph
		/// </summary>
		/// <param name="device">The Direct3D device to render with</param>
		public void RenderBarGraph(Device device)
		{
			device.VertexFormat = GraphVertex.Format;

			for(int i = 0; i < maxValues; ++i)
			{
				device.DrawUserPrimitives(PrimitiveType.TriangleFan, 0, 2, barVertices[i]);
			}
		}

		/// <summary>
		/// Render a line graph
		/// </summary>
		/// <param name="device">The Direct3D device to render with</param>
		public void RenderLineGraph(Device device)
		{
			device.VertexFormat = GraphVertex.Format;

			for(int i = 0; i < maxValues; ++i)
			{
				device.DrawUserPrimitives(PrimitiveType.LineStrip, 0, numLineVertices - 1, lineVertices[i]);
			}
		}
	}
#endif
}
