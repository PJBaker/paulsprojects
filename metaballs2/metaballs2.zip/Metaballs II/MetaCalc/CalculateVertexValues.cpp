//	Metaballs II
//	www.paulsprojects.net
//
//	Copyright (c) 2008, Paul Baker
//	All rights reserved.
//
//	Redistribution and use in source and binary forms, with or without modification,
//	are permitted provided that the following conditions are met:
//
//	    * Redistributions of source code must retain the above copyright notice,
//	      this list of conditions and the following disclaimer.
//	    * Redistributions in binary form must reproduce the above copyright notice,
//	      this list of conditions and the following disclaimer in the documentation
//	      and/or other materials provided with the distribution.
//	    * Neither the name of paulsprojects.net nor the names of its contributors
//	      may be used to endorse or promote products derived from this software
//	      without specific prior written permission.
//
//	THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
//	ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
//	WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
//	DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
//	ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
//	(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
//	LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
//	ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
//	(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
//	SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

#include <algorithm>
#include <omp.h>
#include <xmmintrin.h>
#include <boost/cstdint.hpp>

using boost::int32_t;

struct Vector3
{
	float x, y, z;
};

struct Metaball
{
	Vector3 position;
	float radiusSquared;
};

extern "C"
__declspec(dllexport)
void CalculateVertexValues(	int32_t numVerticesX, int32_t numVerticesY, int32_t numVerticesZ,
							const float * vertexXs, const float * vertexYs, const float * vertexZs,
							float * vertexValues, float * vertexNormalXs, float * vertexNormalYs, float * vertexNormalZs,
							int32_t numMetaballs, Metaball * metaballs,
							int32_t minCubeX, int32_t minCubeY, int32_t maxCubeX, int32_t maxCubeY)
{
	int32_t beginVertexX = std::max(minCubeX, 0L);
	int32_t endVertexX = std::min(maxCubeX + 2, numVerticesX);

	int32_t beginVertexY = std::max(minCubeY, 0L);
	int32_t endVertexY = std::min(maxCubeY + 2, numVerticesY);

#pragma omp parallel for
	for(int32_t i = beginVertexX; i < endVertexX; ++i)
	{
		{
			const Metaball & metaball = metaballs[0];

			__m128 ballPositionXs = _mm_load1_ps(&metaball.position.x);
			__m128 ballPositionYs = _mm_load1_ps(&metaball.position.y);
			__m128 ballPositionZs = _mm_load1_ps(&metaball.position.z);
			__m128 radiusSquareds = _mm_load1_ps(&metaball.radiusSquared);

			int32_t index = (i * numVerticesY + beginVertexY) * numVerticesZ;

			for(int32_t j = beginVertexY * numVerticesZ; j < endVertexY * numVerticesZ; j += 4)
			{
				__m128 ballToVertexXs = _mm_sub_ps(_mm_load_ps(&vertexXs[index]), ballPositionXs);
				__m128 ballToVertexYs = _mm_sub_ps(_mm_load_ps(&vertexYs[index]), ballPositionYs);
				__m128 ballToVertexZs = _mm_sub_ps(_mm_load_ps(&vertexZs[index]), ballPositionZs);

				__m128 ballToVertexX2s = _mm_mul_ps(ballToVertexXs, ballToVertexXs);
				__m128 ballToVertexY2s = _mm_mul_ps(ballToVertexYs, ballToVertexYs);
				__m128 ballToVertexZ2s = _mm_mul_ps(ballToVertexZs, ballToVertexZs);

				__m128 distanceSquareds = _mm_add_ps(_mm_add_ps(ballToVertexX2s, ballToVertexY2s), ballToVertexZ2s);

				__m128 normalScales = _mm_div_ps(radiusSquareds, _mm_mul_ps(distanceSquareds, distanceSquareds));

				__m128 values = _mm_mul_ps(normalScales, distanceSquareds);
				_mm_store_ps(&vertexValues[index], values);

				__m128 normalXs = _mm_mul_ps(ballToVertexXs, normalScales);
				_mm_store_ps(&vertexNormalXs[index], normalXs);

				__m128 normalYs = _mm_mul_ps(ballToVertexYs, normalScales);
				_mm_store_ps(&vertexNormalYs[index], normalYs);

				__m128 normalZs = _mm_mul_ps(ballToVertexZs, normalScales);
				_mm_store_ps(&vertexNormalZs[index], normalZs);

				index += 4;
			}
		}

		for(int32_t ball = 1; ball < numMetaballs; ++ball)
		{
			const Metaball & metaball = metaballs[ball];

			__m128 ballPositionXs = _mm_load1_ps(&metaball.position.x);
			__m128 ballPositionYs = _mm_load1_ps(&metaball.position.y);
			__m128 ballPositionZs = _mm_load1_ps(&metaball.position.z);
			__m128 radiusSquareds = _mm_load1_ps(&metaball.radiusSquared);

			int32_t index = (i * numVerticesY + beginVertexY) * numVerticesZ;

			for(int32_t j = beginVertexY * numVerticesZ; j < endVertexY * numVerticesZ; j += 4)
			{
				__m128 ballToVertexXs = _mm_sub_ps(_mm_load_ps(&vertexXs[index]), ballPositionXs);
				__m128 ballToVertexYs = _mm_sub_ps(_mm_load_ps(&vertexYs[index]), ballPositionYs);
				__m128 ballToVertexZs = _mm_sub_ps(_mm_load_ps(&vertexZs[index]), ballPositionZs);

				__m128 ballToVertexX2s = _mm_mul_ps(ballToVertexXs, ballToVertexXs);
				__m128 ballToVertexY2s = _mm_mul_ps(ballToVertexYs, ballToVertexYs);
				__m128 ballToVertexZ2s = _mm_mul_ps(ballToVertexZs, ballToVertexZs);

				__m128 distanceSquareds = _mm_add_ps(_mm_add_ps(ballToVertexX2s, ballToVertexY2s), ballToVertexZ2s);

				__m128 normalScales = _mm_div_ps(radiusSquareds, _mm_mul_ps(distanceSquareds, distanceSquareds));

				__m128 values = _mm_mul_ps(normalScales, distanceSquareds);
				_mm_store_ps(&vertexValues[index], _mm_add_ps(_mm_load_ps(&vertexValues[index]), values));

				__m128 normalXs = _mm_mul_ps(ballToVertexXs, normalScales);
				_mm_store_ps(&vertexNormalXs[index], _mm_add_ps(_mm_load_ps(&vertexNormalXs[index]), normalXs));

				__m128 normalYs = _mm_mul_ps(ballToVertexYs, normalScales);
				_mm_store_ps(&vertexNormalYs[index], _mm_add_ps(_mm_load_ps(&vertexNormalYs[index]), normalYs));

				__m128 normalZs = _mm_mul_ps(ballToVertexZs, normalScales);
				_mm_store_ps(&vertexNormalZs[index], _mm_add_ps(_mm_load_ps(&vertexNormalZs[index]), normalZs));

				index += 4;
			}
		}
	}
}