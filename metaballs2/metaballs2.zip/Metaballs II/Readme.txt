Metaballs II
============

www.paulsprojects.net
---------------------

Metaballs II renders "blobby objects" by using the "Marching Cubes" algorithm to extract an isosurface from a scalar field.

Compared to my old Metaballs demo (http://paulsprojects.net/opengl/metaballs/metaballs.html), Metaballs II features improved graphics and a 6x speed improvement.

The majority of the program is written in C#. The scene is rendered using Direct3D; including HLSL vertex and pixel shaders, through the managed wrappers provided by the SlimDX project (http://slimdx.mdxinfo.com).

The massive speed improvement over my previous work on Metaballs has been achieved through the use of improved algorithms and more advanced technologies, including OpenMP and SSE intrinsics.

For detailed information on the techniques used, see "technical.txt".

System Requirements
-------------------

Hardware support for:

Vertex shader 2.0
Pixel shader 2.0
4x Anti-aliasing

Software:

.NET framework 2.0
DirectX Runtime (November 2007)

Special Thanks
--------------

The SlimDX Group (http://slimdx.mdxinfo.com)
