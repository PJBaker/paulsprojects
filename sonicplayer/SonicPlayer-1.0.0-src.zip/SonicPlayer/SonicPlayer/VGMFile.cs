//	SonicPlayer
//	www.paulsprojects.net
//
//	Copyright (c) 2008, Paul Baker
//	All rights reserved.
//
//	Redistribution and use in source and binary forms, with or without modification,
//	are permitted provided that the following conditions are met:
//
//	    * Redistributions of source code must retain the above copyright notice,
//	      this list of conditions and the following disclaimer.
//	    * Redistributions in binary form must reproduce the above copyright notice,
//	      this list of conditions and the following disclaimer in the documentation
//	      and/or other materials provided with the distribution.
//	    * Neither the name of paulsprojects.net nor the names of its contributors
//	      may be used to endorse or promote products derived from this software
//	      without specific prior written permission.
//
//	THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
//	ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
//	WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
//	DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
//	ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
//	(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
//	LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
//	ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
//	(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
//	SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Text;

namespace VGM_Player
{
	class VGMFile
	{
		private List<byte> data = new List<byte>();
		private uint loopDataOffset;
		private uint readCursor = 0;

		private class DataBlock
		{
			public List<byte> data = new List<byte>();
			public uint readCursor = 0;
		}
		private Dictionary<byte, DataBlock> dataBlocks = new Dictionary<byte,DataBlock>();
		
		private VGMInfo info;
		public VGMInfo Info
		{
			get { return info; }
		}

		#region Chip properties

		private uint psgClock;
		public uint PSGClock
		{
			get { return psgClock; }
		}

		private ushort psgWhiteNoiseFeedback;
		public ushort PSGWhiteNoiseFeedback
		{
			get { return psgWhiteNoiseFeedback; }
		}

		private byte psgShiftRegisterWidth;
		public byte PSGShiftRegisterWidth
		{
			get { return psgShiftRegisterWidth; }
		}

		private uint ym2413Clock;
		public uint YM2413Clock
		{
			get { return ym2413Clock; }
		}

		private uint ym2612Clock;
		public uint YM2612Clock
		{
			get { return ym2612Clock; }
		}

		private uint ym2151Clock;
		public uint YM2151Clock
		{
			get { return ym2151Clock; }
		}

		#endregion

		private static List<byte> ReadEntireStream(Stream stream)
		{
			List<byte> buffer = new List<byte>();

			const int blockSize = 1024;
			byte[] tempBuffer = new byte[blockSize];

			int bytesRead;
			do
			{
				bytesRead = stream.Read(tempBuffer, 0, blockSize);

				for(int i = 0; i < bytesRead; ++i)
				{
					buffer.Add(tempBuffer[i]);
				}
			}
			while(bytesRead != 0);

			return buffer;
		}

		public VGMFile(string filename)
		{
			FileStream fileStream = new FileStream(filename, FileMode.Open, FileAccess.Read);
			GZipStream gzipStream = new GZipStream(fileStream, CompressionMode.Decompress);
			
			Stream stream;
			try
			{
				List<byte> buffer = ReadEntireStream(gzipStream);
				stream = new MemoryStream(buffer.ToArray());
			}
			catch(InvalidDataException)
			{
				fileStream.Seek(0, SeekOrigin.Begin);
				stream = fileStream;
			}

			uint dataOffset, gd3Offset;
			ReadHeader(stream, filename, out dataOffset, out gd3Offset);
			ReadData(stream, dataOffset);
			ReadGD3(stream, filename, gd3Offset);

			stream.Close();
			gzipStream.Close();
			fileStream.Close();
		}

		private void ReadHeader(Stream stream, string filename, out uint dataOffset, out uint gd3Offset)
		{
			stream.Seek(0, SeekOrigin.Begin);
			BinaryReader reader = new BinaryReader(stream);

			try
			{
				if(reader.ReadUInt32() != 0x206d6756)	//File ID
					throw new InvalidVGMFileException(filename);

				reader.ReadUInt32();					//EOF offset
				
				uint version = reader.ReadUInt32();

				psgClock = reader.ReadUInt32();
				ym2413Clock = reader.ReadUInt32();

				uint relativeGD3Offset = reader.ReadUInt32();
				gd3Offset = (relativeGD3Offset != 0) ? relativeGD3Offset + 0x14 : 0;

				uint numSamples = reader.ReadUInt32();

				uint relativeLoopDataOffset = reader.ReadUInt32();
				bool hasLoop = (relativeLoopDataOffset != 0);
				loopDataOffset = (relativeLoopDataOffset != 0) ? relativeLoopDataOffset + 0x1c : 0;

				uint numLoopSamples = reader.ReadUInt32();

				info = new VGMInfo(numSamples, hasLoop, numLoopSamples, version);

				if(info.majorVersion >= 1 && info.minorVersion >= 1)
				{
					reader.ReadUInt32();				//Rate
				}

				if(info.majorVersion >= 1 && info.minorVersion >= 10)
				{
					psgWhiteNoiseFeedback = reader.ReadUInt16();
					psgShiftRegisterWidth = reader.ReadByte();
					reader.ReadByte();	//Reserved

					ym2612Clock = reader.ReadUInt32();
					ym2151Clock = reader.ReadUInt32();
				}
				else
				{
					psgWhiteNoiseFeedback = 0x0009;
					psgShiftRegisterWidth = 16;

					ym2612Clock = 0;
					ym2151Clock = ym2413Clock;
				}

				if(info.majorVersion >= 1 && info.minorVersion >= 50)
				{
					uint relativeDataOffset = reader.ReadUInt32();
					dataOffset = (relativeDataOffset != 0) ? relativeDataOffset + 0x34 : 0x40;
				}
				else
				{
					dataOffset = 0x40;
				}

				loopDataOffset -= dataOffset;
			}
			catch(EndOfStreamException)
			{
				throw new InvalidVGMFileException(filename);
			}
		}

		private void ReadData(Stream stream, uint dataOffset)
		{
			stream.Seek(dataOffset, SeekOrigin.Begin);
			BinaryReader reader = new BinaryReader(stream);

			try
			{
				for(;;)
				{
					byte command = reader.ReadByte();
					
					if(command == 0x67)
					{
						reader.ReadByte();	//0x66
						byte dataType = reader.ReadByte();
						
						if(!dataBlocks.ContainsKey(dataType))
						{
							dataBlocks.Add(dataType, new DataBlock());
						}

						uint length = reader.ReadUInt32();
						
						for(uint i = 0; i < length; ++i)
						{
							dataBlocks[dataType].data.Add(reader.ReadByte());
						}

						if(loopDataOffset > data.Count)
						{
							loopDataOffset -= 7 + length;
						}
					}
					else
					{
						data.Add(command);

						if(command == 0x66)
							break;

						for(uint i = 0; i < numOperandsTable[command]; ++i)
							data.Add(reader.ReadByte());
					}
				}
			}
			catch(EndOfStreamException)
			{
			}
		}

		private void ReadGD3(Stream stream, string filename, uint gd3Offset)
		{
			if(gd3Offset != 0)
			{
				stream.Seek(gd3Offset, SeekOrigin.Begin);
				BinaryReader reader = new BinaryReader(stream, Encoding.Unicode);

				try
				{
					if(reader.ReadUInt32() != 0x20336447)	//GD3 ID
						throw new InvalidVGMFileException(filename);

					reader.ReadUInt32();					//GD3 Version
					reader.ReadUInt32();					//GD3 Length

					info.title = ReadGD3String(reader);
					ReadGD3String(reader);					//Japanese title

					info.game = ReadGD3String(reader);
					ReadGD3String(reader);					//Japanese game

					info.system = ReadGD3String(reader);
					ReadGD3String(reader);					//Japanese system

					info.author = ReadGD3String(reader);
					ReadGD3String(reader);					//Japanese author

					info.date = ReadGD3String(reader);
					info.creator = ReadGD3String(reader);
					info.notes = ReadGD3String(reader);
				}
				catch(EndOfStreamException)
				{
				}
			}
			else
			{
				info.title = "Untitled";
			}
		}

		private string ReadGD3String(BinaryReader reader)
		{
			StringBuilder builder = new StringBuilder();

			for(;;)
			{
				char character = reader.ReadChar();

				if(character == '\0')
					break;

				builder.Append(character);
			}

			return builder.ToString();
		}

		public void ResetReadCursorToStart()
		{
			readCursor = 0;
		}

		public void ResetReadCursorToLoopPoint()
		{
			readCursor = loopDataOffset;
		}

		public byte GetNextByte()
		{
			if(readCursor < data.Count)
			{
				return data[(int)(readCursor++)];
			}

			return 0x66;	//End of sound data
		}

		public void SetDataBlockCursorPosition(byte dataType, uint position)
		{
			dataBlocks[dataType].readCursor = position;
		}

		public byte GetNextDataBlockByte(byte dataType)
		{
			if(dataBlocks[dataType].readCursor < dataBlocks[dataType].data.Count)
			{
				return dataBlocks[dataType].data[(int)(dataBlocks[dataType].readCursor++)];
			}

			return 0x00;
		}

		public class InvalidVGMFileException : Exception
		{
			public InvalidVGMFileException(string filename_)
			{
				filename = filename_;
			}

			private string filename;
			public string Filename
			{
				get { return filename; }
			}
		}

		#region Lookup tables

		private readonly byte[] numOperandsTable = new byte[256]
			{
				0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
				0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
				0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
				1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
				1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
				1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
				0, 2, 0 ,0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
				0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
				0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
				0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
				2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
				2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
				3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3,
				3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3,
				4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4,
				4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4
			};

		#endregion
	}
}