//	SonicPlayer
//	www.paulsprojects.net
//
//	Copyright (c) 2008, Paul Baker
//	All rights reserved.
//
//	Redistribution and use in source and binary forms, with or without modification,
//	are permitted provided that the following conditions are met:
//
//	    * Redistributions of source code must retain the above copyright notice,
//	      this list of conditions and the following disclaimer.
//	    * Redistributions in binary form must reproduce the above copyright notice,
//	      this list of conditions and the following disclaimer in the documentation
//	      and/or other materials provided with the distribution.
//	    * Neither the name of paulsprojects.net nor the names of its contributors
//	      may be used to endorse or promote products derived from this software
//	      without specific prior written permission.
//
//	THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
//	ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
//	WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
//	DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
//	ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
//	(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
//	LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
//	ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
//	(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
//	SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

namespace VGM_Player
{
	partial class MainForm
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
			this.titleLabel = new System.Windows.Forms.Label();
			this.timeLabel = new System.Windows.Forms.Label();
			this.tabControl1 = new System.Windows.Forms.TabControl();
			this.tabPage1 = new System.Windows.Forms.TabPage();
			this.playlist = new System.Windows.Forms.ListView();
			this.columnHeader1 = new System.Windows.Forms.ColumnHeader();
			this.columnHeader2 = new System.Windows.Forms.ColumnHeader();
			this.tabPage3 = new System.Windows.Forms.TabPage();
			this.trackInfoList = new System.Windows.Forms.ListBox();
			this.tabPage2 = new System.Windows.Forms.TabPage();
			this.groupBox2 = new System.Windows.Forms.GroupBox();
			this.ym2151EnableBox = new System.Windows.Forms.CheckBox();
			this.ym2612EnableBox = new System.Windows.Forms.CheckBox();
			this.ym2413EnableBox = new System.Windows.Forms.CheckBox();
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.psgChannel3EnableBox = new System.Windows.Forms.CheckBox();
			this.psgChannel2EnableBox = new System.Windows.Forms.CheckBox();
			this.psgChannel1EnableBox = new System.Windows.Forms.CheckBox();
			this.psgChannel0EnableBox = new System.Windows.Forms.CheckBox();
			this.timeBar = new System.Windows.Forms.TrackBar();
			this.toolStrip1 = new System.Windows.Forms.ToolStrip();
			this.openButton = new System.Windows.Forms.ToolStripButton();
			this.previousButton = new System.Windows.Forms.ToolStripButton();
			this.playButton = new System.Windows.Forms.ToolStripButton();
			this.stopButton = new System.Windows.Forms.ToolStripButton();
			this.nextButton = new System.Windows.Forms.ToolStripButton();
			this.loopButton = new System.Windows.Forms.ToolStripButton();
			this.helpButton = new System.Windows.Forms.ToolStripButton();
			this.volumeBar = new System.Windows.Forms.TrackBar();
			this.openFileDialog = new System.Windows.Forms.OpenFileDialog();
			this.volumePictureBox = new System.Windows.Forms.PictureBox();
			this.tabControl1.SuspendLayout();
			this.tabPage1.SuspendLayout();
			this.tabPage3.SuspendLayout();
			this.tabPage2.SuspendLayout();
			this.groupBox2.SuspendLayout();
			this.groupBox1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.timeBar)).BeginInit();
			this.toolStrip1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.volumeBar)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.volumePictureBox)).BeginInit();
			this.SuspendLayout();
			// 
			// titleLabel
			// 
			this.titleLabel.AutoSize = true;
			this.titleLabel.Location = new System.Drawing.Point(12, 9);
			this.titleLabel.MaximumSize = new System.Drawing.Size(266, 13);
			this.titleLabel.Name = "titleLabel";
			this.titleLabel.Size = new System.Drawing.Size(0, 13);
			this.titleLabel.TabIndex = 0;
			this.titleLabel.UseMnemonic = false;
			// 
			// timeLabel
			// 
			this.timeLabel.AutoSize = true;
			this.timeLabel.Location = new System.Drawing.Point(278, 9);
			this.timeLabel.Name = "timeLabel";
			this.timeLabel.Size = new System.Drawing.Size(0, 13);
			this.timeLabel.TabIndex = 1;
			this.timeLabel.UseMnemonic = false;
			// 
			// tabControl1
			// 
			this.tabControl1.Controls.Add(this.tabPage1);
			this.tabControl1.Controls.Add(this.tabPage3);
			this.tabControl1.Controls.Add(this.tabPage2);
			this.tabControl1.Location = new System.Drawing.Point(12, 81);
			this.tabControl1.Name = "tabControl1";
			this.tabControl1.SelectedIndex = 0;
			this.tabControl1.Size = new System.Drawing.Size(266, 153);
			this.tabControl1.TabIndex = 3;
			// 
			// tabPage1
			// 
			this.tabPage1.Controls.Add(this.playlist);
			this.tabPage1.Location = new System.Drawing.Point(4, 22);
			this.tabPage1.Name = "tabPage1";
			this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
			this.tabPage1.Size = new System.Drawing.Size(258, 127);
			this.tabPage1.TabIndex = 0;
			this.tabPage1.Text = "Playlist";
			this.tabPage1.UseVisualStyleBackColor = true;
			// 
			// playlist
			// 
			this.playlist.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2});
			this.playlist.FullRowSelect = true;
			this.playlist.Location = new System.Drawing.Point(3, 3);
			this.playlist.Margin = new System.Windows.Forms.Padding(0);
			this.playlist.MultiSelect = false;
			this.playlist.Name = "playlist";
			this.playlist.Size = new System.Drawing.Size(252, 121);
			this.playlist.TabIndex = 0;
			this.playlist.UseCompatibleStateImageBehavior = false;
			this.playlist.View = System.Windows.Forms.View.Details;
			this.playlist.ItemActivate += new System.EventHandler(this.playlist_ItemActivate);
			// 
			// columnHeader1
			// 
			this.columnHeader1.Text = "Title";
			this.columnHeader1.Width = 186;
			// 
			// columnHeader2
			// 
			this.columnHeader2.Text = "Length";
			this.columnHeader2.Width = 45;
			// 
			// tabPage3
			// 
			this.tabPage3.Controls.Add(this.trackInfoList);
			this.tabPage3.Location = new System.Drawing.Point(4, 22);
			this.tabPage3.Name = "tabPage3";
			this.tabPage3.Size = new System.Drawing.Size(258, 127);
			this.tabPage3.TabIndex = 2;
			this.tabPage3.Text = "Track Information";
			this.tabPage3.UseVisualStyleBackColor = true;
			// 
			// trackInfoList
			// 
			this.trackInfoList.FormattingEnabled = true;
			this.trackInfoList.HorizontalScrollbar = true;
			this.trackInfoList.Location = new System.Drawing.Point(3, 3);
			this.trackInfoList.Name = "trackInfoList";
			this.trackInfoList.SelectionMode = System.Windows.Forms.SelectionMode.None;
			this.trackInfoList.Size = new System.Drawing.Size(252, 121);
			this.trackInfoList.TabIndex = 0;
			// 
			// tabPage2
			// 
			this.tabPage2.Controls.Add(this.groupBox2);
			this.tabPage2.Controls.Add(this.groupBox1);
			this.tabPage2.Location = new System.Drawing.Point(4, 22);
			this.tabPage2.Name = "tabPage2";
			this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
			this.tabPage2.Size = new System.Drawing.Size(258, 127);
			this.tabPage2.TabIndex = 1;
			this.tabPage2.Text = "Options";
			this.tabPage2.UseVisualStyleBackColor = true;
			// 
			// groupBox2
			// 
			this.groupBox2.Controls.Add(this.ym2151EnableBox);
			this.groupBox2.Controls.Add(this.ym2612EnableBox);
			this.groupBox2.Controls.Add(this.ym2413EnableBox);
			this.groupBox2.Location = new System.Drawing.Point(132, 8);
			this.groupBox2.Name = "groupBox2";
			this.groupBox2.Size = new System.Drawing.Size(120, 89);
			this.groupBox2.TabIndex = 1;
			this.groupBox2.TabStop = false;
			this.groupBox2.Text = "FM";
			// 
			// ym2151EnableBox
			// 
			this.ym2151EnableBox.AutoSize = true;
			this.ym2151EnableBox.Checked = true;
			this.ym2151EnableBox.CheckState = System.Windows.Forms.CheckState.Checked;
			this.ym2151EnableBox.Location = new System.Drawing.Point(6, 65);
			this.ym2151EnableBox.Name = "ym2151EnableBox";
			this.ym2151EnableBox.Size = new System.Drawing.Size(66, 17);
			this.ym2151EnableBox.TabIndex = 6;
			this.ym2151EnableBox.Text = "YM2151";
			this.ym2151EnableBox.UseVisualStyleBackColor = true;
			this.ym2151EnableBox.CheckedChanged += new System.EventHandler(this.ym2151EnableBox_CheckedChanged);
			// 
			// ym2612EnableBox
			// 
			this.ym2612EnableBox.AutoSize = true;
			this.ym2612EnableBox.Checked = true;
			this.ym2612EnableBox.CheckState = System.Windows.Forms.CheckState.Checked;
			this.ym2612EnableBox.Location = new System.Drawing.Point(6, 42);
			this.ym2612EnableBox.Name = "ym2612EnableBox";
			this.ym2612EnableBox.Size = new System.Drawing.Size(66, 17);
			this.ym2612EnableBox.TabIndex = 5;
			this.ym2612EnableBox.Text = "YM2612";
			this.ym2612EnableBox.UseVisualStyleBackColor = true;
			this.ym2612EnableBox.CheckedChanged += new System.EventHandler(this.ym2612EnableBox_CheckedChanged);
			// 
			// ym2413EnableBox
			// 
			this.ym2413EnableBox.AutoSize = true;
			this.ym2413EnableBox.Checked = true;
			this.ym2413EnableBox.CheckState = System.Windows.Forms.CheckState.Checked;
			this.ym2413EnableBox.Location = new System.Drawing.Point(6, 19);
			this.ym2413EnableBox.Name = "ym2413EnableBox";
			this.ym2413EnableBox.Size = new System.Drawing.Size(66, 17);
			this.ym2413EnableBox.TabIndex = 4;
			this.ym2413EnableBox.Text = "YM2413";
			this.ym2413EnableBox.UseVisualStyleBackColor = true;
			this.ym2413EnableBox.CheckedChanged += new System.EventHandler(this.ym2413EnableBox_CheckedChanged);
			// 
			// groupBox1
			// 
			this.groupBox1.Controls.Add(this.psgChannel3EnableBox);
			this.groupBox1.Controls.Add(this.psgChannel2EnableBox);
			this.groupBox1.Controls.Add(this.psgChannel1EnableBox);
			this.groupBox1.Controls.Add(this.psgChannel0EnableBox);
			this.groupBox1.Location = new System.Drawing.Point(6, 8);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new System.Drawing.Size(120, 111);
			this.groupBox1.TabIndex = 0;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = "PSG";
			// 
			// psgChannel3EnableBox
			// 
			this.psgChannel3EnableBox.AutoSize = true;
			this.psgChannel3EnableBox.Checked = true;
			this.psgChannel3EnableBox.CheckState = System.Windows.Forms.CheckState.Checked;
			this.psgChannel3EnableBox.Location = new System.Drawing.Point(6, 88);
			this.psgChannel3EnableBox.Name = "psgChannel3EnableBox";
			this.psgChannel3EnableBox.Size = new System.Drawing.Size(110, 17);
			this.psgChannel3EnableBox.TabIndex = 3;
			this.psgChannel3EnableBox.Text = "Channel 3 (Noise)";
			this.psgChannel3EnableBox.UseVisualStyleBackColor = true;
			this.psgChannel3EnableBox.CheckedChanged += new System.EventHandler(this.psgChannel3EnableBox_CheckedChanged);
			// 
			// psgChannel2EnableBox
			// 
			this.psgChannel2EnableBox.AutoSize = true;
			this.psgChannel2EnableBox.Checked = true;
			this.psgChannel2EnableBox.CheckState = System.Windows.Forms.CheckState.Checked;
			this.psgChannel2EnableBox.Location = new System.Drawing.Point(6, 65);
			this.psgChannel2EnableBox.Name = "psgChannel2EnableBox";
			this.psgChannel2EnableBox.Size = new System.Drawing.Size(108, 17);
			this.psgChannel2EnableBox.TabIndex = 2;
			this.psgChannel2EnableBox.Text = "Channel 2 (Tone)";
			this.psgChannel2EnableBox.UseVisualStyleBackColor = true;
			this.psgChannel2EnableBox.CheckedChanged += new System.EventHandler(this.psgChannel2EnableBox_CheckedChanged);
			// 
			// psgChannel1EnableBox
			// 
			this.psgChannel1EnableBox.AutoSize = true;
			this.psgChannel1EnableBox.Checked = true;
			this.psgChannel1EnableBox.CheckState = System.Windows.Forms.CheckState.Checked;
			this.psgChannel1EnableBox.Location = new System.Drawing.Point(6, 42);
			this.psgChannel1EnableBox.Name = "psgChannel1EnableBox";
			this.psgChannel1EnableBox.Size = new System.Drawing.Size(108, 17);
			this.psgChannel1EnableBox.TabIndex = 1;
			this.psgChannel1EnableBox.Text = "Channel 1 (Tone)";
			this.psgChannel1EnableBox.UseVisualStyleBackColor = true;
			this.psgChannel1EnableBox.CheckedChanged += new System.EventHandler(this.psgChannel1EnableBox_CheckedChanged);
			// 
			// psgChannel0EnableBox
			// 
			this.psgChannel0EnableBox.AutoSize = true;
			this.psgChannel0EnableBox.Checked = true;
			this.psgChannel0EnableBox.CheckState = System.Windows.Forms.CheckState.Checked;
			this.psgChannel0EnableBox.Location = new System.Drawing.Point(6, 19);
			this.psgChannel0EnableBox.Name = "psgChannel0EnableBox";
			this.psgChannel0EnableBox.Size = new System.Drawing.Size(108, 17);
			this.psgChannel0EnableBox.TabIndex = 0;
			this.psgChannel0EnableBox.Text = "Channel 0 (Tone)";
			this.psgChannel0EnableBox.UseVisualStyleBackColor = true;
			this.psgChannel0EnableBox.CheckedChanged += new System.EventHandler(this.psgChannel0EnableBox_CheckedChanged);
			// 
			// timeBar
			// 
			this.timeBar.LargeChange = 50;
			this.timeBar.Location = new System.Drawing.Point(9, 25);
			this.timeBar.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
			this.timeBar.Maximum = 1000;
			this.timeBar.Name = "timeBar";
			this.timeBar.Size = new System.Drawing.Size(272, 45);
			this.timeBar.TabIndex = 1;
			this.timeBar.TickStyle = System.Windows.Forms.TickStyle.None;
			this.timeBar.MouseDown += new System.Windows.Forms.MouseEventHandler(this.timeBar_MouseDown);
			this.timeBar.MouseUp += new System.Windows.Forms.MouseEventHandler(this.timeBar_MouseUp);
			// 
			// toolStrip1
			// 
			this.toolStrip1.Dock = System.Windows.Forms.DockStyle.None;
			this.toolStrip1.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
			this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.openButton,
            this.previousButton,
            this.playButton,
            this.stopButton,
            this.nextButton,
            this.loopButton,
            this.helpButton});
			this.toolStrip1.Location = new System.Drawing.Point(12, 53);
			this.toolStrip1.Name = "toolStrip1";
			this.toolStrip1.RenderMode = System.Windows.Forms.ToolStripRenderMode.System;
			this.toolStrip1.Size = new System.Drawing.Size(164, 25);
			this.toolStrip1.TabIndex = 0;
			this.toolStrip1.TabStop = true;
			this.toolStrip1.Text = "toolStrip1";
			// 
			// openButton
			// 
			this.openButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.openButton.Image = ((System.Drawing.Image)(resources.GetObject("openButton.Image")));
			this.openButton.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.openButton.Name = "openButton";
			this.openButton.Size = new System.Drawing.Size(23, 22);
			this.openButton.Text = "toolStripButton1";
			this.openButton.ToolTipText = "Open";
			this.openButton.Click += new System.EventHandler(this.openButton_Click);
			// 
			// previousButton
			// 
			this.previousButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.previousButton.Image = ((System.Drawing.Image)(resources.GetObject("previousButton.Image")));
			this.previousButton.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.previousButton.Name = "previousButton";
			this.previousButton.Size = new System.Drawing.Size(23, 22);
			this.previousButton.Text = "toolStripButton2";
			this.previousButton.ToolTipText = "Previous Track";
			this.previousButton.Click += new System.EventHandler(this.previousButton_Click);
			// 
			// playButton
			// 
			this.playButton.CheckOnClick = true;
			this.playButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.playButton.Image = ((System.Drawing.Image)(resources.GetObject("playButton.Image")));
			this.playButton.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.playButton.Name = "playButton";
			this.playButton.Size = new System.Drawing.Size(23, 22);
			this.playButton.Text = "toolStripButton3";
			this.playButton.ToolTipText = "Play";
			this.playButton.Click += new System.EventHandler(this.playButton_Click);
			// 
			// stopButton
			// 
			this.stopButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.stopButton.Image = ((System.Drawing.Image)(resources.GetObject("stopButton.Image")));
			this.stopButton.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.stopButton.Name = "stopButton";
			this.stopButton.Size = new System.Drawing.Size(23, 22);
			this.stopButton.Text = "toolStripButton4";
			this.stopButton.ToolTipText = "Stop";
			this.stopButton.Click += new System.EventHandler(this.stopButton_Click);
			// 
			// nextButton
			// 
			this.nextButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.nextButton.Image = ((System.Drawing.Image)(resources.GetObject("nextButton.Image")));
			this.nextButton.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.nextButton.Name = "nextButton";
			this.nextButton.Size = new System.Drawing.Size(23, 22);
			this.nextButton.Text = "toolStripButton5";
			this.nextButton.ToolTipText = "Next Track";
			this.nextButton.Click += new System.EventHandler(this.nextButton_Click);
			// 
			// loopButton
			// 
			this.loopButton.CheckOnClick = true;
			this.loopButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.loopButton.Image = ((System.Drawing.Image)(resources.GetObject("loopButton.Image")));
			this.loopButton.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.loopButton.Name = "loopButton";
			this.loopButton.Size = new System.Drawing.Size(23, 22);
			this.loopButton.Text = "toolStripButton6";
			this.loopButton.ToolTipText = "Loop";
			this.loopButton.Click += new System.EventHandler(this.loopButton_Click);
			// 
			// helpButton
			// 
			this.helpButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.helpButton.Image = ((System.Drawing.Image)(resources.GetObject("helpButton.Image")));
			this.helpButton.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.helpButton.Name = "helpButton";
			this.helpButton.Size = new System.Drawing.Size(23, 22);
			this.helpButton.Text = "toolStripButton1";
			this.helpButton.ToolTipText = "About SonicPlayer";
			this.helpButton.Click += new System.EventHandler(this.helpButton_Click);
			// 
			// volumeBar
			// 
			this.volumeBar.LargeChange = 10;
			this.volumeBar.Location = new System.Drawing.Point(176, 53);
			this.volumeBar.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
			this.volumeBar.Maximum = 100;
			this.volumeBar.Name = "volumeBar";
			this.volumeBar.Size = new System.Drawing.Size(83, 45);
			this.volumeBar.TabIndex = 2;
			this.volumeBar.TickStyle = System.Windows.Forms.TickStyle.None;
			this.volumeBar.Value = 100;
			this.volumeBar.Scroll += new System.EventHandler(this.volumeBar_Scroll);
			// 
			// openFileDialog
			// 
			this.openFileDialog.Filter = "VGM Files (*.vgm; *.vgz; *.m3u)|*.vgm;*.vgz;*.m3u|All Files|*.*";
			this.openFileDialog.Multiselect = true;
			this.openFileDialog.Title = "Open";
			// 
			// volumePictureBox
			// 
			this.volumePictureBox.Image = ((System.Drawing.Image)(resources.GetObject("volumePictureBox.Image")));
			this.volumePictureBox.Location = new System.Drawing.Point(262, 57);
			this.volumePictureBox.Name = "volumePictureBox";
			this.volumePictureBox.Size = new System.Drawing.Size(16, 16);
			this.volumePictureBox.TabIndex = 1;
			this.volumePictureBox.TabStop = false;
			// 
			// MainForm
			// 
			this.AllowDrop = true;
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(290, 246);
			this.Controls.Add(this.volumePictureBox);
			this.Controls.Add(this.toolStrip1);
			this.Controls.Add(this.tabControl1);
			this.Controls.Add(this.timeLabel);
			this.Controls.Add(this.titleLabel);
			this.Controls.Add(this.volumeBar);
			this.Controls.Add(this.timeBar);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.MaximizeBox = false;
			this.Name = "MainForm";
			this.Text = "SonicPlayer";
			this.DragDrop += new System.Windows.Forms.DragEventHandler(this.MainForm_DragDrop);
			this.DragEnter += new System.Windows.Forms.DragEventHandler(this.MainForm_DragEnter);
			this.tabControl1.ResumeLayout(false);
			this.tabPage1.ResumeLayout(false);
			this.tabPage3.ResumeLayout(false);
			this.tabPage2.ResumeLayout(false);
			this.groupBox2.ResumeLayout(false);
			this.groupBox2.PerformLayout();
			this.groupBox1.ResumeLayout(false);
			this.groupBox1.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.timeBar)).EndInit();
			this.toolStrip1.ResumeLayout(false);
			this.toolStrip1.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.volumeBar)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.volumePictureBox)).EndInit();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Label titleLabel;
		private System.Windows.Forms.Label timeLabel;
		private System.Windows.Forms.TabControl tabControl1;
		private System.Windows.Forms.TabPage tabPage1;
		private System.Windows.Forms.ListView playlist;
		private System.Windows.Forms.TabPage tabPage2;
		private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.CheckBox psgChannel3EnableBox;
		private System.Windows.Forms.CheckBox psgChannel2EnableBox;
		private System.Windows.Forms.CheckBox psgChannel1EnableBox;
		private System.Windows.Forms.CheckBox psgChannel0EnableBox;
		private System.Windows.Forms.GroupBox groupBox2;
		private System.Windows.Forms.CheckBox ym2413EnableBox;
		private System.Windows.Forms.TabPage tabPage3;
		private System.Windows.Forms.TrackBar timeBar;
		private System.Windows.Forms.ToolStrip toolStrip1;
		private System.Windows.Forms.ToolStripButton openButton;
		private System.Windows.Forms.ToolStripButton previousButton;
		private System.Windows.Forms.ToolStripButton playButton;
		private System.Windows.Forms.ToolStripButton stopButton;
		private System.Windows.Forms.ToolStripButton nextButton;
		private System.Windows.Forms.ToolStripButton loopButton;
		private System.Windows.Forms.TrackBar volumeBar;
		private System.Windows.Forms.ListBox trackInfoList;
		private System.Windows.Forms.ColumnHeader columnHeader1;
		private System.Windows.Forms.ColumnHeader columnHeader2;
		private System.Windows.Forms.OpenFileDialog openFileDialog;
		private System.Windows.Forms.CheckBox ym2151EnableBox;
		private System.Windows.Forms.CheckBox ym2612EnableBox;
		private System.Windows.Forms.PictureBox volumePictureBox;
		private System.Windows.Forms.ToolStripButton helpButton;
	}
}