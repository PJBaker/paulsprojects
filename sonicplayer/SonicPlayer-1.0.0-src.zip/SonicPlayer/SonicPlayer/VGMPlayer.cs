//	SonicPlayer
//	www.paulsprojects.net
//
//	Copyright (c) 2008, Paul Baker
//	All rights reserved.
//
//	Redistribution and use in source and binary forms, with or without modification,
//	are permitted provided that the following conditions are met:
//
//	    * Redistributions of source code must retain the above copyright notice,
//	      this list of conditions and the following disclaimer.
//	    * Redistributions in binary form must reproduce the above copyright notice,
//	      this list of conditions and the following disclaimer in the documentation
//	      and/or other materials provided with the distribution.
//	    * Neither the name of paulsprojects.net nor the names of its contributors
//	      may be used to endorse or promote products derived from this software
//	      without specific prior written permission.
//
//	THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
//	ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
//	WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
//	DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
//	ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
//	(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
//	LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
//	ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
//	(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
//	SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using Microsoft.DirectX.DirectSound;

namespace VGM_Player
{
	class VGMPlayer : IDisposable
	{
		private MainForm mainForm;

		private readonly List<VGMFile> vgmFiles = new List<VGMFile>();
		private int currentTrack = 0;

		private PSG psg;
		private YM2413 ym2413;
		private YM2612 ym2612;
		private YM2151 ym2151;

		private Device dsDevice;
		private const int soundBufferLength = 44100 / 10;
		private SecondaryBuffer soundBuffer;

		private int numSamplesWritten = 0;

		public VGMPlayer(MainForm mainForm_, string[] filenames)
		{
			mainForm = mainForm_;
			
			foreach(string filename in filenames)
			{
				if(Path.GetExtension(filename).ToUpper() == ".M3U")
				{
					string[] m3uFilenames = M3UParser.GetFilenames(filename);
					foreach(string m3uFilename in m3uFilenames)
					{
						vgmFiles.Add(new VGMFile(m3uFilename));
					}
				}
				else
				{
					vgmFiles.Add(new VGMFile(filename));
				}
			}

			dsDevice = new Device();
			dsDevice.SetCooperativeLevel(mainForm, CooperativeLevel.Priority);
			CreateSoundBuffer();

			VGMInfo[] vgmInfos = new VGMInfo[vgmFiles.Count];
			for(int i = 0; i < vgmInfos.Length; ++i)
			{
				vgmInfos[i] = vgmFiles[i].Info;
			}
			mainForm.SetPlaylist(vgmInfos);

			mainForm.thirtyMsPassed += UpdateSoundbuffer;

			BeginTrack(0);
			soundBuffer.Play(0, BufferPlayFlags.Looping);
		}

		private void CreateSoundBuffer()
		{
			WaveFormat format = new WaveFormat();
			format.FormatTag = WaveFormatTag.Pcm;
			format.BitsPerSample = 16;
			format.Channels = 2;
			format.BlockAlign = (short)((format.BitsPerSample * format.Channels) / 8);
			format.SamplesPerSecond = 44100;
			format.AverageBytesPerSecond = format.SamplesPerSecond * format.BlockAlign;

			BufferDescription description = new BufferDescription();
			description.Format = format;
			description.BufferBytes = soundBufferLength * format.BlockAlign;
			description.CanGetCurrentPosition = true;
			description.ControlVolume = true;
			description.GlobalFocus = true;
			description.LocateInSoftware = true;

			soundBuffer = new SecondaryBuffer(description, dsDevice);
			soundBuffer.Write(0, new short[soundBufferLength * 2], LockFlag.EntireBuffer);
		}

		private void BeginTrack(int track)
		{
			Debug.Assert(track >= 0);
			Debug.Assert(track < vgmFiles.Count);

			currentTrack = track;

			if(vgmFiles[currentTrack].PSGClock != 0)
			{
				psg = new PSG(	vgmFiles[currentTrack].PSGClock,
								vgmFiles[currentTrack].PSGWhiteNoiseFeedback,
								vgmFiles[currentTrack].PSGShiftRegisterWidth);
			}

			if(vgmFiles[currentTrack].YM2413Clock != 0)
			{
				ym2413 = new YM2413(vgmFiles[currentTrack].YM2413Clock);
			}

			if(vgmFiles[currentTrack].YM2612Clock != 0)
			{
				ym2612 = new YM2612(vgmFiles[currentTrack].YM2612Clock);
			}

			if(vgmFiles[currentTrack].YM2151Clock != 0)
			{
				ym2151 = new YM2151(vgmFiles[currentTrack].YM2151Clock);
			}

			mainForm.SetCurrentTrack(currentTrack);

			ResetTrack(true);
		}

		private void ResetTrack(bool updateMainForm)
		{
			ClearSoundbuffer();

			vgmFiles[currentTrack].ResetReadCursorToStart();
			numSamplesWritten = 0;

			if(updateMainForm)
			{
				mainForm.SetFractionPlayed(0.0);
			}

			samplesOverflowed = 0;
			endOfSoundDataReached = false;

			if(psg != null)		psg.Reset();
			if(ym2413 != null)	ym2413.Reset();
			if(ym2612 != null)	ym2612.Reset();
			if(ym2151 != null)	ym2151.Reset();
		}

		private void ClearSoundbuffer()
		{
			bool isPlaying = soundBuffer.Status.Playing;
			soundBuffer.Stop();

			soundBuffer.Write(0, new short[soundBufferLength * 2], LockFlag.EntireBuffer);

			if (isPlaying)
			{
				soundBuffer.Play(0, BufferPlayFlags.Looping);
			}
		}

		private bool disposed = false;

		public void Dispose()
		{
			Dispose(true);
		}

		protected virtual void Dispose(bool disposing)
		{
			if(!disposed)
			{
				if(disposing)
				{
					mainForm.thirtyMsPassed -= UpdateSoundbuffer;

					if(soundBuffer != null)
					{
						soundBuffer.Stop();
						soundBuffer.Dispose();
					}
				}

				disposed = true;
			}
		}

		#region Controls

		public void Play()
		{
			soundBuffer.Play(0, BufferPlayFlags.Looping);
			mainForm.Play();
		}

		public void Pause()
		{
			soundBuffer.Stop();
			ClearSoundbuffer();	//To prevent a soundbuffer length "blip" on unpausing if the output is disabled while paused
			mainForm.Pause();
		}

		public void Stop()
		{
			soundBuffer.Stop();
			ResetTrack(true);
			mainForm.Stop();
		}

		public void PreviousTrack()
		{
			int newTrack = (numSamplesWritten < 2 * 44100) ? Math.Max(currentTrack - 1, 0) : currentTrack;

			BeginTrack(newTrack);
		}

		public void NextTrack()
		{
			if(currentTrack < vgmFiles.Count - 1)
			{
				BeginTrack(currentTrack + 1);
			}
			else
			{
				Stop();
			}
		}

		public void SetTrack(int track)
		{
			Debug.Assert(track >= 0);
			Debug.Assert(track < vgmFiles.Count);

			BeginTrack(track);
			soundBuffer.Play(0, BufferPlayFlags.Looping);
		}

		private bool loop = false;
		public bool Loop
		{
			get { return loop; }
			set { loop = value; }
		}

		private double volume = 1.0;
		public double Volume
		{
			get { return volume; }
			set
			{
				volume = value;

				double dBVolume = Math.Log10(volume * 0.99 + 0.01) / Math.Log10(0.01);
				
				soundBuffer.Volume = (int)((1.0 - dBVolume) * (double)Microsoft.DirectX.DirectSound.Volume.Max +
					dBVolume * (double)Microsoft.DirectX.DirectSound.Volume.Min);
			}
		}

		public void Seek(double fractionPlayed)
		{
			int seekSample = (int)(fractionPlayed * vgmFiles[currentTrack].Info.numSamples);

			if(seekSample < numSamplesWritten)
			{
				ResetTrack(false);

				CalculateSoundbuffer(seekSample, false);
				numSamplesWritten += seekSample;
			}
			else
			{
				ClearSoundbuffer();

				CalculateSoundbuffer(seekSample - numSamplesWritten, false);
				numSamplesWritten += seekSample - numSamplesWritten;
			}

			double fractionPlayed2 = Clamp((double)(numSamplesWritten - soundBufferLength) / vgmFiles[currentTrack].Info.numSamples, 0.0, 1.0);
			mainForm.SetFractionPlayed(fractionPlayed2);
		}

		public bool PSGChannel0Enabled
		{
			set { if(psg != null) psg.Channel0Enabled = value; }
		}

		public bool PSGChannel1Enabled
		{
			set { if(psg != null) psg.Channel1Enabled = value; }
		}

		public bool PSGChannel2Enabled
		{
			set { if(psg != null) psg.Channel2Enabled = value; }
		}

		public bool PSGChannel3Enabled
		{
			set { if(psg != null) psg.Channel3Enabled = value; }
		}

		private bool ym2413Enabled = true;
		public bool YM2413Enabled
		{
			set { ym2413Enabled = value; }
		}

		private bool ym2612Enabled = true;
		public bool YM2612Enabled
		{
			set { ym2612Enabled = value; }
		}

		private bool ym2151Enabled = true;
		public bool YM2151Enabled
		{
			set { ym2151Enabled = value; }
		}

		#endregion

		#region Soundbuffer calculation

		private int lastPlayCursorPosition = 0;
		private bool lastEndOfSoundDataLooped = false;

		private void UpdateSoundbuffer()
		{
			if(!soundBuffer.Status.Playing)
				return;

			int playCursorPosition = soundBuffer.PlayPosition;
			if(playCursorPosition == lastPlayCursorPosition)
			{
				return;
			}

			int numSamples = (playCursorPosition - lastPlayCursorPosition) / 4;
			if(numSamples < 0)
			{
				numSamples += soundBufferLength;
			}

			soundBuffer.Write(lastPlayCursorPosition, CalculateSoundbuffer(numSamples, true), LockFlag.None);

			lastPlayCursorPosition = playCursorPosition;

			numSamplesWritten += numSamples;

			if(numSamplesWritten >= vgmFiles[currentTrack].Info.numSamples + soundBufferLength)
			{
				if(lastEndOfSoundDataLooped)
				{
					numSamplesWritten -= (int)vgmFiles[currentTrack].Info.numLoopSamples;
				}
				else
				{
					NextTrack();
				}
			}

			double fractionPlayed = Clamp((double)(numSamplesWritten - soundBufferLength) / vgmFiles[currentTrack].Info.numSamples, 0.0, 1.0);
			mainForm.SetFractionPlayed(fractionPlayed);
		}

		private double Clamp(double value, double min, double max)
		{
			return Math.Min(Math.Max(value, min), max);
		}

		private int samplesOverflowed = 0;
		private bool endOfSoundDataReached = false;

		private short[] CalculateSoundbuffer(int totalSamples, bool calculateSamples)
		{
			short[] samples = calculateSamples ? new short[totalSamples * 2] : null;
			
			if(endOfSoundDataReached)
			{
				return samples;
			}
			
			int currentSample = 0;

			if(samplesOverflowed > 0)
			{
				CalculateSamples(samplesOverflowed, ref currentSample, totalSamples, samples, out samplesOverflowed);
			}

			while(currentSample < totalSamples && !endOfSoundDataReached)
			{
				Byte command = vgmFiles[currentTrack].GetNextByte();
				switch(command)
				{
					case 0x4f:	//GG stereo
						byte data = vgmFiles[currentTrack].GetNextByte();
						if(psg != null)
						{
							psg.WriteStereoPort(data);
						}
						break;

					case 0x50:	//PSG write
						data = vgmFiles[currentTrack].GetNextByte();
						if(psg != null)
						{
							psg.WritePort(data);
						}
						break;

					case 0x51:	//YM2413 write
						byte address = vgmFiles[currentTrack].GetNextByte();
						data = vgmFiles[currentTrack].GetNextByte();
						if(ym2413 != null)
						{
							ym2413.WriteRegister(address, data);
						}
						break;

					case 0x52:	//YM2612 port 0 write
						address = vgmFiles[currentTrack].GetNextByte();
						data = vgmFiles[currentTrack].GetNextByte();
						if(ym2612 != null)
						{
							ym2612.WritePort0Register(address, data);
						}
						break;

					case 0x53:	//YM2612 port 1 write
						address = vgmFiles[currentTrack].GetNextByte();
						data = vgmFiles[currentTrack].GetNextByte();
						if(ym2612 != null)
						{
							ym2612.WritePort1Register(address, data);
						}
						break;

					case 0x54:	//YM2151 write
						address = vgmFiles[currentTrack].GetNextByte();
						data = vgmFiles[currentTrack].GetNextByte();
						if(ym2151 != null)
						{
							ym2151.WriteRegister(address, data);
						}
						break;

					case 0x61:	//Wait variable time
						int numSamplesLow = vgmFiles[currentTrack].GetNextByte();
						int numSamplesHigh = vgmFiles[currentTrack].GetNextByte();
						int numSamples = (numSamplesHigh << 8) | numSamplesLow;
						CalculateSamples(numSamples, ref currentSample, totalSamples, samples, out samplesOverflowed);
						break;

					case 0x62:	//Wait 1/60s
						CalculateSamples(735, ref currentSample, totalSamples, samples, out samplesOverflowed);
						break;

					case 0x63:	//Wait 1/50s
						CalculateSamples(882, ref currentSample, totalSamples, samples, out samplesOverflowed);
						break;

					case 0x66:	//End of sound data
						if(loop && vgmFiles[currentTrack].Info.hasLoop)
						{
							vgmFiles[currentTrack].ResetReadCursorToLoopPoint();
							lastEndOfSoundDataLooped = true;
						}
						else
						{
							endOfSoundDataReached = true;
							lastEndOfSoundDataLooped = false;
						}
						break;

					case 0x70: case 0x71: case 0x72: case 0x73: case 0x74: case 0x75: case 0x76: case 0x77:	//Short wait
					case 0x78: case 0x79: case 0x7a: case 0x7b: case 0x7c: case 0x7d: case 0x7e: case 0x7f:
						CalculateSamples((command & 0x0f) + 1, ref currentSample, totalSamples, samples, out samplesOverflowed);
						break;

					case 0x80: case 0x81: case 0x82: case 0x83: case 0x84: case 0x85: case 0x86: case 0x87:	//PCM data bank write then short wait
					case 0x88: case 0x89: case 0x8a: case 0x8b: case 0x8c: case 0x8d: case 0x8e: case 0x8f:
						ym2612.WritePort0Register(0x2a, vgmFiles[currentTrack].GetNextDataBlockByte(0x00));
						CalculateSamples(command & 0x0f, ref currentSample, totalSamples, samples, out samplesOverflowed);
						break;

					case 0xe0:	//PCM data bank seek
						uint position = vgmFiles[currentTrack].GetNextByte();
						position |= ((uint)vgmFiles[currentTrack].GetNextByte() << 8);
						position |= ((uint)vgmFiles[currentTrack].GetNextByte() << 16);
						position |= ((uint)vgmFiles[currentTrack].GetNextByte() << 24);
						vgmFiles[currentTrack].SetDataBlockCursorPosition(0x00, position);
						break;

					case 0x30: case 0x31: case 0x32: case 0x33: case 0x34: case 0x35: case 0x36: case 0x37:	//One operand reserved
					case 0x38: case 0x39: case 0x3a: case 0x3b: case 0x3c: case 0x3d: case 0x3e: case 0x3f:
					case 0x40: case 0x41: case 0x42: case 0x43: case 0x44: case 0x45: case 0x46: case 0x47:
					case 0x48: case 0x49: case 0x4a: case 0x4b: case 0x4c: case 0x4d: case 0x4e:
						vgmFiles[currentTrack].GetNextByte();
						break;

					                                                       case 0x55: case 0x56: case 0x57:	//Two operands reserved
					case 0x58: case 0x59: case 0x5a: case 0x5b: case 0x5c: case 0x5d: case 0x5e: case 0x5f:
					case 0xa0: case 0xa1: case 0xa2: case 0xa3: case 0xa4: case 0xa5: case 0xa6: case 0xa7:
					case 0xa8: case 0xa9: case 0xaa: case 0xab: case 0xac: case 0xad: case 0xae: case 0xaf:
					case 0xb0: case 0xb1: case 0xb2: case 0xb3: case 0xb4: case 0xb5: case 0xb6: case 0xb7:
					case 0xb8: case 0xb9: case 0xba: case 0xbb: case 0xbc: case 0xbd: case 0xbe: case 0xbf:
						vgmFiles[currentTrack].GetNextByte();
						vgmFiles[currentTrack].GetNextByte();
						break;

					case 0xc0: case 0xc1: case 0xc2: case 0xc3: case 0xc4: case 0xc5: case 0xc6: case 0xc7:	//Three operands reserved
					case 0xc8: case 0xc9: case 0xca: case 0xcb: case 0xcc: case 0xcd: case 0xce: case 0xcf:
					case 0xd0: case 0xd1: case 0xd2: case 0xd3: case 0xd4: case 0xd5: case 0xd6: case 0xd7:
					case 0xd8: case 0xd9: case 0xda: case 0xdb: case 0xdc: case 0xdd: case 0xde: case 0xdf:
						vgmFiles[currentTrack].GetNextByte();
						vgmFiles[currentTrack].GetNextByte();
						vgmFiles[currentTrack].GetNextByte();
						break;

					           case 0xe1: case 0xe2: case 0xe3: case 0xe4: case 0xe5: case 0xe6: case 0xe7:	//Four operands reserved
					case 0xe8: case 0xe9: case 0xea: case 0xeb: case 0xec: case 0xed: case 0xee: case 0xef:
					case 0xf0: case 0xf1: case 0xf2: case 0xf3: case 0xf4: case 0xf5: case 0xf6: case 0xf7:
					case 0xf8: case 0xf9: case 0xfa: case 0xfb: case 0xfc: case 0xfd: case 0xfe: case 0xff:
						vgmFiles[currentTrack].GetNextByte();
						vgmFiles[currentTrack].GetNextByte();
						vgmFiles[currentTrack].GetNextByte();
						vgmFiles[currentTrack].GetNextByte();
						break;
				}
			}

			return samples;
		}

		private void CalculateSamples(int numSamples, ref int currentSample, int totalSamples, short[] samples, out int numSamplesOverflowed)
		{
			int samplesRemaining = totalSamples - currentSample;

			int numSamplesToCalculate;
			if(numSamples <= samplesRemaining)
			{
				numSamplesToCalculate = numSamples;
				numSamplesOverflowed = 0;
			}
			else
			{
				numSamplesToCalculate = samplesRemaining;
				numSamplesOverflowed = numSamples - samplesRemaining;
			}

			Debug.Assert(numSamplesToCalculate >= 0);
			if(numSamplesToCalculate == 0)
			{
				return;
			}

			if(samples != null)
			{
				if(psg != null)
				{
					short[] psgSamples = psg.CalculateSamples(numSamplesToCalculate);
					Debug.Assert(psgSamples.Length == numSamplesToCalculate * 2);
					for(int i = 0; i < numSamplesToCalculate * 2; ++i)
					{
						samples[currentSample * 2 + i] += psgSamples[i];
					}
				}

				if(ym2413 != null)
				{
					short[] ym2413Samples = ym2413.CalculateSamples(numSamplesToCalculate);
					Debug.Assert(ym2413Samples.Length == numSamplesToCalculate * 2);
					
					if(ym2413Enabled)
					{
						for(int i = 0; i < numSamplesToCalculate * 2; ++i)
						{
							samples[currentSample * 2 + i] += ym2413Samples[i];
						}
					}
				}

				if(ym2612 != null)
				{
					short[] ym2612Samples = ym2612.CalculateSamples(numSamplesToCalculate);
					Debug.Assert(ym2612Samples.Length == numSamplesToCalculate * 2);

					if(ym2612Enabled)
					{
						for(int i = 0; i < numSamplesToCalculate * 2; ++i)
						{
							samples[currentSample * 2 + i] += ym2612Samples[i];
						}
					}
				}

				if(ym2151 != null)
				{
					short[] ym2151Samples = ym2151.CalculateSamples(numSamplesToCalculate);
					Debug.Assert(ym2151Samples.Length == numSamplesToCalculate * 2);

					if(ym2151Enabled)
					{
						for(int i = 0; i < numSamplesToCalculate * 2; ++i)
						{
							samples[currentSample * 2 + i] += ym2151Samples[i];
						}
					}
				}
			}

			currentSample += numSamplesToCalculate;
		}

		#endregion
	}
}