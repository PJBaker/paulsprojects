//	SonicPlayer
//	www.paulsprojects.net
//
//	Copyright (c) 2008, Paul Baker
//	All rights reserved.
//
//	Redistribution and use in source and binary forms, with or without modification,
//	are permitted provided that the following conditions are met:
//
//	    * Redistributions of source code must retain the above copyright notice,
//	      this list of conditions and the following disclaimer.
//	    * Redistributions in binary form must reproduce the above copyright notice,
//	      this list of conditions and the following disclaimer in the documentation
//	      and/or other materials provided with the distribution.
//	    * Neither the name of paulsprojects.net nor the names of its contributors
//	      may be used to endorse or promote products derived from this software
//	      without specific prior written permission.
//
//	THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
//	ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
//	WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
//	DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
//	ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
//	(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
//	LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
//	ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
//	(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
//	SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Text;
using System.Windows.Forms;

namespace VGM_Player
{
	public partial class MainForm : Form
	{
		private Timer timer;
		public delegate void ThirtyMsPassedEventHandler();
		public event ThirtyMsPassedEventHandler thirtyMsPassed;

		private VGMPlayer vgmPlayer;
		private VGMInfo[] infos;

		private int currentTrack = 0;
		private bool moveTimeBar = true;

		/// <summary>
		/// Class to render a tool strip in the "System" style, but without the border at the bottom
		/// </summary>
		/// <remarks>
		/// Derived from that at: http://connect.microsoft.com/VisualStudio/feedback/ViewFeedback.aspx?FeedbackID=92862
		/// </remarks>
		private class ToolStripBorderlessSystemRenderer : ToolStripSystemRenderer
		{
			protected override void OnRenderToolStripBorder(ToolStripRenderEventArgs e)
			{
			}
		}
		
		public MainForm()
		{
			InitializeComponent();

			timeBar.AutoSize = false;
			timeBar.Height = 25;

			volumeBar.AutoSize = false;
			volumeBar.Height = 25;
			
			toolStrip1.Renderer = new ToolStripBorderlessSystemRenderer();

			SetTimeLabelText("0:00 / 0:00");

			timer = new Timer();
			timer.Interval = 30;
			timer.Tick += delegate(object sender, EventArgs e)
			{
				if(thirtyMsPassed != null)
				{
					thirtyMsPassed();
				}
			};
			timer.Start();
		}

		public void SetPlaylist(params VGMInfo[] infos_)
		{
			infos = infos_;

			playlist.Items.Clear();

			foreach(VGMInfo info in infos)
			{
				ListViewItem playlistItem = new ListViewItem(info.title);
				playlistItem.SubItems.Add(info.lengthString);

				playlist.Items.Add(playlistItem);
			}
		}

		private void SetTimeLabelText(string text)
		{
			timeLabel.Text = text;

			Point location = timeLabel.Location;
			location.X = ClientSize.Width - 12 - timeLabel.Size.Width;
			timeLabel.Location = location;
		}

		public void SetCurrentTrack(int index)
		{
			Debug.Assert(index < infos.Length);

			currentTrack = index;

			titleLabel.Text = infos[currentTrack].title;
			SetTimeLabelText("0:00 / " + infos[currentTrack].lengthString);

			foreach(ListViewItem item in playlist.Items)
			{
				item.Font = new Font(item.Font, 0);
			}
			
			playlist.Items[currentTrack].Font = new Font(playlist.Items[currentTrack].Font, FontStyle.Bold);

			trackInfoList.Items.Clear();
			trackInfoList.Items.AddRange(new object[]
			{
				"Title:\t" + infos[currentTrack].title,
				"Game:\t" + infos[currentTrack].game,
				"System:\t" + infos[currentTrack].system,
				"Author:\t" + infos[currentTrack].author,
				"Date:\t" + infos[currentTrack].date,
				"Creator:\t" + infos[currentTrack].creator,
				"Length:\t" + infos[currentTrack].lengthString,
				"Version:\t" + infos[currentTrack].versionString,
				"Notes:\t" + infos[currentTrack].notes
			});
		}

		public void SetFractionPlayed(double fraction)
		{
			Debug.Assert(timeBar.Minimum == 0);
			if(moveTimeBar)
			{
				timeBar.Value = (int)(fraction * timeBar.Maximum);
			}

			int numSamplesPlayed = (int)(fraction * infos[currentTrack].numSamples);
			int numMinutesPlayed = (numSamplesPlayed / 44100) / 60;
			int numSecondsPlayed = (numSamplesPlayed / 44100) % 60;
			string timePlayedString = numMinutesPlayed.ToString() + ':' + numSecondsPlayed.ToString("d2");

			SetTimeLabelText(timePlayedString + " / " + infos[currentTrack].lengthString);
		}

		private void openButton_Click(object sender, EventArgs e)
		{
			if(openFileDialog.ShowDialog() == DialogResult.OK)
			{
				CreateVGMPlayer(openFileDialog.FileNames);
			}
		}

		private void CreateVGMPlayer(string[] filenames)
		{
			if (vgmPlayer != null)
			{
				vgmPlayer.Dispose();
				vgmPlayer = null;
			}

			try
			{
				vgmPlayer = new VGMPlayer(this, filenames);
			}
			catch(FileNotFoundException ex)
			{
				string text = ex.FileName + " not found.";

				if(ex.FileName.StartsWith("Microsoft.DirectX"))
				{
					text += Environment.NewLine + Environment.NewLine;
					text += "SonicPlayer requires an up-to-date DirectX Runtime to be installed.";
				}
				
				MessageBox.Show(text, "File Not Found" , MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
			catch(VGMFile.InvalidVGMFileException ex)
			{
				string text = ex.Filename + " is not a valid VGM file.";
				MessageBox.Show(text, "Invalid VGM File" , MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
			catch(Exception ex)
			{
				string text = ex.Message;
				MessageBox.Show(text, "Error" , MessageBoxButtons.OK, MessageBoxIcon.Error);
			}

			if(vgmPlayer != null)
			{
				vgmPlayer.Loop = loopButton.Checked;
				Debug.Assert(volumeBar.Minimum == 0);
				vgmPlayer.Volume = (double)volumeBar.Value / volumeBar.Maximum;
				vgmPlayer.PSGChannel0Enabled = psgChannel0EnableBox.Checked;
				vgmPlayer.PSGChannel1Enabled = psgChannel1EnableBox.Checked;
				vgmPlayer.PSGChannel2Enabled = psgChannel2EnableBox.Checked;
				vgmPlayer.PSGChannel3Enabled = psgChannel3EnableBox.Checked;
				vgmPlayer.YM2413Enabled = ym2413EnableBox.Checked;
				vgmPlayer.YM2612Enabled = ym2612EnableBox.Checked;
				vgmPlayer.YM2151Enabled = ym2151EnableBox.Checked;

				playButton.Checked = true;
				playButton.ToolTipText = "Pause";
			}
		}

		private void volumeBar_Scroll(object sender, EventArgs e)
		{
			if(vgmPlayer != null)
			{
				Debug.Assert(volumeBar.Minimum == 0);
				vgmPlayer.Volume = (double)volumeBar.Value / volumeBar.Maximum;
			}
		}

		private void psgChannel0EnableBox_CheckedChanged(object sender, EventArgs e)
		{
			if(vgmPlayer != null)
			{
				vgmPlayer.PSGChannel0Enabled = psgChannel0EnableBox.Checked;
			}
		}

		private void psgChannel1EnableBox_CheckedChanged(object sender, EventArgs e)
		{
			if(vgmPlayer != null)
			{
				vgmPlayer.PSGChannel1Enabled = psgChannel1EnableBox.Checked;
			}
		}

		private void psgChannel2EnableBox_CheckedChanged(object sender, EventArgs e)
		{
			if(vgmPlayer != null)
			{
				vgmPlayer.PSGChannel2Enabled = psgChannel2EnableBox.Checked;
			}
		}

		private void psgChannel3EnableBox_CheckedChanged(object sender, EventArgs e)
		{
			if(vgmPlayer != null)
			{
				vgmPlayer.PSGChannel3Enabled = psgChannel3EnableBox.Checked;
			}
		}

		private void ym2413EnableBox_CheckedChanged(object sender, EventArgs e)
		{
			if(vgmPlayer != null)
			{
				vgmPlayer.YM2413Enabled = ym2413EnableBox.Checked;
			}
		}

		private void ym2612EnableBox_CheckedChanged(object sender, EventArgs e)
		{
			if(vgmPlayer != null)
			{
				vgmPlayer.YM2612Enabled = ym2612EnableBox.Checked;
			}
		}

		private void ym2151EnableBox_CheckedChanged(object sender, EventArgs e)
		{
			if(vgmPlayer != null)
			{
				vgmPlayer.YM2151Enabled = ym2151EnableBox.Checked;
			}
		}

		private void playButton_Click(object sender, EventArgs e)
		{
			if(vgmPlayer != null)
			{
				if(playButton.Checked)
				{
					vgmPlayer.Play();
				}
				else
				{
					vgmPlayer.Pause();
				}
			}
			else
			{
				playButton.Checked = false;
			}
		}

		public void Play()
		{
			playButton.Checked = true;
			playButton.ToolTipText = "Pause";
		}

		public void Pause()
		{
			playButton.Checked = false;
			playButton.ToolTipText = "Play";
		}

		private void stopButton_Click(object sender, EventArgs e)
		{
			if(vgmPlayer != null)
			{
				vgmPlayer.Stop();
			}
		}

		public void Stop()
		{
			playButton.Checked = false;
			playButton.ToolTipText = "Play";
		}

		private void loopButton_Click(object sender, EventArgs e)
		{
			if(vgmPlayer != null)
			{
				vgmPlayer.Loop = loopButton.Checked;
			}
		}

		private void previousButton_Click(object sender, EventArgs e)
		{
			if(vgmPlayer != null)
			{
				vgmPlayer.PreviousTrack();
			}
		}

		private void nextButton_Click(object sender, EventArgs e)
		{
			if(vgmPlayer != null)
			{
				vgmPlayer.NextTrack();
			}
		}

		private void timeBar_MouseDown(object sender, MouseEventArgs e)
		{
			moveTimeBar = false;

		}

		private void timeBar_MouseUp(object sender, MouseEventArgs e)
		{
			moveTimeBar = true;

			if(vgmPlayer != null)
			{
				Debug.Assert(timeBar.Minimum == 0);
				vgmPlayer.Seek((double)timeBar.Value / timeBar.Maximum);
			}
		}

		private void playlist_ItemActivate(object sender, EventArgs e)
		{
			Debug.Assert(playlist.SelectedIndices.Count == 1);

			if(vgmPlayer != null)
			{
				vgmPlayer.SetTrack(playlist.SelectedIndices[0]);
			}
		}

		private void MainForm_DragDrop(object sender, DragEventArgs e)
		{
			if(e.Data.GetDataPresent(DataFormats.FileDrop))
			{
				CreateVGMPlayer((string[])e.Data.GetData(DataFormats.FileDrop));
			}
		}

		private void MainForm_DragEnter(object sender, DragEventArgs e)
		{
			if(e.Data.GetDataPresent(DataFormats.FileDrop))
			{
				e.Effect = DragDropEffects.Copy;
			}
			else
			{
				e.Effect = DragDropEffects.None;
			}
		}

		private void helpButton_Click(object sender, EventArgs e)
		{
			using(AboutForm aboutForm = new AboutForm())
			{
				aboutForm.ShowDialog(this);
			}
		}
	}
}