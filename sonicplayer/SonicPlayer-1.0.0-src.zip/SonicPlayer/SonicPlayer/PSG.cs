//	SonicPlayer
//	www.paulsprojects.net
//
//	Copyright (c) 2008, Paul Baker
//	All rights reserved.
//
//	Redistribution and use in source and binary forms, with or without modification,
//	are permitted provided that the following conditions are met:
//
//	    * Redistributions of source code must retain the above copyright notice,
//	      this list of conditions and the following disclaimer.
//	    * Redistributions in binary form must reproduce the above copyright notice,
//	      this list of conditions and the following disclaimer in the documentation
//	      and/or other materials provided with the distribution.
//	    * Neither the name of paulsprojects.net nor the names of its contributors
//	      may be used to endorse or promote products derived from this software
//	      without specific prior written permission.
//
//	THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
//	ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
//	WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
//	DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
//	ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
//	(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
//	LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
//	ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
//	(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
//	SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

using System;

namespace VGM_Player
{
	class PSG
	{
		private readonly uint clock;
		private readonly ushort whiteNoiseFeedback;
		private readonly byte shiftRegisterWidth;

		private byte latchedChannel = 0;
		private bool volumesLatched = false;
		private byte[] volumeRegisters = {0x0f, 0x0f, 0x0f, 0x0f};
		private ushort[] toneRegisters = new ushort[3];
		private byte noiseRegister = 0;

		private double[] tonePhaseCounters = {0.0, 0.0, 0.0};
		private byte[] toneOutputs = {0, 0, 0};

		private double noisePhaseCounter = 0.0;
		private byte noiseOutput = 0;
		private ushort noiseLFSR;
		private byte noiseLFSROutput = 0;

		private bool[] leftOutputEnabled = {true, true, true, true};
		private bool[] rightOutputEnabled = {true, true, true, true};
		
		public PSG(uint clock_, ushort whiteNoiseFeedback_, byte shiftRegisterWidth_)
		{
			clock = clock_;
			whiteNoiseFeedback = whiteNoiseFeedback_;
			shiftRegisterWidth = shiftRegisterWidth_;

			noiseLFSR = (ushort)(1 << (shiftRegisterWidth - 1));
		}

		public void Reset()
		{
			latchedChannel = 0;
			volumesLatched = false;
			volumeRegisters[0] = 0x0f;
			volumeRegisters[1] = 0x0f;
			volumeRegisters[2] = 0x0f;
			volumeRegisters[3] = 0x0f;
			toneRegisters[0] = 0x0000;
			toneRegisters[1] = 0x0000;
			toneRegisters[2] = 0x0000;
			noiseRegister = 0;

			tonePhaseCounters[0] = 0.0;
			tonePhaseCounters[1] = 0.0;
			tonePhaseCounters[2] = 0.0;
			toneOutputs[0] = 0;
			toneOutputs[1] = 0;
			toneOutputs[2] = 0;

			noisePhaseCounter = 0.0;
			noiseOutput = 0;
			noiseLFSR = (ushort)(1 << (shiftRegisterWidth - 1));
			noiseOutput = 0;

			leftOutputEnabled[0] = true;
			leftOutputEnabled[1] = true;
			leftOutputEnabled[2] = true;
			leftOutputEnabled[3] = true;
			rightOutputEnabled[0] = true;
			rightOutputEnabled[1] = true;
			rightOutputEnabled[2] = true;
			rightOutputEnabled[3] = true;
		}

		private bool[] channelsEnabled = {true, true, true, true};

		public bool Channel0Enabled
		{
			get { return channelsEnabled[0]; }
			set { channelsEnabled[0] = value; }
		}

		public bool Channel1Enabled
		{
			get { return channelsEnabled[1]; }
			set { channelsEnabled[1] = value; }
		}

		public bool Channel2Enabled
		{
			get { return channelsEnabled[2]; }
			set { channelsEnabled[2] = value; }
		}

		public bool Channel3Enabled
		{
			get { return channelsEnabled[3]; }
			set { channelsEnabled[3] = value; }
		}

		public void WritePort(byte data)
		{
			if((data & 0x80) != 0)
			{
				//A latch/data byte
				latchedChannel = (byte)((data & 0x60) >> 5);
				volumesLatched = (data & 0x10) != 0;

				if(volumesLatched)
				{
					volumeRegisters[latchedChannel] = (byte)(data & 0x0f);
				}
				else if(latchedChannel < 3)
				{
					toneRegisters[latchedChannel] &= 0x03f0;
					toneRegisters[latchedChannel] |= (ushort)(data & 0x0f);
				}
				else
				{
					noiseRegister = (byte)(data & 0x07);
					noiseLFSR = 0x8000;
				}
			}
			else
			{
				//A data byte
				if(volumesLatched)
				{
					volumeRegisters[latchedChannel] = (byte)(data & 0x0f);
				}
				else if(latchedChannel < 3)
				{
					toneRegisters[latchedChannel] &= 0x000f;
					toneRegisters[latchedChannel] |= (ushort)((data & 0x3f) << 4);
				}
				else
				{
					noiseRegister = (byte)(data & 0x07);
					noiseLFSR = 0x8000;
				}
			}
		}

		public void WriteStereoPort(byte data)
		{
			rightOutputEnabled[0] = (data & 0x01) != 0;
			rightOutputEnabled[1] = (data & 0x02) != 0;
			rightOutputEnabled[2] = (data & 0x04) != 0;
			rightOutputEnabled[3] = (data & 0x08) != 0;

			leftOutputEnabled[0] = (data & 0x10) != 0;
			leftOutputEnabled[1] = (data & 0x20) != 0;
			leftOutputEnabled[2] = (data & 0x40) != 0;
			leftOutputEnabled[3] = (data & 0x80) != 0;
		}

		public short[] CalculateSamples(int numSamples)
		{
			short[] samples = new short[numSamples * 2];
			
			for(int channel = 0; channel < 3; ++channel)
			{
				CalculateToneSamples(channel, channelsEnabled[channel], numSamples, samples);
			}
			CalculateNoiseSamples(channelsEnabled[3], numSamples, samples);

			return samples;
		}

		private void CalculateToneSamples(int channel, bool channelEnabled, int numSamples, short[] samples)
		{
			for(int i = 0; i < numSamples; ++i)
			{
				short sample;

				if(toneRegisters[channel] < 0x0002)
				{
					tonePhaseCounters[channel] = 0.0;

					sample = (short)(volumeTable[volumeRegisters[channel]] / 16);
				}
				else
				{
					tonePhaseCounters[channel] -= clock / (16.0 * 44100);

					while(tonePhaseCounters[channel] < 0.0)
					{
						tonePhaseCounters[channel] += toneRegisters[channel];
						toneOutputs[channel] = (byte)(1 - toneOutputs[channel]);
					}

					sample = (short)((2 * toneOutputs[channel] - 1) * volumeTable[volumeRegisters[channel]] / 16);
				}

				if(channelEnabled)
				{
					if(leftOutputEnabled[channel])
					{
						samples[i * 2] += sample;
					}

					if(rightOutputEnabled[channel])
					{
						samples[i * 2 + 1] += sample;
					}
				}
			}
		}

		private ushort Parity(ushort val)
		{
			val ^= (ushort)(val >> 8);
			val ^= (ushort)(val >> 4);
			val ^= (ushort)(val >> 2);
			val ^= (ushort)(val >> 1);

			return (ushort)(val & 0x0001);
		}

		private void CalculateNoiseSamples(bool channelEnabled, int numSamples, short[] samples)
		{
			for(int i = 0; i < numSamples; ++i)
			{
				noisePhaseCounter -= clock / (16.0 * 44100);

				while(noisePhaseCounter < 0.0)
				{
					switch(noiseRegister & 0x03)
					{
						case 0x00:	noisePhaseCounter += 0x10; break;
						case 0x01:	noisePhaseCounter += 0x20; break;
						case 0x02:	noisePhaseCounter += 0x40; break;
						case 0x03:	noisePhaseCounter += (toneRegisters[2] != 0x0000) ? (double)toneRegisters[2] : 0x0001; break;
					}

					noiseOutput = (byte)(1 - noiseOutput);

					if(noiseOutput == 1)
					{
						noiseLFSROutput = (byte)(noiseLFSR & 0x0001);

						ushort noiseLFSRInput;
						if((noiseRegister & 0x04) != 0)
						{
							noiseLFSRInput = Parity((ushort)(noiseLFSR & whiteNoiseFeedback));
						}
						else
						{
							noiseLFSRInput = (ushort)(noiseLFSR & 0x0001);
						}
						noiseLFSR >>= 1;
						noiseLFSR |= (ushort)(noiseLFSRInput << (shiftRegisterWidth - 1));
					}
				}

				if(channelEnabled)
				{
					short sample = (short)(noiseLFSROutput * volumeTable[volumeRegisters[3]] / 8);

					if(leftOutputEnabled[3])
					{
						samples[i * 2] += sample;
					}

					if(rightOutputEnabled[3])
					{
						samples[i * 2 + 1] += sample;
					}
				}
			}

		}

		#region Lookup tables

		private readonly short[] volumeTable =
		{
			32767, 26028, 20675, 16422, 13045, 10362, 8231, 6538,
			5193, 4125, 3277, 2603, 2067, 1642, 1304, 0
		};

		#endregion
	}
}
