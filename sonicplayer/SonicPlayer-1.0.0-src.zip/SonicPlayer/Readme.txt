SonicPlayer
===========

www.paulsprojects.net
---------------------

Play music from games for the Sega Master System, Genesis and other systems!

SonicPlayer is a standalone music player for Windows supporting the VGM format. Files in this format can be created by many emulators, including Meka (http://www.smspower.org/meka/) and Kega Fusion (http://www.eidolons-inn.net/tiki-index.php?page=kega). Many VGM files are also available in archives, for example http://www.smspower.org/music/vgm/index.shtml and http://project2612.org/.

SonicPlayer features a highly accurate implementation of the SN76489 PSG, thanks to the information at http://www.smspower.org/dev/docs/wiki/Sound/PSG. Also suported are the YM2413, YM2612 and YM2151 FM chips, using the implementations from the MAME (http://mamedev.org/) project. SonicPlayer thus supports the playback of music written for many systems, including the Sega Genesis (Mega Drive), Master System and Game Gear, the BBC Micro and some arcade games.

System Requirements
-------------------

.NET framework 2.0
DirectX Runtime

Special Thanks
--------------

SMS POWER! (http://www.smspower.org/)
Nicola Salmoria and the MAME team (http://mamedev.org)