//////////////////////////////////////////////////////////////////////////////////////////
//	SGIX_shadow_extension.h
//	Extension setup header
//	Downloaded from: www.paulsprojects.net
//	Created:	20th July 2002
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	

#ifndef SGIX_SHADOW_EXTENSION_H
#define SGIX_SHADOW_EXTENSION_H

bool SetUpSGIX_shadow();
extern bool SGIX_shadow_supported;

#endif	//SGIX_SHADOW_EXTENSION_H
