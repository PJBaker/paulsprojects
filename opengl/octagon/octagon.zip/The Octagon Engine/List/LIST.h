//////////////////////////////////////////////////////////////////////////////////////////
//	LIST.h
//	Template class for a list of items. Like std::vector, but holds on to any memory
//	it creates, so that there is no penalty for allocating memory per frame
//	Downloaded from: www.paulsprojects.net
//	Created:	8th December 2002
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	

#ifndef LIST_H
#define LIST_H

#include "../Log/LOG.h"

template <class T>

class LIST
{
public:
	//Add a list of elements to the end
	bool AddElements(int count, const T * newEntries)
	{
		//If there is not space in the list for the new elements, create it
		if(listSize-numEntries<count)
		{
			if(!IncreaseSpace(numEntries+count))
				return false;
		}

		//Copy the new elements into the list
		memcpy(&entries[numEntries], newEntries, count*sizeof(T));

		//Increase numElements
		numEntries+=count;

		return true;
	}

	//Add a list of elements, with options
	bool AddElementsEx(int count, const T * newEntries, bool reverse, T baseOffset)
	{
		//If there is not space in the list for the new elements, create it
		if(listSize-numEntries<count)
		{
			if(!IncreaseSpace(numEntries+count))
				return false;
		}

		//Copy the new elements into the list
		if(!reverse)
		{
			for(int i=0; i<count; ++i)
				entries[numEntries+i]=newEntries[i]+baseOffset;
		}
		else	//if(reverse)
		{
			for(int i=0; i<count; ++i)
				entries[numEntries+i]=newEntries[count-i-1]+baseOffset;
		}

		//Increase numElements
		numEntries+=count;

		return true;
	}

	//Add a consecutive list of elements to the end
	bool AddArray(int first, int count)
	{
		//If there is not space in the list for the new elements, create it
		if(listSize-numEntries<count)
		{
			if(!IncreaseSpace(numEntries+count))
				return false;
		}

		//Fill the new elements in the list
		for(int i=0; i<count; ++i)
			entries[numEntries+i]=first+i;

		//Increase numElements
		numEntries+=count;

		return true;
	}


	//Clear the list
	//Do not delete the memory, but set it for re-use
	void Clear()
	{	numEntries=0;	}

	//Access a member of the list
	T & operator[](int index)
	{
		return entries[index];
	}

	const int & GetSize()
	{	return numEntries;	}

	//The list itself
	T * entries;

protected:
	//Number of entries in the list
	int numEntries;

	//Total size of list(including empty spaces)
	int listSize;

	//Increase the size of the list
	bool IncreaseSpace(int newSize)
	{
		//Create a new array of the new size
		T * tempList=new T[newSize];
		if(!tempList)
		{
			LOG::Instance()->OutputError("Unable to allocate space for list of %d entries", newSize);
			return false;
		}

		//Copy over the current indices if there are any
		if(numEntries!=0 && entries!=NULL)
			memcpy(tempList, entries, numEntries*sizeof(T));

		//delete the old list and point "elements" at the new array
		if(entries)
			delete [] entries;
		entries=tempList;

		//Update listSize
		listSize=newSize;

		return true;
	}

public:
	LIST()	:	numEntries(0), listSize(0), entries(NULL)
	{}
	~LIST()
	{
		if(entries)
			delete [] entries;
		entries=NULL;
	}

	//Need a deep copy constructor (to add to vectors etc)
	LIST(const LIST & rhs)
	{
		listSize=rhs.listSize;
		numEntries=rhs.numEntries;

		entries=new T[listSize];
		memcpy(entries, rhs.entries, listSize*sizeof(T));
	}

};

#endif	//LIST_H


