//////////////////////////////////////////////////////////////////////////////////////////
//	Standard Codepath/LightingPass0.cpp
//	Set/End states for standard codepath lighting pass 0 (attenuation)
//	Downloaded from: www.paulsprojects.net
//	Created:	13th December 2002
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <vector>
#include "../../GL files/glee.h"			//header for OpenGL 1.4
#include "../../Maths/Maths.h"
#include "../../Log/LOG.h"
#include "../../Bounding Volumes/Bounding Volumes.h"
#include "../../Render Manager/RENDER_MANAGER.h"
#include "../../Console/CONSOLE.h"
#include "../../Point Light/POINT_LIGHT.h"
#include "../CODEPATH_MANAGER.h"

bool STANDARD_CODEPATH::SetLightingPass0States(	const POINT_LIGHT * currentLight,
												const VECTOR3D & cameraPosition,
												DRAWING_STATES & drawingStates)
{
	//Bind and enable attenuation textures
	//Unit 0 - atten2D
	glBindTexture(GL_TEXTURE_2D, RENDER_MANAGER::Instance()->atten2DTexture);
	glEnable(GL_TEXTURE_2D);

	//Unit 1 - atten1D
	glActiveTexture(GL_TEXTURE1);
	glBindTexture(GL_TEXTURE_1D, RENDER_MANAGER::Instance()->atten1DTexture);
	glEnable(GL_TEXTURE_1D);
	glActiveTexture(GL_TEXTURE0);


	//Calculate the texture matrix for attenuation
	static MATRIX4X4 biasMatrix(0.5f, 0.0f, 0.0f, 0.0f,
								0.0f, 0.5f, 0.0f, 0.0f,
								0.0f, 0.0f, 0.5f, 0.0f,
								0.5f, 0.5f, 0.5f, 1.0f);
	
	static MATRIX4X4 scaleMatrix;
	scaleMatrix.SetUniformScale(1.0f/currentLight->boundingSphere.radius);

	static MATRIX4X4 translationMatrix;
	translationMatrix.SetTranslation(-currentLight->boundingSphere.centre);

	static MATRIX4X4 attenMatrix;
	attenMatrix=biasMatrix*scaleMatrix*translationMatrix;


	//Set up TexGen
	//Unit 0 takes (x, y) of attenuation in (s, t)
	glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);
	glTexGenfv(GL_S, GL_OBJECT_PLANE, attenMatrix.GetRow(0));
	glEnable(GL_TEXTURE_GEN_S);

	glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);
	glTexGenfv(GL_T, GL_OBJECT_PLANE, attenMatrix.GetRow(1));
	glEnable(GL_TEXTURE_GEN_T);

	//Unit 1 takes z of attenuation in s
	glActiveTexture(GL_TEXTURE1);
	glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);
	glTexGenfv(GL_S, GL_OBJECT_PLANE, attenMatrix.GetRow(2));
	glEnable(GL_TEXTURE_GEN_S);
	glActiveTexture(GL_TEXTURE0);


	//Set TexEnv: (tex0-tex1) in alpha only.
	//Set RGB texenv to replace with black
	glTexEnvfv(GL_TEXTURE_ENV, GL_TEXTURE_ENV_COLOR, black);
	
	//Unit 0 replaces with black in RGB
	glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_COMBINE);
	
	glTexEnvi(GL_TEXTURE_ENV, GL_SOURCE0_RGB, GL_CONSTANT);
	glTexEnvi(GL_TEXTURE_ENV, GL_COMBINE_RGB, GL_REPLACE);

	//Unit 0 replaces with tex0 in alpha
	glTexEnvi(GL_TEXTURE_ENV, GL_SOURCE0_ALPHA, GL_TEXTURE);
	glTexEnvi(GL_TEXTURE_ENV, GL_COMBINE_ALPHA, GL_REPLACE);


	
	glActiveTexture(GL_TEXTURE1);
	glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_COMBINE);

	//Unit 1 replaces with black in rgb
	glTexEnvi(GL_TEXTURE_ENV, GL_SOURCE0_RGB, GL_CONSTANT);
	glTexEnvi(GL_TEXTURE_ENV, GL_COMBINE_RGB, GL_REPLACE);

	//Unit 1 subtracts tex1 in alpha
	glTexEnvi(GL_TEXTURE_ENV, GL_SOURCE0_ALPHA, GL_PREVIOUS);
	glTexEnvi(GL_TEXTURE_ENV, GL_COMBINE_ALPHA, GL_SUBTRACT);
	glTexEnvi(GL_TEXTURE_ENV, GL_SOURCE1_ALPHA, GL_TEXTURE);

	glActiveTexture(GL_TEXTURE0);

	//Only draw where stencil is zero
	glStencilFunc(GL_EQUAL, 0, ~0);
	glStencilOp(GL_KEEP, GL_KEEP, GL_KEEP);
	glEnable(GL_STENCIL_TEST);


	//Only draw to alpha
	glColorMask(0, 0, 0, 1);
	

	//Fill in the drawing states
	drawingStates.useNormalArray=false;

	//vertex array units
	drawingStates.textureCoordUnit1=0;
	drawingStates.textureCoordUnit2=0;
	drawingStates.sTangentUnit=0;
	drawingStates.tTangentUnit=0;
	drawingStates.spareUnit=0;

	//texture units
	drawingStates.decalTextureUnit=0;
	drawingStates.emissiveTextureUnit=0;
	drawingStates.normalMapTextureUnit=0;

	drawingStates.drawNonGloss=true;
	
	return true;
}

void STANDARD_CODEPATH::EndLightingPass0(const POINT_LIGHT * currentLight)
{
	//Disable textures
	glDisable(GL_TEXTURE_2D);

	glActiveTexture(GL_TEXTURE1);
	glDisable(GL_TEXTURE_1D);
	glActiveTexture(GL_TEXTURE0);


	//Disable TexGen
	glDisable(GL_TEXTURE_GEN_S);
	glDisable(GL_TEXTURE_GEN_T);

	glActiveTexture(GL_TEXTURE1);
	glDisable(GL_TEXTURE_GEN_S);
	glActiveTexture(GL_TEXTURE0);


	//Reset TexEnv
	glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);

	glActiveTexture(GL_TEXTURE1);
	glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
	glActiveTexture(GL_TEXTURE0);

	//Reset color mask
	glColorMask(1, 1, 1, 1);

	glDisable(GL_STENCIL_TEST);
}