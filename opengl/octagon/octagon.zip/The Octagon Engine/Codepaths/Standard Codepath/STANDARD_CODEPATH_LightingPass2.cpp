//////////////////////////////////////////////////////////////////////////////////////////
//	Standard Codepath/LightingPass2.cpp
//	Set/End states for standard codepath lighting pass 2 (color modulation)
//	Downloaded from: www.paulsprojects.net
//	Created:	13th December 2002
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <vector>
#include "../../GL files/glee.h"			//header for OpenGL 1.4
#include "../../Maths/Maths.h"
#include "../../Log/LOG.h"
#include "../../Bounding Volumes/Bounding Volumes.h"
#include "../../Render Manager/RENDER_MANAGER.h"
#include "../../Console/CONSOLE.h"
#include "../../Point Light/POINT_LIGHT.h"
#include "../CODEPATH_MANAGER.h"

bool STANDARD_CODEPATH::SetLightingPass2States(	const POINT_LIGHT * currentLight,
												const VECTOR3D & cameraPosition,
												DRAWING_STATES & drawingStates)
{
	//If we have a projected cube map, enable texgen and set up texture matrix on unit 1
	if(currentLight->hasCubeMap)
	{
		glActiveTexture(GL_TEXTURE1);
	
		//Object linear texgen
		glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);
		glTexGenfv(GL_S, GL_OBJECT_PLANE, VECTOR4D(1.0f, 0.0f, 0.0f, 0.0f));
		glEnable(GL_TEXTURE_GEN_S);

		glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);
		glTexGenfv(GL_T, GL_OBJECT_PLANE, VECTOR4D(0.0f, 1.0f, 0.0f, 0.0f));
		glEnable(GL_TEXTURE_GEN_T);

		glTexGeni(GL_R, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);
		glTexGenfv(GL_R, GL_OBJECT_PLANE, VECTOR4D(0.0f, 0.0f, 1.0f, 0.0f));
		glEnable(GL_TEXTURE_GEN_R);

		//set up texture matrix to calculate light->vertex vector
		glMatrixMode(GL_TEXTURE);
		glLoadIdentity();
		VECTOR3D translation=-currentLight->boundingSphere.centre;
		glTranslatef(translation.x, translation.y, translation.z);
		glMatrixMode(GL_MODELVIEW);

		glActiveTexture(GL_TEXTURE0);
	}

	//Enable texture units
	//Unit 0 - decal texture
	glEnable(GL_TEXTURE_2D);

	//Unit 1 - If we have a projected cube map, bind and enable the cube map
	if(currentLight->hasCubeMap)
	{
		glActiveTexture(GL_TEXTURE1);
		RENDER_MANAGER::Instance()->BindCubeMapTexture(currentLight->cubeMapIndex);
		glEnable(GL_TEXTURE_CUBE_MAP);
		glActiveTexture(GL_TEXTURE0);
	}

	//Send the light's color to col0
	glColor4fv(currentLight->color);

	//Set TexEnv: col0*tex0(*tex1 if enabled)
	//This is the default!
	
	//Set blend to modulate with destination alpha & add to framefuffer
	glBlendFunc(GL_DST_ALPHA, GL_ONE);
	glEnable(GL_BLEND);

	//Only draw where stencil is zero
	glStencilFunc(GL_EQUAL, 0, ~0);
	glStencilOp(GL_KEEP, GL_KEEP, GL_KEEP);
	glEnable(GL_STENCIL_TEST);


	//Fill in the drawing states
	drawingStates.useNormalArray=false;

	//vertex array units
	drawingStates.textureCoordUnit1=GL_TEXTURE0;
	drawingStates.textureCoordUnit2=0;
	drawingStates.sTangentUnit=0;
	drawingStates.tTangentUnit=0;
	drawingStates.spareUnit=0;

	//texture units
	drawingStates.decalTextureUnit=GL_TEXTURE0;
	drawingStates.emissiveTextureUnit=0;
	drawingStates.normalMapTextureUnit=0;

	drawingStates.drawNonGloss=true;
	
	return true;
}

void STANDARD_CODEPATH::EndLightingPass2(const POINT_LIGHT * currentLight)
{
	//Disable texture units
	glDisable(GL_TEXTURE_2D);

	//Disable texgen if we have a cube map
	if(currentLight->hasCubeMap)
	{
		glActiveTexture(GL_TEXTURE1);
		
		glDisable(GL_TEXTURE_CUBE_MAP);

		glDisable(GL_TEXTURE_GEN_S);
		glDisable(GL_TEXTURE_GEN_T);
		glDisable(GL_TEXTURE_GEN_R);

		glMatrixMode(GL_TEXTURE);
		glLoadIdentity();
		glMatrixMode(GL_MODELVIEW);

		glActiveTexture(GL_TEXTURE0);
	}

	//reset color
	glColor4fv(white);

	//Reset TexEnv
	glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);

	//Disable blend
	glDisable(GL_BLEND);

	glDisable(GL_STENCIL_TEST);
}