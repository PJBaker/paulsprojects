//////////////////////////////////////////////////////////////////////////////////////////
//	STANDARD_CODEPATH.h
//	Class for the standard (no extensions) codepath
//	Downloaded from: www.paulsprojects.net
//	Created:	13th December 2002
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	

#ifndef STANDARD_CODEPATH_H
#define STANDARD_CODEPATH_H

class STANDARD_CODEPATH : public CODEPATH
{
public:
	//Init the codepath
	virtual bool Init();

	//Does this codepath require Tangent Space light vectors in spare?
	virtual bool AreTangentSpaceLightVectorsRequired()
	{	return true;	}

	//Lighting passes
	//Pass0 - attenuation
	virtual bool SetLightingPass0States(const POINT_LIGHT * currentLight,
										const VECTOR3D & cameraPosition,
										DRAWING_STATES & drawingStates);
	virtual void EndLightingPass0(const POINT_LIGHT * currentLight);

	//Pass1 - bump dot product
	virtual bool SetLightingPass1States(const POINT_LIGHT * currentLight,
										const VECTOR3D & cameraPosition,
										DRAWING_STATES & drawingStates);
	virtual void EndLightingPass1(const POINT_LIGHT * currentLight);


	//Pass2 - modulate with color, decal & cube map
	virtual bool SetLightingPass2States(const POINT_LIGHT * currentLight,
										const VECTOR3D & cameraPosition,
										DRAWING_STATES & drawingStates);
	virtual void EndLightingPass2(const POINT_LIGHT * currentLight);
	

	//No pass 3. Return false
	virtual bool SetLightingPass3States(const POINT_LIGHT * currentLight,
										const VECTOR3D & cameraPosition,
										DRAWING_STATES & drawingStates)
	{	return false;	}
	virtual void EndLightingPass3(const POINT_LIGHT * currentLight)
	{}
};

#endif	//CODEPATH_H
