//////////////////////////////////////////////////////////////////////////////////////////
//	Standard Codepath/LightingPass1.cpp
//	Set/End states for standard codepath lighting pass 1 (bump dp3 & self shadow)
//	Downloaded from: www.paulsprojects.net
//	Created:	13th December 2002
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <vector>
#include "../../GL files/glee.h"			//header for OpenGL 1.4
#include "../../Maths/Maths.h"
#include "../../Log/LOG.h"
#include "../../Bounding Volumes/Bounding Volumes.h"
#include "../../Render Manager/RENDER_MANAGER.h"
#include "../../Console/CONSOLE.h"
#include "../../Point Light/POINT_LIGHT.h"
#include "../CODEPATH_MANAGER.h"

bool STANDARD_CODEPATH::SetLightingPass1States(	const POINT_LIGHT * currentLight,
												const VECTOR3D & cameraPosition,
												DRAWING_STATES & drawingStates)
{
	//Enable texture units
	//Unit 0 - normal map
	glEnable(GL_TEXTURE_2D);

	//Unit 1 - normalisation cube map
	glActiveTexture(GL_TEXTURE1);
	glBindTexture(GL_TEXTURE_CUBE_MAP, RENDER_MANAGER::Instance()->normCubeMap);
	glEnable(GL_TEXTURE_CUBE_MAP);
	glActiveTexture(GL_TEXTURE0);

	//Set TexEnv: tex0 dot tex1
	//Unit 0 replaces with tex0
	glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_COMBINE);

	glTexEnvi(GL_TEXTURE_ENV, GL_SOURCE0_RGB, GL_TEXTURE);
	glTexEnvi(GL_TEXTURE_ENV, GL_COMBINE_RGB, GL_REPLACE);

	//Unit 1 dots previous with tex1
	glActiveTexture(GL_TEXTURE1);

	glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_COMBINE);

	glTexEnvi(GL_TEXTURE_ENV, GL_SOURCE0_RGB, GL_PREVIOUS);
	glTexEnvi(GL_TEXTURE_ENV, GL_COMBINE_RGB, GL_DOT3_RGBA);
	glTexEnvi(GL_TEXTURE_ENV, GL_SOURCE1_RGB, GL_TEXTURE);

	glActiveTexture(GL_TEXTURE0);


	//Set blend to modulate with destination alpha
	glBlendFunc(GL_DST_ALPHA, GL_ZERO);
	glEnable(GL_BLEND);

	//Only draw where stencil is zero
	glStencilFunc(GL_EQUAL, 0, ~0);
	glStencilOp(GL_KEEP, GL_KEEP, GL_KEEP);
	glEnable(GL_STENCIL_TEST);


	//Only draw to alpha
	glColorMask(0, 0, 0, 1);


	//Fill in the drawing states
	drawingStates.useNormalArray=false;

	//vertex array units
	drawingStates.textureCoordUnit1=GL_TEXTURE0;
	drawingStates.textureCoordUnit2=0;
	drawingStates.sTangentUnit=0;
	drawingStates.tTangentUnit=0;
	drawingStates.spareUnit=GL_TEXTURE1;

	//texture units
	drawingStates.decalTextureUnit=0;
	drawingStates.emissiveTextureUnit=0;
	drawingStates.normalMapTextureUnit=GL_TEXTURE0;

	drawingStates.drawNonGloss=true;
	
	return true;
}

void STANDARD_CODEPATH::EndLightingPass1(const POINT_LIGHT * currentLight)
{
	//Disable texture units
	glDisable(GL_TEXTURE_2D);

	glActiveTexture(GL_TEXTURE1);
	glDisable(GL_TEXTURE_CUBE_MAP);
	glActiveTexture(GL_TEXTURE0);

	//Reset TexEnv
	glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);

	glActiveTexture(GL_TEXTURE1);
	glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
	glActiveTexture(GL_TEXTURE0);

	//Disable blend
	glDisable(GL_BLEND);

	//Reset color mask
	glColorMask(1, 1, 1, 1);

	glDisable(GL_STENCIL_TEST);
}