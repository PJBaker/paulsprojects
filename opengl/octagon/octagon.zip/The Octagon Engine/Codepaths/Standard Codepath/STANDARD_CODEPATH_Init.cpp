//////////////////////////////////////////////////////////////////////////////////////////
//	Standard Codepath/Init.cpp
//	Inittiate the standard codepath
//	Downloaded from: www.paulsprojects.net
//	Created:	13th December 2002
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <vector>
#include "../../GL files/glee.h"			//header for OpenGL 1.4
#include "../../Maths/Maths.h"
#include "../../Log/LOG.h"
#include "../../Bounding Volumes/Bounding Volumes.h"
#include "../../Render Manager/RENDER_MANAGER.h"
#include "../../Console/CONSOLE.h"
#include "../../Point Light/POINT_LIGHT.h"
#include "../CODEPATH_MANAGER.h"

bool STANDARD_CODEPATH::Init()
{
	//Check for 2 texture units
	GLint maxTextureUnits;
	glGetIntegerv(GL_MAX_TEXTURE_UNITS, &maxTextureUnits);
	if(maxTextureUnits<2)
	{
		LOG::Instance()->OutputError("Standard Codepath requires at least 2 texture units");
		return false;
	}

	//Check for destination alpha
	GLint alphaBits;
	glGetIntegerv(GL_ALPHA_BITS, &alphaBits);
	if(alphaBits<8)
	{
		LOG::Instance()->OutputError("Standard Codepath requires an 8 bit destination alpha buffer");
		return false;
	}


	return true;
}
