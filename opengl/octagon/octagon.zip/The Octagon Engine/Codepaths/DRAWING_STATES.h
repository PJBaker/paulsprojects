//////////////////////////////////////////////////////////////////////////////////////////
//	DRAWING_STATES.h
//	Filled in by codepath state settings to tell the render manager how to draw
//	Downloaded from: www.paulsprojects.net
//	Created:	13th December 2002
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	

#ifndef DRAWING_STATES_H
#define DRAWING_STATES_H

class DRAWING_STATES
{
public:
	//Use the normal array?
	bool useNormalArray;

	//which texture units are vertex arrays sent to?
	GLenum textureCoordUnit1;
	GLenum textureCoordUnit2;
	GLenum sTangentUnit;
	GLenum tTangentUnit;
	GLenum spareUnit;

	//which texture units are textures bound to?
	GLenum decalTextureUnit;
	GLenum normalMapTextureUnit;
	GLenum emissiveTextureUnit;

	//Are we drawing geometry which does not have a gloss map?
	bool drawNonGloss;

	DRAWING_STATES()	:	useNormalArray(false),
							textureCoordUnit1(0),
							textureCoordUnit2(0),
							sTangentUnit(0),
							tTangentUnit(0),
							spareUnit(0),
							decalTextureUnit(0),
							emissiveTextureUnit(0),
							drawNonGloss(false)
	{}
	~DRAWING_STATES()
	{}
};

#endif	//DRAWING_STATES_H