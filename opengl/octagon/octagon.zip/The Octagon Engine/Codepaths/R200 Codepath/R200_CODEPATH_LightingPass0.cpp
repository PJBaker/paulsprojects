//////////////////////////////////////////////////////////////////////////////////////////
//	NV20 Codepath/LightingPass0.cpp
//	Set/End states for R200 codepath lighting pass 0
//	Do the lighting equation...
//	Downloaded from: www.paulsprojects.net
//	Created:	16th December 2002
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <vector>
#include "../../GL files/glee.h"			//header for OpenGL 1.4
#include "../../Maths/Maths.h"
#include "../../Log/LOG.h"
#include "../../Bounding Volumes/Bounding Volumes.h"
#include "../../Render Manager/RENDER_MANAGER.h"
#include "../../Console/CONSOLE.h"
#include "../../Point Light/POINT_LIGHT.h"
#include "../CODEPATH_MANAGER.h"

bool R200_CODEPATH::SetLightingPass0States(	const POINT_LIGHT * currentLight,
											const VECTOR3D & cameraPosition,
											DRAWING_STATES & drawingStates)
{
	//Set up matrix0 for attenuation
	glMatrixMode(GL_MATRIX0_ARB);
	glLoadIdentity();
	glTranslatef(0.5f, 0.5f, 0.5f);
	glScalef(0.5f, 0.5f, 0.5f);
	float scale=1.0f/currentLight->boundingSphere.radius;
	glScalef(scale, scale, scale);
	VECTOR3D translation=-currentLight->boundingSphere.centre;
	glTranslatef(translation.x, translation.y, translation.z);
	glMatrixMode(GL_MODELVIEW);


	//Send the light's color as col0
	glColor4fv(currentLight->color);


	//Bind and enable vertex program
	if(currentLight->hasCubeMap)
		glBindProgramARB(GL_VERTEX_PROGRAM_ARB, pass0WithCubeMapVP);
	else
		glBindProgramARB(GL_VERTEX_PROGRAM_ARB, pass0NoCubeMapVP);
	//Send the light's position as program local parameter 0, and camera position as 1
	glProgramLocalParameter4fvARB(GL_VERTEX_PROGRAM_ARB, 0, currentLight->boundingSphere.centre);
	glProgramLocalParameter4fvARB(GL_VERTEX_PROGRAM_ARB, 1, cameraPosition);
	glEnable(GL_VERTEX_PROGRAM_ARB);


	
	//Enable textures
	
	//unit 0 - decal
	glEnable(GL_TEXTURE_2D);
	
	//unit 1 - normal map
	glActiveTexture(GL_TEXTURE1);
	glEnable(GL_TEXTURE_2D);
	
	//unit 2 - none
	
	//unit 3 - normalisation cube map
	glActiveTexture(GL_TEXTURE3);
	glBindTexture(GL_TEXTURE_CUBE_MAP, RENDER_MANAGER::Instance()->normCubeMap);
	glEnable(GL_TEXTURE_CUBE_MAP);
	
	//unit 4 - light's projected cube map (if any), otherwise norm cube map
	glActiveTexture(GL_TEXTURE4);
	if(currentLight->hasCubeMap)
		RENDER_MANAGER::Instance()->BindCubeMapTexture(currentLight->cubeMapIndex);
	else
		glBindTexture(GL_TEXTURE_CUBE_MAP, RENDER_MANAGER::Instance()->normCubeMap);
	glEnable(GL_TEXTURE_CUBE_MAP);
	

	//unit 5 - specular ramp
	glActiveTexture(GL_TEXTURE5);
	glBindTexture(GL_TEXTURE_1D, specularRampTexture);
	glEnable(GL_TEXTURE_1D);
	glActiveTexture(GL_TEXTURE0);
	


	//Bind and enable fragment shader
	if(currentLight->hasCubeMap)
		glBindFragmentShaderATI(pass0WithCubeMapFS);
	else
		glBindFragmentShaderATI(pass0NoCubeMapFS);

	glEnable(GL_FRAGMENT_SHADER_ATI);

	//Enable additive blend
	glBlendFunc(GL_ONE, GL_ONE);
	glEnable(GL_BLEND);


	//Only draw where stencil is zero
	glStencilFunc(GL_EQUAL, 0, ~0);
	glStencilOp(GL_KEEP, GL_KEEP, GL_KEEP);
	glEnable(GL_STENCIL_TEST);


	//Fill in the drawing states
	drawingStates.useNormalArray=true;

	//vertex array units
	drawingStates.textureCoordUnit1=GL_TEXTURE0;
	drawingStates.textureCoordUnit2=0;
	drawingStates.sTangentUnit=GL_TEXTURE1;
	drawingStates.tTangentUnit=GL_TEXTURE2;
	drawingStates.spareUnit=0;

	//texture units
	drawingStates.decalTextureUnit=GL_TEXTURE0;
	drawingStates.emissiveTextureUnit=0;
	drawingStates.normalMapTextureUnit=GL_TEXTURE1;

	drawingStates.drawNonGloss=true;

	return true;
}

void R200_CODEPATH::EndLightingPass0(const POINT_LIGHT * currentLight)
{
	glMatrixMode(GL_MATRIX0_ARB);
	glLoadIdentity();
	glMatrixMode(GL_MODELVIEW);

	glColor4fv(white);

	glDisable(GL_VERTEX_PROGRAM_ARB);

	//Disable textures
	glDisable(GL_TEXTURE_2D);
		
	glActiveTexture(GL_TEXTURE1);
	glDisable(GL_TEXTURE_2D);
	
	glActiveTexture(GL_TEXTURE3);
	glDisable(GL_TEXTURE_CUBE_MAP);
	
	glActiveTexture(GL_TEXTURE4);
	glDisable(GL_TEXTURE_CUBE_MAP);
	
	glActiveTexture(GL_TEXTURE5);
	glDisable(GL_TEXTURE_1D);
	glActiveTexture(GL_TEXTURE0);
	
	glDisable(GL_FRAGMENT_SHADER_ATI);
	
	glDisable(GL_BLEND);

	glDisable(GL_STENCIL_TEST);	
}
