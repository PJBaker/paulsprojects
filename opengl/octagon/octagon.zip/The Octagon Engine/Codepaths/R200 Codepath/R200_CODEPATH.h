//////////////////////////////////////////////////////////////////////////////////////////
//	R200_CODEPATH.h
//	Class for R200 (Radeon 8500/9000) codepath
//	Downloaded from: www.paulsprojects.net
//	Created:	6th February 2003
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	

#ifndef R200_CODEPATH_H
#define R200_CODEPATH_H

class R200_CODEPATH : public CODEPATH
{
public:
	//Init the codepath
	virtual bool Init();

	//Does this codepath require Tangent Space light vectors in spare?
	virtual bool AreTangentSpaceLightVectorsRequired()
	{	return false;	}

	//Lighting passes
	//Pass0. Do the whole equation!
	virtual bool SetLightingPass0States(const POINT_LIGHT * currentLight,
										const VECTOR3D & cameraPosition,
										DRAWING_STATES & drawingStates);
	virtual void EndLightingPass0(const POINT_LIGHT * currentLight);

	//No pass 1. Return false
	virtual bool SetLightingPass1States(const POINT_LIGHT * currentLight,
										const VECTOR3D & cameraPosition,
										DRAWING_STATES & drawingStates)
	{	return false;	}
	virtual void EndLightingPass1(const POINT_LIGHT * currentLight)
	{}


	//No pass 2. Return false
	virtual bool SetLightingPass2States(const POINT_LIGHT * currentLight,
										const VECTOR3D & cameraPosition,
										DRAWING_STATES & drawingStates)
	{	return false;	}
	virtual void EndLightingPass2(const POINT_LIGHT * currentLight)
	{}

	//vertex program
	GLuint pass2VP;
	

	//No pass 3. Return false
	virtual bool SetLightingPass3States(const POINT_LIGHT * currentLight,
										const VECTOR3D & cameraPosition,
										DRAWING_STATES & drawingStates)
	{	return false;	}
	virtual void EndLightingPass3(const POINT_LIGHT * currentLight)
	{}

protected:
	//vertex programs & fragment shaders
	GLuint pass0NoCubeMapVP;
	GLuint pass0NoCubeMapFS;

	GLuint pass0WithCubeMapVP;
	GLuint pass0WithCubeMapFS;

	//specular ramp texture
	GLuint specularRampTexture;
};

#endif	//CODEPATH_H
