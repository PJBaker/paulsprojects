//////////////////////////////////////////////////////////////////////////////////////////
//	R200 Codepath/Init.cpp
//	Initiate the R200 codepath
//	Downloaded from: www.paulsprojects.net
//	Created:	13th December 2002
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <vector>
#include "../../GL files/glee.h"			//header for OpenGL 1.4
#include "../../GL files/ARB_program.h"
#include "../../Maths/Maths.h"
#include "../../Log/LOG.h"
#include "../../Bounding Volumes/Bounding Volumes.h"
#include "../../Render Manager/RENDER_MANAGER.h"
#include "../../Console/CONSOLE.h"
#include "../../Point Light/POINT_LIGHT.h"
#include "../CODEPATH_MANAGER.h"

bool R200_CODEPATH::Init()
{
	//We can assume 8 bit destination alpha and 2 texture units,
	//since the standard codepath MUST be supported

	//Check for 6 texture units
	GLint maxTextureUnits;
	glGetIntegerv(GL_MAX_TEXTURE_UNITS, &maxTextureUnits);
	if(maxTextureUnits<6)
	{
		LOG::Instance()->OutputError("R200 Codepath requires at least 6 texture units");
		return false;
	}

	//Check for extensions
	if(!GLEE_ARB_vertex_program || !GLEE_ATI_fragment_shader)
	{
		LOG::Instance()->OutputError("R200 Codepath requires ARB_vertex program");
		LOG::Instance()->OutputError("and ATI_fragment_shader extensions");
		return false;
	}

	//Load the vertex programs
	glGenProgramsARB(1, &pass0NoCubeMapVP);
	glBindProgramARB(GL_VERTEX_PROGRAM_ARB, pass0NoCubeMapVP);
	if(!LoadARB_program(GL_VERTEX_PROGRAM_ARB, "Codepaths/R200 Codepath/pass0NoCubeMapVP.txt"))
		return false;

	glGenProgramsARB(1, &pass0WithCubeMapVP);
	glBindProgramARB(GL_VERTEX_PROGRAM_ARB, pass0WithCubeMapVP);
	if(!LoadARB_program(GL_VERTEX_PROGRAM_ARB, "Codepaths/R200 Codepath/pass0WithCubeMapVP.txt"))
		return false;

	//Create the specular ramp texture
	int rampSize=256;
	GLubyte * rampData=new GLubyte[rampSize];
	if(!rampData)
	{
		LOG::Instance()->OutputError("Unable to allocate space for specular ramp data");
		return false;
	}

	for(int i=0; i<rampSize; ++i)
	{
		float brightness=(float)i/(rampSize-1);
		brightness=powf(brightness, 16.0f);
		
		rampData[i]=GLubyte(255*brightness);
	}

	glGenTextures(1, &specularRampTexture);
	glBindTexture(GL_TEXTURE_1D, specularRampTexture);

	glTexParameteri(GL_TEXTURE_1D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
	glTexParameteri(GL_TEXTURE_1D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
	glTexParameteri(GL_TEXTURE_1D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_1D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);

	glTexImage1D(	GL_TEXTURE_1D, 0, GL_INTENSITY8, rampSize, 0, GL_LUMINANCE,
					GL_UNSIGNED_BYTE, rampData);

	if(rampData)
		delete [] rampData;
	rampData=NULL;

	

	//Create the fragment shaders

	//With cube map
	//Texture Unit			0		1			2			3			4			5

	//Texture Image			decal	normal map	none		norm cube	projected	specular ramp
	//Texture Coords		decal	decal		attenuation	H			projected	L
	
	pass0WithCubeMapFS=glGenFragmentShadersATI(1);
	glBindFragmentShaderATI(pass0WithCubeMapFS);
	{
		glBeginFragmentShaderATI();
		{
			//PHASE 1
			//Sample N and H into regs 1 and 3
			glSampleMapATI(GL_REG_1_ATI, GL_TEXTURE1, GL_SWIZZLE_STR_ATI);
			glSampleMapATI(GL_REG_3_ATI, GL_TEXTURE3, GL_SWIZZLE_STR_ATI);

			//Pass through attenuation coords and L, into regs 2 and 5
			glPassTexCoordATI(GL_REG_2_ATI, GL_TEXTURE2, GL_SWIZZLE_STR_ATI);
			glPassTexCoordATI(GL_REG_5_ATI, GL_TEXTURE5, GL_SWIZZLE_STR_ATI);

			//Do attenuation calculations. reg2=sat(1-(reg2 dot reg2))
			glColorFragmentOp2ATI(	GL_DOT3_ATI,
									GL_REG_2_ATI, GL_NONE, GL_NONE,
									GL_REG_2_ATI, GL_NONE, GL_BIAS_BIT_ATI | GL_2X_BIT_ATI,
									GL_REG_2_ATI, GL_NONE, GL_BIAS_BIT_ATI | GL_2X_BIT_ATI);
			glColorFragmentOp1ATI(	GL_MOV_ATI,
									GL_REG_2_ATI, GL_NONE, GL_SATURATE_BIT_ATI,
									GL_REG_2_ATI, GL_NONE, GL_COMP_BIT_ATI);

			//move L to reg4 as temporary
			glColorFragmentOp1ATI(	GL_MOV_ATI,
									GL_REG_4_ATI, GL_NONE, GL_NONE,
									GL_REG_5_ATI, GL_NONE, GL_NONE);

			//Do specular dot product. reg5=N.H
			glColorFragmentOp2ATI(	GL_DOT3_ATI,
									GL_REG_5_ATI, GL_NONE, GL_NONE,
									GL_REG_1_ATI, GL_NONE, GL_BIAS_BIT_ATI | GL_2X_BIT_ATI,
									GL_REG_3_ATI, GL_NONE, GL_BIAS_BIT_ATI | GL_2X_BIT_ATI);

			//Multiply N.H by gloss. Recall gloss is stored as 1-gloss in normal map alpha
			glColorFragmentOp2ATI(	GL_MUL_ATI,
									GL_REG_5_ATI, GL_NONE, GL_NONE,
									GL_REG_5_ATI, GL_NONE, GL_NONE,
									GL_REG_1_ATI, GL_ALPHA, GL_COMP_BIT_ATI);

			//Move L to reg3
			glColorFragmentOp1ATI(	GL_MOV_ATI,
									GL_REG_3_ATI, GL_NONE, GL_NONE,
									GL_REG_4_ATI, GL_NONE, GL_NONE);
			
			//result:
			//Texture Unit			0		1		2			3		4		5
			//Registers:			?		?		attenuation	L		?		N.H

			//PHASE 2
			//Sample decal map & normal map to reg 0 and 1
			glSampleMapATI(GL_REG_0_ATI, GL_TEXTURE0, GL_SWIZZLE_STR_ATI);
			glSampleMapATI(GL_REG_1_ATI, GL_TEXTURE1, GL_SWIZZLE_STR_ATI);
			
			//Pass through attenuation for unit 2
			glPassTexCoordATI(GL_REG_2_ATI, GL_REG_2_ATI, GL_SWIZZLE_STR_ATI);

			//Dependent read norm cube map for L
			glSampleMapATI(GL_REG_3_ATI, GL_REG_3_ATI, GL_SWIZZLE_STR_ATI);

			//Sample projected cube map for 4
			glSampleMapATI(GL_REG_4_ATI, GL_TEXTURE4, GL_SWIZZLE_STR_ATI);

			//Dependent read specular ramp from N.H to 5
			glSampleMapATI(GL_REG_5_ATI, GL_REG_5_ATI, GL_SWIZZLE_STR_ATI);

			//Do diffuse dot product. Reg1=N.L
			glColorFragmentOp2ATI(	GL_DOT3_ATI,
									GL_REG_1_ATI, GL_NONE, GL_NONE,
									GL_REG_1_ATI, GL_NONE, GL_BIAS_BIT_ATI | GL_2X_BIT_ATI,
									GL_REG_3_ATI, GL_NONE, GL_BIAS_BIT_ATI | GL_2X_BIT_ATI);

			//Combine difuse and specular
			//reg0=decal*(N.L)+(N.H^power)
			glColorFragmentOp3ATI(	GL_MAD_ATI,
									GL_REG_0_ATI, GL_NONE, GL_NONE,
									GL_REG_0_ATI, GL_NONE, GL_NONE,
									GL_REG_1_ATI, GL_NONE, GL_NONE,
									GL_REG_5_ATI, GL_NONE, GL_NONE);

			//Multiply this by the attenuation (reg2), the cube map (reg4) and the color (col0)
			glColorFragmentOp2ATI(	GL_MUL_ATI,
									GL_REG_0_ATI, GL_NONE, GL_NONE,
									GL_REG_0_ATI, GL_NONE, GL_NONE,
									GL_REG_2_ATI, GL_NONE, GL_NONE);
			glColorFragmentOp2ATI(	GL_MUL_ATI,
									GL_REG_0_ATI, GL_NONE, GL_NONE,
									GL_REG_0_ATI, GL_NONE, GL_NONE,
									GL_REG_4_ATI, GL_NONE, GL_NONE);
			glColorFragmentOp2ATI(	GL_MUL_ATI,
									GL_REG_0_ATI, GL_NONE, GL_NONE,
									GL_REG_0_ATI, GL_NONE, GL_NONE,
									GL_PRIMARY_COLOR, GL_NONE, GL_NONE);
			
		}
		glEndFragmentShaderATI();
	}



	//No cube map
	
	//Texture Unit			0		1			2			3			4			5

	//Texture Image			decal	normal map	none		norm cube	norm cube	specular ramp
	//Texture Coords		decal	decal		attenuation	H			L			none

	pass0NoCubeMapFS=glGenFragmentShadersATI(1);
	glBindFragmentShaderATI(pass0NoCubeMapFS);
	{
		glBeginFragmentShaderATI();
		{
			//PHASE 1
			//Sample N and H into regs 1 and 3
			glSampleMapATI(GL_REG_1_ATI, GL_TEXTURE1, GL_SWIZZLE_STR_ATI);
			glSampleMapATI(GL_REG_3_ATI, GL_TEXTURE3, GL_SWIZZLE_STR_ATI);

			//Pass through attenuation coords into reg 2
			glPassTexCoordATI(GL_REG_2_ATI, GL_TEXTURE2, GL_SWIZZLE_STR_ATI);
			
			//Do attenuation calculations. reg2=sat(1-(reg2 dot reg2))
			glColorFragmentOp2ATI(	GL_DOT3_ATI,
									GL_REG_2_ATI, GL_NONE, GL_NONE,
									GL_REG_2_ATI, GL_NONE, GL_BIAS_BIT_ATI | GL_2X_BIT_ATI,
									GL_REG_2_ATI, GL_NONE, GL_BIAS_BIT_ATI | GL_2X_BIT_ATI);
			glColorFragmentOp1ATI(	GL_MOV_ATI,
									GL_REG_2_ATI, GL_NONE, GL_SATURATE_BIT_ATI,
									GL_REG_2_ATI, GL_NONE, GL_COMP_BIT_ATI);

			//Do specular dot product. reg5=N.H
			glColorFragmentOp2ATI(	GL_DOT3_ATI,
									GL_REG_5_ATI, GL_NONE, GL_NONE,
									GL_REG_1_ATI, GL_NONE, GL_BIAS_BIT_ATI | GL_2X_BIT_ATI,
									GL_REG_3_ATI, GL_NONE, GL_BIAS_BIT_ATI | GL_2X_BIT_ATI);

			//Multiply N.H by gloss. Recall gloss is stored as 1-gloss in normal map alpha
			glColorFragmentOp2ATI(	GL_MUL_ATI,
									GL_REG_5_ATI, GL_NONE, GL_NONE,
									GL_REG_5_ATI, GL_NONE, GL_NONE,
									GL_REG_1_ATI, GL_ALPHA, GL_COMP_BIT_ATI);

			//result:
			//Texture Unit			0		1		2			3		4		5
			//Registers:			?		?		attenuation	?		?		N.H

			//PHASE 2
			//Sample decal map & normal map to reg 0 and 1
			glSampleMapATI(GL_REG_0_ATI, GL_TEXTURE0, GL_SWIZZLE_STR_ATI);
			glSampleMapATI(GL_REG_1_ATI, GL_TEXTURE1, GL_SWIZZLE_STR_ATI);
			
			//Pass through attenuation for unit 2
			glPassTexCoordATI(GL_REG_2_ATI, GL_REG_2_ATI, GL_SWIZZLE_STR_ATI);

			//Sample norm cube map for L
			glSampleMapATI(GL_REG_4_ATI, GL_TEXTURE4_ARB, GL_SWIZZLE_STR_ATI);

			//Dependent read specular ramp from N.H to 5
			glSampleMapATI(GL_REG_5_ATI, GL_REG_5_ATI, GL_SWIZZLE_STR_ATI);

			//Do diffuse dot product. Reg1=N.L
			glColorFragmentOp2ATI(	GL_DOT3_ATI,
									GL_REG_1_ATI, GL_NONE, GL_NONE,
									GL_REG_1_ATI, GL_NONE, GL_BIAS_BIT_ATI | GL_2X_BIT_ATI,
									GL_REG_4_ATI, GL_NONE, GL_BIAS_BIT_ATI | GL_2X_BIT_ATI);

			//Combine difuse and specular
			//reg0=decal*(N.L)+(N.H^power)
			glColorFragmentOp3ATI(	GL_MAD_ATI,
									GL_REG_0_ATI, GL_NONE, GL_NONE,
									GL_REG_0_ATI, GL_NONE, GL_NONE,
									GL_REG_1_ATI, GL_NONE, GL_NONE,
									GL_REG_5_ATI, GL_NONE, GL_NONE);

			//Multiply this by the attenuation (reg2) and the color (col0)
			glColorFragmentOp2ATI(	GL_MUL_ATI,
									GL_REG_0_ATI, GL_NONE, GL_NONE,
									GL_REG_0_ATI, GL_NONE, GL_NONE,
									GL_REG_2_ATI, GL_NONE, GL_NONE);
			glColorFragmentOp2ATI(	GL_MUL_ATI,
									GL_REG_0_ATI, GL_NONE, GL_NONE,
									GL_REG_0_ATI, GL_NONE, GL_NONE,
									GL_PRIMARY_COLOR, GL_NONE, GL_NONE);
			
		}
		glEndFragmentShaderATI();
	}
	

	return true;
}
