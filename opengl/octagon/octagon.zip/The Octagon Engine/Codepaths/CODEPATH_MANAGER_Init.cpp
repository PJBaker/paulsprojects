//////////////////////////////////////////////////////////////////////////////////////////
//	CODEPATH_MANAGER_Init.cpp
//	Initiate the codepath manager
//	Downloaded from: www.paulsprojects.net
//	Created:	16th December 2002
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <vector>
#include "../GL files/glee.h"			//header for OpenGL 1.4
#include "../Maths/Maths.h"
#include "../Log/LOG.h"
#include "../Bounding Volumes/Bounding Volumes.h"
#include "../Render Manager/RENDER_MANAGER.h"
#include "../Console/CONSOLE.h"
#include "../Point Light/POINT_LIGHT.h"
#include "CODEPATH_MANAGER.h"

bool CODEPATH_MANAGER::Init()
{
	//Init the codepaths
	if(!standardCodepath.Init())
	{
		LOG::Instance()->OutputError("Standard codepath not supported");
		return false;
	}
	else
		LOG::Instance()->OutputSuccess("Standard Codepath Supported");

	
	nv20CodepathSupported=nv20Codepath.Init();
	
	if(!nv20CodepathSupported)
		LOG::Instance()->OutputError("NV20 Codepath not supported");
	else
		LOG::Instance()->OutputSuccess("NV20 Codepath Supported");

	
	r200CodepathSupported=r200Codepath.Init();
	
	if(!r200CodepathSupported)
		LOG::Instance()->OutputError("R200 Codepath not supported");
	else
		LOG::Instance()->OutputSuccess("R200 Codepath Supported");

	//Point codepath at the codepath to begin with
	if(nv20CodepathSupported)
	{
		codepathType=CODEPATH_TYPE_NV20;
		codepath=&nv20Codepath;
	}
	else if(r200CodepathSupported)
	{
		codepathType=CODEPATH_TYPE_R200;
		codepath=&r200Codepath;
	}
	else
	{
		codepathType=CODEPATH_TYPE_STANDARD;
		codepath=&standardCodepath;
	}

	return true;
}