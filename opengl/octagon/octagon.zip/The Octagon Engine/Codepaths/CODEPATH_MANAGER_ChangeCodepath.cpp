//////////////////////////////////////////////////////////////////////////////////////////
//	CODEPATH_MANAGER_ChangeCodepath.cpp
//	Change codepath
//	Downloaded from: www.paulsprojects.net
//	Created:	12th February 2003
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <vector>
#include "../GL files/glee.h"			//header for OpenGL 1.4
#include "../Maths/Maths.h"
#include "../Log/LOG.h"
#include "../Bounding Volumes/Bounding Volumes.h"
#include "../Render Manager/RENDER_MANAGER.h"
#include "../Console/CONSOLE.h"
#include "../Point Light/POINT_LIGHT.h"
#include "CODEPATH_MANAGER.h"

bool CODEPATH_MANAGER::ChangeCodepath(int newCodepath)
{
	if(newCodepath==0)
	{
		codepath=&standardCodepath;
		codepathType=CODEPATH_TYPE_STANDARD;
		return true;
	}

	if(newCodepath==1)
	{
		if(nv20CodepathSupported)
		{
			codepath=&nv20Codepath;
			codepathType=CODEPATH_TYPE_NV20;
			return true;
		}
		else
			return false;
	}

	if(newCodepath==2)
	{
		if(r200CodepathSupported)
		{
			codepath=&r200Codepath;
			codepathType=CODEPATH_TYPE_R200;
			return true;
		}
		else
			return false;
	}

	return false;
}