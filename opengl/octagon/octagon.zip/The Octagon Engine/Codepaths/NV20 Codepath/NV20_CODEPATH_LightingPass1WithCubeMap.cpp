//////////////////////////////////////////////////////////////////////////////////////////
//	NV20 Codepath/LightingPass1WithCubeMap.cpp
//	Set/End states for NV20 codepath lighting pass 1 if the light has a cube map (diffuse)
//	Downloaded from: www.paulsprojects.net
//	Created:	16th December 2002
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <vector>
#include "../../GL files/glee.h"			//header for OpenGL 1.4
#include "../../Maths/Maths.h"
#include "../../Log/LOG.h"
#include "../../Bounding Volumes/Bounding Volumes.h"
#include "../../Render Manager/RENDER_MANAGER.h"
#include "../../Console/CONSOLE.h"
#include "../../Point Light/POINT_LIGHT.h"
#include "../CODEPATH_MANAGER.h"

bool NV20_CODEPATH::SetLightingPass1WithCubeMapStates(	const POINT_LIGHT * currentLight,
														const VECTOR3D & cameraPosition,
														DRAWING_STATES & drawingStates)
{
	//Send the light's color as col0
	glColor4fv(currentLight->color);

	//Bind and enable vertex program
	glBindProgramARB(GL_VERTEX_PROGRAM_ARB, pass1WithCubeMapVP);
	//Send the light's position as program local parameter 0
	glProgramLocalParameter4fvARB(GL_VERTEX_PROGRAM_ARB, 0, currentLight->boundingSphere.centre);
	glEnable(GL_VERTEX_PROGRAM_ARB);


	//Set up  and enable textures
	//unit 0 - decal
	glEnable(GL_TEXTURE_2D);

	//unit 1 - normal map
	glActiveTexture(GL_TEXTURE1);
	glEnable(GL_TEXTURE_2D);
	
	//unit 2 - light's projected cube map
	glActiveTexture(GL_TEXTURE2);
	glEnable(GL_TEXTURE_CUBE_MAP);
	RENDER_MANAGER::Instance()->BindCubeMapTexture(currentLight->cubeMapIndex);

	//unit 3 - normalisation cube map
	glActiveTexture(GL_TEXTURE3);
	glEnable(GL_TEXTURE_CUBE_MAP);
	glBindTexture(GL_TEXTURE_CUBE_MAP, RENDER_MANAGER::Instance()->normCubeMap);
	glActiveTexture(GL_TEXTURE0);

	
	//Set up register combiners:		  tex1 dot tex3		for bump map
	//									* tex0 * col0 * tex2
	glCombinerParameteriNV(GL_NUM_GENERAL_COMBINERS_NV, 2);

	//Combiner 0 does	tex3 dot tex1 -> spare0
	glCombinerInputNV(	GL_COMBINER0_NV, GL_RGB, GL_VARIABLE_A_NV, GL_TEXTURE3,
						GL_EXPAND_NORMAL_NV, GL_RGB);
	glCombinerInputNV(	GL_COMBINER0_NV, GL_RGB, GL_VARIABLE_B_NV, GL_TEXTURE1,
						GL_EXPAND_NORMAL_NV, GL_RGB);
	glCombinerOutputNV(	GL_COMBINER0_NV, GL_RGB, GL_SPARE0_NV, GL_DISCARD_NV, GL_DISCARD_NV,
						GL_NONE, GL_NONE, true, false, false);

	//Combiner 1 does	spare0*tex0 -> spare0
	glCombinerInputNV(	GL_COMBINER1_NV, GL_RGB, GL_VARIABLE_A_NV, GL_SPARE0_NV,
						GL_UNSIGNED_IDENTITY_NV, GL_RGB);
	glCombinerInputNV(	GL_COMBINER1_NV, GL_RGB, GL_VARIABLE_B_NV, GL_TEXTURE0,
						GL_UNSIGNED_IDENTITY_NV, GL_RGB);
	glCombinerOutputNV(	GL_COMBINER1_NV, GL_RGB, GL_SPARE0_NV, GL_DISCARD_NV, GL_DISCARD_NV,
						GL_NONE, GL_NONE, false, false, false);

	//Final combiner outputs spare0*tex2*col0
	//first do tex2*col0 in the EF multiplier
	glFinalCombinerInputNV(GL_VARIABLE_E_NV, GL_TEXTURE2, GL_UNSIGNED_IDENTITY_NV, GL_RGB);
	glFinalCombinerInputNV(GL_VARIABLE_F_NV, GL_PRIMARY_COLOR_NV, GL_UNSIGNED_IDENTITY_NV, GL_RGB);

	glFinalCombinerInputNV(GL_VARIABLE_A_NV, GL_SPARE0_NV, GL_UNSIGNED_IDENTITY_NV, GL_RGB);
	glFinalCombinerInputNV(GL_VARIABLE_B_NV, GL_E_TIMES_F_NV, GL_UNSIGNED_IDENTITY_NV, GL_RGB);
	glFinalCombinerInputNV(GL_VARIABLE_C_NV, GL_ZERO, GL_UNSIGNED_IDENTITY_NV, GL_RGB);
	glFinalCombinerInputNV(GL_VARIABLE_D_NV, GL_ZERO, GL_UNSIGNED_IDENTITY_NV, GL_RGB);

	//Enable register combiners
	glEnable(GL_REGISTER_COMBINERS_NV);

	
	//Enable blend - modulate with dest. alpha and add
	glBlendFunc(GL_DST_ALPHA, GL_ONE);
	glEnable(GL_BLEND);

	//Only draw where stencil is zero
	glStencilFunc(GL_EQUAL, 0, ~0);
	glStencilOp(GL_KEEP, GL_KEEP, GL_KEEP);
	glEnable(GL_STENCIL_TEST);


	//Fill in the drawing states
	drawingStates.useNormalArray=true;

	//vertex array units
	drawingStates.textureCoordUnit1=GL_TEXTURE0;
	drawingStates.textureCoordUnit2=0;
	drawingStates.sTangentUnit=GL_TEXTURE1;
	drawingStates.tTangentUnit=GL_TEXTURE2;
	drawingStates.spareUnit=0;

	//texture units
	drawingStates.decalTextureUnit=GL_TEXTURE0;
	drawingStates.emissiveTextureUnit=0;
	drawingStates.normalMapTextureUnit=GL_TEXTURE1;

	drawingStates.drawNonGloss=true;
	
	return true;
}

void NV20_CODEPATH::EndLightingPass1WithCubeMap(const POINT_LIGHT * currentLight)
{
	glColor4fv(white);

	//Disable vertex program
	glDisable(GL_VERTEX_PROGRAM_ARB);

	//Disable textures
	glDisable(GL_TEXTURE_2D);

	glActiveTexture(GL_TEXTURE1);
	glDisable(GL_TEXTURE_2D);
	
	glActiveTexture(GL_TEXTURE2);
	glDisable(GL_TEXTURE_CUBE_MAP);
	
	glActiveTexture(GL_TEXTURE3);
	glDisable(GL_TEXTURE_CUBE_MAP);
	glActiveTexture(GL_TEXTURE0);

	
	//Disable register combiners
	glDisable(GL_REGISTER_COMBINERS_NV);

	//Disable blend
	glDisable(GL_BLEND);

	glDisable(GL_STENCIL_TEST);
}