//////////////////////////////////////////////////////////////////////////////////////////
//	NV20_CODEPATH.h
//	Class for NV20 (GF3) codepath
//	Downloaded from: www.paulsprojects.net
//	Created:	16th December 2002
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	

#ifndef NV20_CODEPATH_H
#define NV20_CODEPATH_H

class NV20_CODEPATH : public CODEPATH
{
public:
	//Init the codepath
	virtual bool Init();

	//Does this codepath require Tangent Space light vectors in spare?
	virtual bool AreTangentSpaceLightVectorsRequired()
	{	return false;	}

	//Lighting passes
	//Pass0. Sent to Pass0WithCubeMap or Pass0NoCubeMap depending on whether the light has a
	//cube map
	virtual bool SetLightingPass0States(const POINT_LIGHT * currentLight,
										const VECTOR3D & cameraPosition,
										DRAWING_STATES & drawingStates);
	virtual void EndLightingPass0(const POINT_LIGHT * currentLight);

	//Pass1. If a cube map, call Pass1WithCubeMap. Otherwise return false;
	virtual bool SetLightingPass1States(const POINT_LIGHT * currentLight,
										const VECTOR3D & cameraPosition,
										DRAWING_STATES & drawingStates);
	virtual void EndLightingPass1(const POINT_LIGHT * currentLight);


	//Pass2. Specular
	virtual bool SetLightingPass2States(const POINT_LIGHT * currentLight,
										const VECTOR3D & cameraPosition,
										DRAWING_STATES & drawingStates);
	virtual void EndLightingPass2(const POINT_LIGHT * currentLight);

	//vertex program
	GLuint pass2VP;
	

	//No pass 3. Return false
	virtual bool SetLightingPass3States(const POINT_LIGHT * currentLight,
										const VECTOR3D & cameraPosition,
										DRAWING_STATES & drawingStates)
	{	return false;	}
	virtual void EndLightingPass3(const POINT_LIGHT * currentLight)
	{}

protected:
	//pass 0 if the light has no cube map. Do entire diffuse
	virtual bool SetLightingPass0NoCubeMapStates(	const POINT_LIGHT * currentLight,
													const VECTOR3D & cameraPosition,
													DRAWING_STATES & drawingStates);
	virtual void EndLightingPass0NoCubeMap(const POINT_LIGHT * currentLight);

	//vertex program for this pass
	GLuint pass0NoCubeMapVP;


	//pass 0 if the light has a projected cube map. Store attenuation in alpha
	virtual bool SetLightingPass0WithCubeMapStates(	const POINT_LIGHT * currentLight,
													const VECTOR3D & cameraPosition,
													DRAWING_STATES & drawingStates);
	
	virtual void EndLightingPass0WithCubeMap(const POINT_LIGHT * currentLight);


	//pass 1 if the light has a projected cube map. Complete the diffuse equation
	virtual bool SetLightingPass1WithCubeMapStates(	const POINT_LIGHT * currentLight,
													const VECTOR3D & cameraPosition,
													DRAWING_STATES & drawingStates);
	
	virtual void EndLightingPass1WithCubeMap(const POINT_LIGHT * currentLight);

	//Vertex program
	GLuint pass1WithCubeMapVP;
};

#endif	//CODEPATH_H
