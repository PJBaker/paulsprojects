//////////////////////////////////////////////////////////////////////////////////////////
//	NV20 Codepath/LightingPass0.cpp
//	Set/End states for NV20 codepath lighting pass 0
//	Call one of 2 functions based on whether the light has a projected cube map
//	Downloaded from: www.paulsprojects.net
//	Created:	16th December 2002
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <vector>
#include "../../GL files/glee.h"			//header for OpenGL 1.4
#include "../../Maths/Maths.h"
#include "../../Log/LOG.h"
#include "../../Bounding Volumes/Bounding Volumes.h"
#include "../../Render Manager/RENDER_MANAGER.h"
#include "../../Console/CONSOLE.h"
#include "../../Point Light/POINT_LIGHT.h"
#include "../CODEPATH_MANAGER.h"

bool NV20_CODEPATH::SetLightingPass0States(	const POINT_LIGHT * currentLight,
											const VECTOR3D & cameraPosition,
											DRAWING_STATES & drawingStates)
{
	//If no cube map, call Pass1NoCubeMap. Does entire diffuse equation
	if(!currentLight->hasCubeMap)
		return SetLightingPass0NoCubeMapStates(currentLight, cameraPosition, drawingStates);
	else
		//if a cube map, simply store attenuation in alpha
		return SetLightingPass0WithCubeMapStates(currentLight, cameraPosition, drawingStates);
}

void NV20_CODEPATH::EndLightingPass0(const POINT_LIGHT * currentLight)
{
	if(!currentLight->hasCubeMap)
		EndLightingPass0NoCubeMap(currentLight);
	else
		EndLightingPass0WithCubeMap(currentLight);
}
