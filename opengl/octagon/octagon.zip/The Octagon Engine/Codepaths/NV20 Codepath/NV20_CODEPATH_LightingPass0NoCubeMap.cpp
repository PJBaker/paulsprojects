//////////////////////////////////////////////////////////////////////////////////////////
//	NV20 Codepath/LightingPass0NoCubeMap.cpp
//	Set/End states for NV20 codepath lighting pass 0 if the light has no cube map (diffuse)
//	Downloaded from: www.paulsprojects.net
//	Created:	16th December 2002
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <vector>
#include "../../GL files/glee.h"			//header for OpenGL 1.4
#include "../../Maths/Maths.h"
#include "../../Log/LOG.h"
#include "../../Bounding Volumes/Bounding Volumes.h"
#include "../../Render Manager/RENDER_MANAGER.h"
#include "../../Console/CONSOLE.h"
#include "../../Point Light/POINT_LIGHT.h"
#include "../CODEPATH_MANAGER.h"

bool NV20_CODEPATH::SetLightingPass0NoCubeMapStates(	const POINT_LIGHT * currentLight,
														const VECTOR3D & cameraPosition,
														DRAWING_STATES & drawingStates)
{
	//Set up matrix0 for attenuation
	glMatrixMode(GL_MATRIX0_ARB);
	glLoadIdentity();
	glTranslatef(0.5f, 0.5f, 0.5f);
	glScalef(0.5f, 0.5f, 0.5f);
	float scale=1.0f/currentLight->boundingSphere.radius;
	glScalef(scale, scale, scale);
	VECTOR3D translation=-currentLight->boundingSphere.centre;
	glTranslatef(translation.x, translation.y, translation.z);
	glMatrixMode(GL_MODELVIEW);


	//Send the light's color as col0
	glColor4fv(currentLight->color);


	//Bind and enable vertex program
	glBindProgramARB(GL_VERTEX_PROGRAM_ARB, pass0NoCubeMapVP);
	//Send the light's position as program local parameter 0
	glProgramLocalParameter4fvARB(GL_VERTEX_PROGRAM_ARB, 0, currentLight->boundingSphere.centre);
	glEnable(GL_VERTEX_PROGRAM_ARB);


	//Set up textures & texture shaders
	//unit 0 - decal
	glTexEnvi(GL_TEXTURE_SHADER_NV, GL_SHADER_OPERATION_NV, GL_TEXTURE_2D);

	//unit 1 - normal map
	glActiveTexture(GL_TEXTURE1);
	glTexEnvi(GL_TEXTURE_SHADER_NV, GL_SHADER_OPERATION_NV, GL_TEXTURE_2D);
	
	//unit 2 - pass through for attenuation
	glActiveTexture(GL_TEXTURE2);
	glTexEnvi(GL_TEXTURE_SHADER_NV, GL_SHADER_OPERATION_NV, GL_PASS_THROUGH_NV);

	//unit 3 - normalisation cube map
	glActiveTexture(GL_TEXTURE3);
	glTexEnvi(GL_TEXTURE_SHADER_NV, GL_SHADER_OPERATION_NV, GL_TEXTURE_CUBE_MAP);
	glBindTexture(GL_TEXTURE_CUBE_MAP, RENDER_MANAGER::Instance()->normCubeMap);
	glActiveTexture(GL_TEXTURE0);

	//Enable texture shaders
	glEnable(GL_TEXTURE_SHADER_NV);


	//Set up register combiners:		1-(tex2 dot tex2)	for 1-dst^2 attenuation,
	//									* tex1 dot tex3		for bump map
	//									* clampto01[8*max(light.z, 0)] for self shadow
	//									* tex0 * col0
	glCombinerParameteriNV(GL_NUM_GENERAL_COMBINERS_NV, 2);

	//Combiner 0 does	tex2 dot tex2 -> spare0
	//					tex3 dot tex1 -> spare1
	glCombinerInputNV(	GL_COMBINER0_NV, GL_RGB, GL_VARIABLE_A_NV, GL_TEXTURE2,
						GL_EXPAND_NORMAL_NV, GL_RGB);
	glCombinerInputNV(	GL_COMBINER0_NV, GL_RGB, GL_VARIABLE_B_NV, GL_TEXTURE2,
						GL_EXPAND_NORMAL_NV, GL_RGB);
	glCombinerInputNV(	GL_COMBINER0_NV, GL_RGB, GL_VARIABLE_C_NV, GL_TEXTURE3,
						GL_EXPAND_NORMAL_NV, GL_RGB);
	glCombinerInputNV(	GL_COMBINER0_NV, GL_RGB, GL_VARIABLE_D_NV, GL_TEXTURE1,
						GL_EXPAND_NORMAL_NV, GL_RGB);
	glCombinerOutputNV(	GL_COMBINER0_NV, GL_RGB, GL_SPARE0_NV, GL_SPARE1_NV, GL_DISCARD_NV,
						GL_NONE, GL_NONE, true, true, false);

	//Combiner 0 alpha does clampto01[8*max(light.z, 0)] -> spare0.a
	glCombinerInputNV(	GL_COMBINER0_NV, GL_ALPHA, GL_VARIABLE_A_NV, GL_ZERO,
						GL_UNSIGNED_INVERT_NV, GL_ALPHA);
	glCombinerInputNV(	GL_COMBINER0_NV, GL_ALPHA, GL_VARIABLE_B_NV, GL_TEXTURE3,
						GL_EXPAND_NORMAL_NV, GL_BLUE);
	glCombinerInputNV(	GL_COMBINER0_NV, GL_ALPHA, GL_VARIABLE_C_NV, GL_ZERO,
						GL_UNSIGNED_INVERT_NV, GL_ALPHA);
	glCombinerInputNV(	GL_COMBINER0_NV, GL_ALPHA, GL_VARIABLE_D_NV, GL_TEXTURE3,
						GL_EXPAND_NORMAL_NV, GL_BLUE);
	glCombinerOutputNV(	GL_COMBINER0_NV, GL_ALPHA, GL_DISCARD_NV, GL_DISCARD_NV, GL_SPARE0_NV,
						GL_SCALE_BY_FOUR_NV, GL_NONE, false, false, false);

	//Combiner 1 does	(1-spare0)*spare0.a -> spare0
	//					spare1*tex0         -> spare1
	glCombinerInputNV(	GL_COMBINER1_NV, GL_RGB, GL_VARIABLE_A_NV, GL_SPARE0_NV,
						GL_UNSIGNED_INVERT_NV, GL_RGB);
	glCombinerInputNV(	GL_COMBINER1_NV, GL_RGB, GL_VARIABLE_B_NV, GL_SPARE0_NV,
						GL_UNSIGNED_IDENTITY_NV, GL_ALPHA);
	glCombinerInputNV(	GL_COMBINER1_NV, GL_RGB, GL_VARIABLE_C_NV, GL_SPARE1_NV,
						GL_UNSIGNED_IDENTITY_NV, GL_RGB);
	glCombinerInputNV(	GL_COMBINER1_NV, GL_RGB, GL_VARIABLE_D_NV, GL_TEXTURE0,
						GL_UNSIGNED_IDENTITY_NV, GL_RGB);
	glCombinerOutputNV(	GL_COMBINER1_NV, GL_RGB, GL_SPARE0_NV, GL_SPARE1_NV, GL_DISCARD_NV,
						GL_NONE, GL_NONE, false, false, false);

	//Final combiner outputs spare0*spare1*col0
	//first do spare1*col0 in the EF multiplier
	glFinalCombinerInputNV(GL_VARIABLE_E_NV, GL_SPARE1_NV, GL_UNSIGNED_IDENTITY_NV, GL_RGB);
	glFinalCombinerInputNV(GL_VARIABLE_F_NV, GL_PRIMARY_COLOR_NV, GL_UNSIGNED_IDENTITY_NV, GL_RGB);

	glFinalCombinerInputNV(GL_VARIABLE_A_NV, GL_SPARE0_NV, GL_UNSIGNED_IDENTITY_NV, GL_RGB);
	glFinalCombinerInputNV(GL_VARIABLE_B_NV, GL_E_TIMES_F_NV, GL_UNSIGNED_IDENTITY_NV, GL_RGB);
	glFinalCombinerInputNV(GL_VARIABLE_C_NV, GL_ZERO, GL_UNSIGNED_IDENTITY_NV, GL_RGB);
	glFinalCombinerInputNV(GL_VARIABLE_D_NV, GL_ZERO, GL_UNSIGNED_IDENTITY_NV, GL_RGB);

	//Output attenuation * self shadow as alpha
	glFinalCombinerInputNV(GL_VARIABLE_G_NV, GL_SPARE0_NV, GL_UNSIGNED_IDENTITY_NV, GL_BLUE);

	//Enable register combiners
	glEnable(GL_REGISTER_COMBINERS_NV);

	
	//Enable additive blend for rgb, replace for alpha
	glBlendColorEXT(1.0f, 1.0f, 1.0f, 0.0f);
	glBlendFunc(GL_ONE, GL_CONSTANT_COLOR_EXT);
	glEnable(GL_BLEND);


	//Only draw where stencil is zero
	glStencilFunc(GL_EQUAL, 0, ~0);
	glStencilOp(GL_KEEP, GL_KEEP, GL_KEEP);
	glEnable(GL_STENCIL_TEST);


	//Fill in the drawing states
	drawingStates.useNormalArray=true;

	//vertex array units
	drawingStates.textureCoordUnit1=GL_TEXTURE0;
	drawingStates.textureCoordUnit2=0;
	drawingStates.sTangentUnit=GL_TEXTURE1;
	drawingStates.tTangentUnit=GL_TEXTURE2;
	drawingStates.spareUnit=0;

	//texture units
	drawingStates.decalTextureUnit=GL_TEXTURE0;
	drawingStates.emissiveTextureUnit=0;
	drawingStates.normalMapTextureUnit=GL_TEXTURE1;

	drawingStates.drawNonGloss=true;

	return true;
}

void NV20_CODEPATH::EndLightingPass0NoCubeMap(const POINT_LIGHT * currentLight)
{
	//Reset matrix0
	glMatrixMode(GL_MATRIX0_ARB);
	glLoadIdentity();
	glMatrixMode(GL_MODELVIEW);

	//reset color
	glColor4fv(white);

	//disable vertex program
	glDisable(GL_VERTEX_PROGRAM_ARB);

	//disable texture shaders
	glDisable(GL_TEXTURE_SHADER_NV);

	//disable register combiners
	glDisable(GL_REGISTER_COMBINERS_NV);

	//disable blend
	glDisable(GL_BLEND);

	glDisable(GL_STENCIL_TEST);
}