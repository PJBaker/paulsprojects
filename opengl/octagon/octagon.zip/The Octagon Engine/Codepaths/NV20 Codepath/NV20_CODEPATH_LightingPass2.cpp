//////////////////////////////////////////////////////////////////////////////////////////
//	NV20 Codepath/LightingPass2.cpp
//	Set/End states for NV20 codepath lighting pass 2 (specular)
//	Downloaded from: www.paulsprojects.net
//	Created:	2nd January 2003
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <vector>
#include "../../GL files/glee.h"			//header for OpenGL 1.4
#include "../../Maths/Maths.h"
#include "../../Log/LOG.h"
#include "../../Bounding Volumes/Bounding Volumes.h"
#include "../../Render Manager/RENDER_MANAGER.h"
#include "../../Console/CONSOLE.h"
#include "../../Point Light/POINT_LIGHT.h"
#include "../CODEPATH_MANAGER.h"

bool NV20_CODEPATH::SetLightingPass2States(	const POINT_LIGHT * currentLight,
											const VECTOR3D & cameraPosition,
											DRAWING_STATES & drawingStates)
{
	//Send the light's color as col0
	glColor4fv(currentLight->color);


	//Bind and enable vertex program
	glBindProgramARB(GL_VERTEX_PROGRAM_ARB, pass2VP);
	
	//Send the light's position as program local parameter 0, and camera position as parameter 1
	glProgramLocalParameter4fvARB(GL_VERTEX_PROGRAM_ARB, 0, currentLight->boundingSphere.centre);
	glProgramLocalParameter4fvARB(GL_VERTEX_PROGRAM_ARB, 1, cameraPosition);
	
	glEnable(GL_VERTEX_PROGRAM_ARB);


	//Set up and enable textures
	//unit 0 - normal map
	glEnable(GL_TEXTURE_2D);
	
	//unit 1 - normalisation cube map
	glActiveTexture(GL_TEXTURE1);
	glBindTexture(GL_TEXTURE_CUBE_MAP, RENDER_MANAGER::Instance()->normCubeMap);
	glEnable(GL_TEXTURE_CUBE_MAP);
	
	//unit 2 - light's projected cube map (if there is one)
	if(currentLight->hasCubeMap)
	{
		glActiveTexture(GL_TEXTURE2);
		RENDER_MANAGER::Instance()->BindCubeMapTexture(currentLight->cubeMapIndex);
		glEnable(GL_TEXTURE_CUBE_MAP);
	}
	glActiveTexture(GL_TEXTURE0);


	//Set up register combiners:		tex0 dot tex1		for bump map
	//									^16					for exponent
	//									*tex0.a				for gloss map
	//									*tex2 (if there is one) for projected cube map
	//									col0
	glCombinerParameteriNV(GL_NUM_GENERAL_COMBINERS_NV, 6);

	//Combiner 0 does	tex0 dot tex1 -> spare0
	glCombinerInputNV(	GL_COMBINER0_NV, GL_RGB, GL_VARIABLE_A_NV, GL_TEXTURE0,
						GL_EXPAND_NORMAL_NV, GL_RGB);
	glCombinerInputNV(	GL_COMBINER0_NV, GL_RGB, GL_VARIABLE_B_NV, GL_TEXTURE1,
						GL_EXPAND_NORMAL_NV, GL_RGB);
	glCombinerOutputNV(	GL_COMBINER0_NV, GL_RGB, GL_SPARE0_NV, GL_DISCARD_NV, GL_DISCARD_NV,
						GL_NONE, GL_NONE, true, false, false);

	//Combiners 1-4 do spare0*spare0 -> spare0
	glCombinerInputNV(	GL_COMBINER1_NV, GL_RGB, GL_VARIABLE_A_NV, GL_SPARE0_NV,
						GL_UNSIGNED_IDENTITY_NV, GL_RGB);
	glCombinerInputNV(	GL_COMBINER1_NV, GL_RGB, GL_VARIABLE_B_NV, GL_SPARE0_NV,
						GL_UNSIGNED_IDENTITY_NV, GL_RGB);
	glCombinerOutputNV(	GL_COMBINER1_NV, GL_RGB, GL_SPARE0_NV, GL_DISCARD_NV, GL_DISCARD_NV,
						GL_NONE, GL_NONE, false, false, false);

	glCombinerInputNV(	GL_COMBINER2_NV, GL_RGB, GL_VARIABLE_A_NV, GL_SPARE0_NV,
						GL_UNSIGNED_IDENTITY_NV, GL_RGB);
	glCombinerInputNV(	GL_COMBINER2_NV, GL_RGB, GL_VARIABLE_B_NV, GL_SPARE0_NV,
						GL_UNSIGNED_IDENTITY_NV, GL_RGB);
	glCombinerOutputNV(	GL_COMBINER2_NV, GL_RGB, GL_SPARE0_NV, GL_DISCARD_NV, GL_DISCARD_NV,
						GL_NONE, GL_NONE, false, false, false);

	glCombinerInputNV(	GL_COMBINER3_NV, GL_RGB, GL_VARIABLE_A_NV, GL_SPARE0_NV,
						GL_UNSIGNED_IDENTITY_NV, GL_RGB);
	glCombinerInputNV(	GL_COMBINER3_NV, GL_RGB, GL_VARIABLE_B_NV, GL_SPARE0_NV,
						GL_UNSIGNED_IDENTITY_NV, GL_RGB);
	glCombinerOutputNV(	GL_COMBINER3_NV, GL_RGB, GL_SPARE0_NV, GL_DISCARD_NV, GL_DISCARD_NV,
						GL_NONE, GL_NONE, false, false, false);

	glCombinerInputNV(	GL_COMBINER4_NV, GL_RGB, GL_VARIABLE_A_NV, GL_SPARE0_NV,
						GL_UNSIGNED_IDENTITY_NV, GL_RGB);
	glCombinerInputNV(	GL_COMBINER4_NV, GL_RGB, GL_VARIABLE_B_NV, GL_SPARE0_NV,
						GL_UNSIGNED_IDENTITY_NV, GL_RGB);
	glCombinerOutputNV(	GL_COMBINER4_NV, GL_RGB, GL_SPARE0_NV, GL_DISCARD_NV, GL_DISCARD_NV,
						GL_NONE, GL_NONE, false, false, false);

	//Combiner 5 does spare0 * (1-tex0.a) -> spare0
	//tex0.a stores 1-gloss
	glCombinerInputNV(	GL_COMBINER5_NV, GL_RGB, GL_VARIABLE_A_NV, GL_SPARE0_NV,
						GL_UNSIGNED_IDENTITY_NV, GL_RGB);
	glCombinerInputNV(	GL_COMBINER5_NV, GL_RGB, GL_VARIABLE_B_NV, GL_TEXTURE0,
						GL_UNSIGNED_INVERT_NV, GL_ALPHA);
	glCombinerOutputNV(	GL_COMBINER5_NV, GL_RGB, GL_SPARE0_NV, GL_DISCARD_NV, GL_DISCARD_NV,
						GL_NONE, GL_NONE, false, false, false);

	//Final combiner outputs spare0*tex2*col0 if there is a cube map
	if(currentLight->hasCubeMap)
	{
		glFinalCombinerInputNV(GL_VARIABLE_E_NV, GL_PRIMARY_COLOR_NV, GL_UNSIGNED_IDENTITY_NV, GL_RGB);
		glFinalCombinerInputNV(GL_VARIABLE_F_NV, GL_TEXTURE2, GL_UNSIGNED_IDENTITY_NV, GL_RGB);
	
		glFinalCombinerInputNV(GL_VARIABLE_A_NV, GL_SPARE0_NV, GL_UNSIGNED_IDENTITY_NV, GL_RGB);
		glFinalCombinerInputNV(GL_VARIABLE_B_NV, GL_E_TIMES_F_NV, GL_UNSIGNED_IDENTITY_NV, GL_RGB);
		glFinalCombinerInputNV(GL_VARIABLE_C_NV, GL_ZERO, GL_UNSIGNED_IDENTITY_NV, GL_RGB);
		glFinalCombinerInputNV(GL_VARIABLE_D_NV, GL_ZERO, GL_UNSIGNED_IDENTITY_NV, GL_RGB);
	}
	else	//Final combiner outputs spare0*col0 if no projected cube map
	{
		glFinalCombinerInputNV(GL_VARIABLE_A_NV, GL_SPARE0_NV, GL_UNSIGNED_IDENTITY_NV, GL_RGB);
		glFinalCombinerInputNV(GL_VARIABLE_B_NV, GL_PRIMARY_COLOR_NV, GL_UNSIGNED_IDENTITY_NV, GL_RGB);
		glFinalCombinerInputNV(GL_VARIABLE_C_NV, GL_ZERO, GL_UNSIGNED_IDENTITY_NV, GL_RGB);
		glFinalCombinerInputNV(GL_VARIABLE_D_NV, GL_ZERO, GL_UNSIGNED_IDENTITY_NV, GL_RGB);
	}

	//Enable register combiners
	glEnable(GL_REGISTER_COMBINERS_NV);

	
	//Enable blend - modulate with dest. alpha and add
	glBlendFunc(GL_DST_ALPHA, GL_ONE);
	glEnable(GL_BLEND);


	//Only draw where stencil is zero
	glStencilFunc(GL_EQUAL, 0, ~0);
	glStencilOp(GL_KEEP, GL_KEEP, GL_KEEP);
	glEnable(GL_STENCIL_TEST);


	//Fill in the drawing states
	drawingStates.useNormalArray=true;

	//vertex array units
	drawingStates.textureCoordUnit1=GL_TEXTURE0;
	drawingStates.textureCoordUnit2=0;
	drawingStates.sTangentUnit=GL_TEXTURE1;
	drawingStates.tTangentUnit=GL_TEXTURE2;
	drawingStates.spareUnit=0;

	//texture units
	drawingStates.decalTextureUnit=0;
	drawingStates.emissiveTextureUnit=0;
	drawingStates.normalMapTextureUnit=GL_TEXTURE0;

	drawingStates.drawNonGloss=false;

	return true;
}

void NV20_CODEPATH::EndLightingPass2(const POINT_LIGHT * currentLight)
{
	glColor4fv(white);

	glDisable(GL_VERTEX_PROGRAM_ARB);

	glDisable(GL_TEXTURE_2D);
	glActiveTexture(GL_TEXTURE1);
	glDisable(GL_TEXTURE_CUBE_MAP);

	if(currentLight->hasCubeMap)
	{
		glActiveTexture(GL_TEXTURE2);
		glDisable(GL_TEXTURE_CUBE_MAP);
	}
	glActiveTexture(GL_TEXTURE0);

	glDisable(GL_REGISTER_COMBINERS_NV);
	
	glDisable(GL_BLEND);

	glDisable(GL_STENCIL_TEST);
}