//////////////////////////////////////////////////////////////////////////////////////////
//	NV20 Codepath/LightingPass0WithCubeMap.cpp
//	Set/End states for NV20 codepath lighting pass 0 if the light has a cube map (attenuation)
//	Downloaded from: www.paulsprojects.net
//	Created:	16th December 2002
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <vector>
#include "../../GL files/glee.h"			//header for OpenGL 1.4
#include "../../Maths/Maths.h"
#include "../../Log/LOG.h"
#include "../../Bounding Volumes/Bounding Volumes.h"
#include "../../Render Manager/RENDER_MANAGER.h"
#include "../../Console/CONSOLE.h"
#include "../../Point Light/POINT_LIGHT.h"
#include "../CODEPATH_MANAGER.h"

bool NV20_CODEPATH::SetLightingPass0WithCubeMapStates(	const POINT_LIGHT * currentLight,
														const VECTOR3D & cameraPosition,
														DRAWING_STATES & drawingStates)
{
	//Calculate the texture matrix for attenuation
	static MATRIX4X4 biasMatrix(0.5f, 0.0f, 0.0f, 0.0f,
								0.0f, 0.5f, 0.0f, 0.0f,
								0.0f, 0.0f, 0.5f, 0.0f,
								0.5f, 0.5f, 0.5f, 1.0f);
	
	static MATRIX4X4 scaleMatrix;
	scaleMatrix.SetUniformScale(1.0f/currentLight->boundingSphere.radius);

	static MATRIX4X4 translationMatrix;
	translationMatrix.SetTranslation(-currentLight->boundingSphere.centre);

	static MATRIX4X4 attenMatrix;
	attenMatrix=biasMatrix*scaleMatrix*translationMatrix;


	//Set up TexGen
	//Unit 0 takes (x, y, z) of attenuation in (s, t, r)
	glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);
	glTexGenfv(GL_S, GL_OBJECT_PLANE, attenMatrix.GetRow(0));
	glEnable(GL_TEXTURE_GEN_S);

	glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);
	glTexGenfv(GL_T, GL_OBJECT_PLANE, attenMatrix.GetRow(1));
	glEnable(GL_TEXTURE_GEN_T);

	glTexGeni(GL_R, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);
	glTexGenfv(GL_R, GL_OBJECT_PLANE, attenMatrix.GetRow(2));
	glEnable(GL_TEXTURE_GEN_R);



	//Set up texture shaders
	//Unit 0 does pass through for attenuation
	glTexEnvi(GL_TEXTURE_SHADER_NV, GL_SHADER_OPERATION_NV, GL_PASS_THROUGH_NV);

	//Units 1-3 do nothing
	glActiveTexture(GL_TEXTURE1);
	glTexEnvi(GL_TEXTURE_SHADER_NV, GL_SHADER_OPERATION_NV, GL_NONE);
	glActiveTexture(GL_TEXTURE2);
	glTexEnvi(GL_TEXTURE_SHADER_NV, GL_SHADER_OPERATION_NV, GL_NONE);
	glActiveTexture(GL_TEXTURE3);
	glTexEnvi(GL_TEXTURE_SHADER_NV, GL_SHADER_OPERATION_NV, GL_NONE);
	glActiveTexture(GL_TEXTURE0);

	//Enable texture shaders
	glEnable(GL_TEXTURE_SHADER_NV);



	//Set up register combiners:	  1-(tex0 dot tex0)	for 1-dst^2 attenuation,
	glCombinerParameteriNV(GL_NUM_GENERAL_COMBINERS_NV, 1);

	//Combiner 0 does	tex0 dot tex0 -> spare0
	glCombinerInputNV(	GL_COMBINER0_NV, GL_RGB, GL_VARIABLE_A_NV, GL_TEXTURE0,
						GL_EXPAND_NORMAL_NV, GL_RGB);
	glCombinerInputNV(	GL_COMBINER0_NV, GL_RGB, GL_VARIABLE_B_NV, GL_TEXTURE0,
						GL_EXPAND_NORMAL_NV, GL_RGB);
	glCombinerOutputNV(	GL_COMBINER0_NV, GL_RGB, GL_SPARE0_NV, GL_DISCARD_NV, GL_DISCARD_NV,
						GL_NONE, GL_NONE, true, false, false);

	//Final combiner outputs zero as rgb
	glFinalCombinerInputNV(GL_VARIABLE_A_NV, GL_ZERO, GL_UNSIGNED_IDENTITY_NV, GL_RGB);
	glFinalCombinerInputNV(GL_VARIABLE_B_NV, GL_ZERO, GL_UNSIGNED_IDENTITY_NV, GL_RGB);
	glFinalCombinerInputNV(GL_VARIABLE_C_NV, GL_ZERO, GL_UNSIGNED_IDENTITY_NV, GL_RGB);
	glFinalCombinerInputNV(GL_VARIABLE_D_NV, GL_ZERO, GL_UNSIGNED_IDENTITY_NV, GL_RGB);

	//Output 1-spare0 as alpha
	glFinalCombinerInputNV(GL_VARIABLE_G_NV, GL_SPARE0_NV, GL_UNSIGNED_INVERT_NV, GL_BLUE);

	//Enable register combiners
	glEnable(GL_REGISTER_COMBINERS_NV);

	//Only draw where stencil is zero
	glStencilFunc(GL_EQUAL, 0, ~0);
	glStencilOp(GL_KEEP, GL_KEEP, GL_KEEP);
	glEnable(GL_STENCIL_TEST);
	
	//Only draw to alpha
	glColorMask(0, 0, 0, 1);
	

	//Fill in the drawing states
	drawingStates.useNormalArray=false;

	//vertex array units
	drawingStates.textureCoordUnit1=0;
	drawingStates.textureCoordUnit2=0;
	drawingStates.sTangentUnit=0;
	drawingStates.tTangentUnit=0;
	drawingStates.spareUnit=0;

	//texture units
	drawingStates.decalTextureUnit=0;
	drawingStates.emissiveTextureUnit=0;
	drawingStates.normalMapTextureUnit=0;

	drawingStates.drawNonGloss=true;
	
	return true;
}

void NV20_CODEPATH::EndLightingPass0WithCubeMap(const POINT_LIGHT * currentLight)
{
	//Disable texgen
	glDisable(GL_TEXTURE_GEN_S);
	glDisable(GL_TEXTURE_GEN_T);
	glDisable(GL_TEXTURE_GEN_R);

	//Disable texture shaders
	glDisable(GL_TEXTURE_SHADER_NV);

	//Disable register combiners
	glDisable(GL_REGISTER_COMBINERS_NV);

	glDisable(GL_STENCIL_TEST);

	//reset color mask
	glColorMask(1, 1, 1, 1);
}