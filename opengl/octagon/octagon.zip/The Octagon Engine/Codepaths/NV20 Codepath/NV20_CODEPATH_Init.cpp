//////////////////////////////////////////////////////////////////////////////////////////
//	NV20 Codepath/Init.cpp
//	Initiate the NV20 codepath
//	Downloaded from: www.paulsprojects.net
//	Created:	13th December 2002
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <vector>
#include "../../GL files/glee.h"			//header for OpenGL 1.4
#include "../../GL files/ARB_program.h"
#include "../../Maths/Maths.h"
#include "../../Log/LOG.h"
#include "../../Bounding Volumes/Bounding Volumes.h"
#include "../../Render Manager/RENDER_MANAGER.h"
#include "../../Console/CONSOLE.h"
#include "../../Point Light/POINT_LIGHT.h"
#include "../CODEPATH_MANAGER.h"

bool NV20_CODEPATH::Init()
{
	//We can assume 8 bit destination alpha and 2 texture units,
	//since the standard codepath MUST be supported

	//Check for 4 texture units
	GLint maxTextureUnits;
	glGetIntegerv(GL_MAX_TEXTURE_UNITS, &maxTextureUnits);
	if(maxTextureUnits<4)
	{
		LOG::Instance()->OutputError("NV20 Codepath requires at least 4 texture units");
		return false;
	}

	//Check for extensions
	if(	!GLEE_ARB_vertex_program	||	!GLEE_NV_register_combiners	||
		!GLEE_NV_texture_shader		||	!GLEE_EXT_blend_color)
	{
		LOG::Instance()->OutputError("NV20 Codepath requires ARB_vertex program, NV_register_combiners,");
		LOG::Instance()->OutputError("NV_texture_shader and EXT_blend_color extensions");
		return false;
	}

	//Check for 6 general combiners
	GLint maxGeneralCombiners;
	glGetIntegerv(GL_MAX_GENERAL_COMBINERS_NV, &maxGeneralCombiners);
	if(maxGeneralCombiners<6)
	{
		LOG::Instance()->OutputError("NV20 Codepath requires at least 6 general combiners");
		return false;
	}

	//Load the vertex programs
	glGenProgramsARB(1, &pass0NoCubeMapVP);
	glBindProgramARB(GL_VERTEX_PROGRAM_ARB, pass0NoCubeMapVP);
	if(!LoadARB_program(GL_VERTEX_PROGRAM_ARB, "Codepaths/NV20 Codepath/pass0NoCubeMapVP.txt"))
		return false;

	glGenProgramsARB(1, &pass1WithCubeMapVP);
	glBindProgramARB(GL_VERTEX_PROGRAM_ARB, pass1WithCubeMapVP);
	if(!LoadARB_program(GL_VERTEX_PROGRAM_ARB, "Codepaths/NV20 Codepath/pass1WithCubeMapVP.txt"))
		return false;

	glGenProgramsARB(1, &pass2VP);
	glBindProgramARB(GL_VERTEX_PROGRAM_ARB, pass2VP);
	if(!LoadARB_program(GL_VERTEX_PROGRAM_ARB, "Codepaths/NV20 Codepath/pass2VP.txt"))
		return false;
	
	return true;
}
