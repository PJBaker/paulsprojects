//////////////////////////////////////////////////////////////////////////////////////////
//	CODEPATH.h
//	Abstract base class for a codepath
//	Downloaded from: www.paulsprojects.net
//	Created:	13th December 2002
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	

#ifndef CODEPATH_H
#define CODEPATH_H

class CODEPATH
{
public:
	//Init the codepath
	virtual bool Init()=0;

	//Does this codepath require Tangent Space light vectors in spare?
	virtual bool AreTangentSpaceLightVectorsRequired()=0;

	//Lighting passes
	virtual bool SetLightingPass0States(const POINT_LIGHT * currentLight,
										const VECTOR3D & cameraPosition,
										DRAWING_STATES & drawingStates)=0;
	virtual void EndLightingPass0(const POINT_LIGHT * currentLight)=0;


	virtual bool SetLightingPass1States(const POINT_LIGHT * currentLight,
										const VECTOR3D & cameraPosition,
										DRAWING_STATES & drawingStates)=0;
	virtual void EndLightingPass1(const POINT_LIGHT * currentLight)=0;


	virtual bool SetLightingPass2States(const POINT_LIGHT * currentLight,
										const VECTOR3D & cameraPosition,
										DRAWING_STATES & drawingStates)=0;
	virtual void EndLightingPass2(const POINT_LIGHT * currentLight)=0;


	virtual bool SetLightingPass3States(const POINT_LIGHT * currentLight,
										const VECTOR3D & cameraPosition,
										DRAWING_STATES & drawingStates)=0;
	virtual void EndLightingPass3(const POINT_LIGHT * currentLight)=0;

	//Set/End a given pass
	bool SetLightingStates(	int pass, const POINT_LIGHT * currentLight,
							const VECTOR3D & cameraPosition,
							DRAWING_STATES & drawingStates)
	{
		if(pass==0)
			return SetLightingPass0States(	currentLight, cameraPosition, drawingStates);
		if(pass==1)
			return SetLightingPass1States(	currentLight, cameraPosition, drawingStates);
		if(pass==2)
			return SetLightingPass2States(	currentLight, cameraPosition, drawingStates);
		if(pass==3)
			return SetLightingPass3States(	currentLight, cameraPosition, drawingStates);

		return false;
	}

	void EndLighting(int pass, const POINT_LIGHT * currentLight)
	{
		if(pass==0)
			EndLightingPass0(currentLight);
		if(pass==1)
			EndLightingPass1(currentLight);
		if(pass==2)
			EndLightingPass2(currentLight);
		if(pass==3)
			EndLightingPass3(currentLight);
	}
};

#endif	//CODEPATH_H
