//////////////////////////////////////////////////////////////////////////////////////////
//	CODEPATH_MANAGER.h
//	Manager for codepaths
//	Downloaded from: www.paulsprojects.net
//	Created:	16th December 2002
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	

#ifndef CODEPATH_MANAGER_H
#define CODEPATH_MANAGER_H

#include "DRAWING_STATES.h"

#include "CODEPATH.h"
#include "Standard Codepath/STANDARD_CODEPATH.h"
#include "NV20 Codepath/NV20_CODEPATH.h"
#include "R200 Codepath/R200_CODEPATH.h"

enum CODEPATH_TYPE
{
	CODEPATH_TYPE_STANDARD=0,
	CODEPATH_TYPE_NV20,
	CODEPATH_TYPE_R200
};

class CODEPATH_MANAGER
{
protected:
	//protected constructor & copy constructor to prevent >1 instances
	CODEPATH_MANAGER()
	{}
	CODEPATH_MANAGER(const CODEPATH_MANAGER &)
	{}
	CODEPATH_MANAGER & operator=(const CODEPATH_MANAGER &)
	{}

public:
	//public function to access the instance
	static CODEPATH_MANAGER * Instance()
	{
		static CODEPATH_MANAGER instance;	//our sole instance
		return &instance;
	}

	bool Init();

	//Codepath used by renderer
	CODEPATH_TYPE codepathType;
	CODEPATH * codepath;
	char * GetCodepathString()	//return the name of the current codepath
	{
		if(codepathType==CODEPATH_TYPE_STANDARD)
			return "Standard Codepath";
		if(codepathType==CODEPATH_TYPE_NV20)
			return "NV20 Codepath";
		if(codepathType==CODEPATH_TYPE_R200)
			return "R200 Codepath";

		return "";
	}

	//Change codepath
	bool ChangeCodepath(int newCodepath);

protected:
	//Codepaths
	STANDARD_CODEPATH standardCodepath;

	bool nv20CodepathSupported;
	NV20_CODEPATH nv20Codepath;

	bool r200CodepathSupported;
	R200_CODEPATH r200Codepath;
};

#endif	//CODEPATH_MANAGER_H

