//////////////////////////////////////////////////////////////////////////////////////////
//	BSP_LoadNodes.cpp
//	Load bsp tree nodes
//	Downloaded from: www.paulsprojects.net
//	Created:	15th December 2002
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <vector>
#include "../GL files/glee.h"			//header for OpenGL 1.4
#include "../Maths/Maths.h"
#include "../Log/LOG.h"
#include "../Render Manager/RENDER_MANAGER.h"
#include "BSP.h"

bool BSP::LoadNodes(FILE * file)
{
	//Calculate the number of planes
	int numPlanes=header.directoryEntries[bspPlanes].length/sizeof(PLANE);

	//Create space for this many planes
	PLANE * planes=new PLANE[numPlanes];
	if(!planes)
	{
		LOG::Instance()->OutputError("Unable to allocate memory for %d BSP splitting planes",
										numPlanes);
		return false;
	}

	//Read in the planes
	fseek(file, header.directoryEntries[bspPlanes].offset, SEEK_SET);
	fread(planes, header.directoryEntries[bspPlanes].length, 1, file);

	//Loop through planes
	//Reverse the intercept and convert to our coordinate system
	for(int i=0; i<numPlanes; ++i)
	{
		float temp=planes[i].normal.y;
		planes[i].normal.y=planes[i].normal.z;
		planes[i].normal.z=-temp;

		planes[i].intercept=-planes[i].intercept/64;
	}


	//Calculate the number of nodes
	numNodes=header.directoryEntries[bspNodes].length/sizeof(BSP_LOAD_NODE);

	//Create space for this many LOAD_NODES
	BSP_LOAD_NODE * loadNodes=new BSP_LOAD_NODE[numNodes];
	if(!loadNodes)
	{
		LOG::Instance()->OutputError("Unable to allocate space for %d LOAD_NODEs", numNodes);
		return false;
	}

	//Read in the LOAD_NODEs
	fseek(file, header.directoryEntries[bspNodes].offset, SEEK_SET);
	fread(loadNodes, header.directoryEntries[bspNodes].length, 1, file);


	//Create space for nodes
	nodes=new BSP_NODE[numNodes];
	if(!nodes)
	{
		LOG::Instance()->OutputError("Unable to allocate space for %d BSP_NODEs", numNodes);
		return false;
	}

	//Convert LOAD_NODEs to NODEs
	for(int i=0; i<numNodes; ++i)
	{
		nodes[i].back=loadNodes[i].back;
		nodes[i].front=loadNodes[i].front;

		nodes[i].splittingPlane=planes[loadNodes[i].planeIndex];	//use node bounding box? - todo
	}

	//Free temporary memory
	if(planes)
		delete [] planes;
	planes=NULL;

	if(loadNodes)
		delete [] loadNodes;
	loadNodes=NULL;

	return true;
}