//////////////////////////////////////////////////////////////////////////////////////////
//	BSP_SendPolygonFaceIndices.cpp
//	Send the vertex indices for polygon faces to the render manager
//	Downloaded from: www.paulsprojects.net
//	Created:	12th December 2002
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <vector>
#include "../GL files/glee.h"			//header for OpenGL 1.4
#include "../Maths/Maths.h"
#include "../Log/LOG.h"
#include "../Render Manager/RENDER_MANAGER.h"
#include "BSP.h"

bool BSP::SendPolygonFaceIndices(const BITSET & facesToDraw, bool drawNonFacing)
{
	bool anySent=false;

	//Loop through polygon faces
	for(int i=0; i<numPolygonFaces; ++i)
	{
		//If this face is not facing and we are not drawing non-facing faces, continue
		if(!drawNonFacing && !polygonFaces[i].isFacing)
			continue;

		//If this face is not set in the bitset, continue
		if(!facesToDraw.IsSet(polygonFaces[i].pvsFaceNumber))
			continue;

		//Add the indices to the list
		RENDER_MANAGER::Instance()->AddGeometryElements(polygonFaces[i].surfaceTextureIndex,
														polygonFaces[i].numIndices,
														polygonFaces[i].indices);

		anySent=true;
	}

	return anySent;
}