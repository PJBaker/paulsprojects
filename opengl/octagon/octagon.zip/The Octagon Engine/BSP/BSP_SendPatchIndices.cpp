//////////////////////////////////////////////////////////////////////////////////////////
//	BSP_SendPatchIndices.cpp
//	Send the vertex indices for patches to the render manager
//	Downloaded from: www.paulsprojects.net
//	Created:	3rd January 2003
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <vector>
#include "../GL files/glee.h"			//header for OpenGL 1.4
#include "../Maths/Maths.h"
#include "../Log/LOG.h"
#include "../Render Manager/RENDER_MANAGER.h"
#include "BSP.h"

bool BSP::SendPatchIndices(	const BITSET & facesToDraw,
							const BOUNDING_VOLUME * volume1,	//only draw if the patch is in these volumes
							const BOUNDING_VOLUME * volume2)
{
	bool anySent=false;

	//Loop through patches
	for(int i=0; i<numPatches; ++i)
	{
		//If this patch is not set in the bitset, continue
		if(!facesToDraw.IsSet(patches[i].pvsFaceNumber))
			continue;

		//If this patch is not in a given volume, continue
		if(volume1)
			if(!volume1->IsAABoundingBoxInside(patches[i].boundingBox))
				continue;

		if(volume2)
			if(!volume2->IsAABoundingBoxInside(patches[i].boundingBox))
				continue;

		//Add the indices to the list
		RENDER_MANAGER::Instance()->AddGeometryElements(patches[i].surfaceTextureIndex,
														patches[i].numIndices,
														patches[i].indices);

		anySent=true;
	}

	return anySent;
}