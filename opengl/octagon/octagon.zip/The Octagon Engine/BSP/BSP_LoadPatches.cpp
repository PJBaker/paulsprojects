//////////////////////////////////////////////////////////////////////////////////////////
//	BSP_LoadPatches.cpp
//	Load bsp patches
//	Downloaded from: www.paulsprojects.net
//	Created:	3rd January 2003
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <vector>
#include "../GL files/glee.h"			//header for OpenGL 1.4
#include "../Maths/Maths.h"
#include "../Log/LOG.h"
#include "../Render Manager/RENDER_MANAGER.h"
#include "../Console/CONSOLE.h"
#include "BSP.h"

bool BSP::LoadPatches(FILE * file)
{
	//Tesselation. The number of "quads" across/up per biquadratic patch
	int patchTesselation=CONSOLE::Instance()->variables.patchTesselation;

	//Calculate the number of BSP_LOAD_FACEs
	int numLoadFaces=header.directoryEntries[bspFaces].length/sizeof(BSP_LOAD_FACE);

	//Create space for the load faces
	BSP_LOAD_FACE * loadFaces=new BSP_LOAD_FACE[numLoadFaces];
	if(!loadFaces)
	{
		LOG::Instance()->OutputError("Unable to allocate space for %d BSP_LOAD_FACEs",
										numLoadFaces);
		return false;
	}

	//read in the BSP_LOAD_FACEs
	fseek(file, header.directoryEntries[bspFaces].offset, SEEK_SET);
	fread(loadFaces, header.directoryEntries[bspFaces].length, 1, file);


	//Calculate how many patches there are
	numPatches=0;

	for(int i=0; i<numLoadFaces; ++i)
	{
		//skip this face if it is not a patch
		if(loadFaces[i].type!=bspPatch)
			continue;

		//skip this face if the texture was not loaded
		if(tempTextureIndices[loadFaces[i].texture]==-1)
			continue;

		++numPatches;
	}


	//Create space for this many patches
	patches=new BSP_PATCH[numPatches];
	if(!patches)
	{
		LOG::Instance()->OutputError("Unable to allocate space for %d BSP_PATCHes", numPatches);
		return false;
	}



	//Fill in the patches
	int currentPatch=0;

	for(int i=0; i<numLoadFaces; ++i)
	{
		//skip this face if it is not a patch
		if(loadFaces[i].type!=bspPatch)
			continue;

		//skip this face if the texture was not loaded
		if(tempTextureIndices[loadFaces[i].texture]==-1)
			continue;

		//Fill in the properties of the face
		patches[currentPatch].pvsFaceNumber=i;
		patches[currentPatch].surfaceTextureIndex=tempTextureIndices[loadFaces[i].texture];
		
		//Calculate the number of control points across & up
		int controlWidth=loadFaces[i].patchSize[0];
		int controlHeight=loadFaces[i].patchSize[1];

		//Calculate the number of biquadratic patches to decompose into
		int biquadWidth=(controlWidth-1)/2;
		int biquadHeight=(controlHeight-1)/2;

		//Calculate the number of vertices across * up
		int vertexWidth=biquadWidth*patchTesselation+1;
		int vertexHeight=biquadHeight*patchTesselation+1;
		
		//Create space for a temporary array of the patch's control points
		int numControlPoints=controlWidth*controlHeight;
		
		GEOMETRY_VERTEX * controlPoints=new GEOMETRY_VERTEX[numControlPoints];
		if(!controlPoints)
		{
			LOG::Instance()->OutputError("Unable to allocate space for %d control points",
											numControlPoints);
			return false;
		}
											
		//Fill in the array of control points
		for(int j=0; j<numControlPoints; ++j)
		{
			controlPoints[j].position.x=
								 tempVertices[loadFaces[i].firstVertexIndex+j].position.x/64;
			controlPoints[j].position.y= 
								 tempVertices[loadFaces[i].firstVertexIndex+j].position.z/64;
			controlPoints[j].position.z=
								-tempVertices[loadFaces[i].firstVertexIndex+j].position.y/64;

			controlPoints[j].texCoords.x=
								 tempVertices[loadFaces[i].firstVertexIndex+j].decalCoords.x;
			controlPoints[j].texCoords.y=
								-tempVertices[loadFaces[i].firstVertexIndex+j].decalCoords.y;
		}


		//Create space for vertices
		GEOMETRY_VERTEX * vertices=new GEOMETRY_VERTEX[vertexWidth*vertexHeight];
		if(!vertices)
		{
			LOG::Instance()->OutputError("Unable to allocate space for %d vertices",
											vertexWidth*vertexHeight);
			return false;
		}
	
		//Create space for an array to hold the vertices for a single biquadratic patch
		GEOMETRY_VERTEX * biquadVertices=new GEOMETRY_VERTEX[(patchTesselation+1)*
																(patchTesselation+1)];
		if(!biquadVertices)
		{
			LOG::Instance()->OutputError("Unable to allocate space for %d vertices",
											(patchTesselation+1)*(patchTesselation+1));
			return false;
		}


		//Loop through the biquadratic patches
		for(int j=0; j<biquadHeight; ++j)
		{
			for(int k=0; k<biquadWidth; ++k)
			{
				//Fill an array with the 9 control points for this biquadratic patch
				GEOMETRY_VERTEX biquadControlPoints[9];

				biquadControlPoints[0]=controlPoints[j*controlWidth*2 + k*2];
				biquadControlPoints[1]=controlPoints[j*controlWidth*2 + k*2 +1];
				biquadControlPoints[2]=controlPoints[j*controlWidth*2 + k*2 +2];

				biquadControlPoints[3]=controlPoints[j*controlWidth*2 + controlWidth + k*2];
				biquadControlPoints[4]=controlPoints[j*controlWidth*2 + controlWidth + k*2 +1];
				biquadControlPoints[5]=controlPoints[j*controlWidth*2 + controlWidth + k*2 +2];

				biquadControlPoints[6]=controlPoints[j*controlWidth*2 + controlWidth*2 + k*2];
				biquadControlPoints[7]=controlPoints[j*controlWidth*2 + controlWidth*2 + k*2 +1];
				biquadControlPoints[8]=controlPoints[j*controlWidth*2 + controlWidth*2 + k*2 +2];

				//Tesselate this biquadratic patch into the biquadVertices
				if(!TesselateBiquadraticPatch(biquadControlPoints, biquadVertices, patchTesselation))
					return false;

				//Add the calculated vertices to the array
				for(int l=0; l<patchTesselation+1; ++l)
				{
					for(int m=0; m<patchTesselation+1; ++m)
					{
						int index= (j*vertexWidth+k)*patchTesselation + l*vertexWidth + m;
						vertices[index]=biquadVertices[l*(patchTesselation+1)+m];
					}
				}
			}
		}


		//Fill in indices
		patches[currentPatch].numIndices=(vertexWidth-1)*(vertexHeight-1)*6;

		patches[currentPatch].indices=new unsigned int[patches[currentPatch].numIndices];
		if(!patches[currentPatch].indices)
		{
			LOG::Instance()->OutputError("Unable to allocate space for %d indices",
											patches[currentPatch].numIndices);
			return false;
		}

		for(int j=0; j<vertexHeight-1; ++j)
		{
			for(int k=0; k<vertexWidth-1; ++k)
			{
				patches[currentPatch].indices[(j*(vertexWidth-1)+k)*6+0]=j*vertexWidth+k;
				patches[currentPatch].indices[(j*(vertexWidth-1)+k)*6+1]=j*vertexWidth+k+1;
				patches[currentPatch].indices[(j*(vertexWidth-1)+k)*6+2]=(j+1)*vertexWidth+k;

				patches[currentPatch].indices[(j*(vertexWidth-1)+k)*6+3]=(j+1)*vertexWidth+k;
				patches[currentPatch].indices[(j*(vertexWidth-1)+k)*6+4]=j*vertexWidth+k+1;
				patches[currentPatch].indices[(j*(vertexWidth-1)+k)*6+5]=(j+1)*vertexWidth+k+1;
			}
		}

		//Create space for plane equations
		patches[currentPatch].planeEquations=new PLANE[patches[currentPatch].numIndices/3];
		patches[currentPatch].isFacing=new bool[patches[currentPatch].numIndices/3];
		if(!patches[currentPatch].planeEquations || !patches[currentPatch].isFacing)
		{
			LOG::Instance()->OutputError("Unable to allocate space for %d planes",
											patches[currentPatch].numIndices/3);
			return false;
		}


		//Calculate the TSB for each triangle and add to the vertices
		VECTOR3D normal, sTangent, tTangent;
		for(int j=0; j<patches[currentPatch].numIndices; j+=3)
		{
			RENDER_MANAGER::Instance()->CalculateTSB(vertices[patches[currentPatch].indices[j+0]],
													 vertices[patches[currentPatch].indices[j+1]],
													 vertices[patches[currentPatch].indices[j+2]],
													 normal, sTangent, tTangent);

			for(int k=0; k<3; ++k)
			{
				vertices[patches[currentPatch].indices[j+k]].normal+=normal;
				vertices[patches[currentPatch].indices[j+k]].sTangent+=sTangent;
				vertices[patches[currentPatch].indices[j+k]].tTangent+=tTangent;
			}

			//Calculate plane equation
			patches[currentPatch].planeEquations[j/3].normal=normal;
			patches[currentPatch].planeEquations[j/3].CalculateIntercept(
										vertices[patches[currentPatch].indices[j+0]].position);
		}

		//Normalise TSBs
		for(int j=0; j<vertexWidth*vertexHeight; ++j)
		{
			vertices[j].normal.Normalize();
			vertices[j].sTangent.Normalize();
			vertices[j].tTangent.Normalize();
		}

		//Send vertices to render manager
		int firstVertexIndex=RENDER_MANAGER::Instance()->AddTempGeometryVertex(vertices[0]);

		for(int j=1; j<vertexWidth*vertexHeight; ++j)
		{
			RENDER_MANAGER::Instance()->AddTempGeometryVertex(vertices[j]);
		}

		//Add firstVertexIndex to the indices
		for(int j=0; j<patches[currentPatch].numIndices; ++j)
			patches[currentPatch].indices[j]+=firstVertexIndex;

		//Fill in the bounding box
		VECTOR3D newMins ( 999999.0f, 999999.0f, 999999.0f);
		VECTOR3D newMaxes(-999999.0f,-999999.0f,-999999.0f);

		//Loop through vertices & update values
		for(int j=0; j<vertexWidth*vertexHeight; ++j)
		{
			VECTOR3D & vertexPosition=vertices[j].position;

			if(vertexPosition.x<newMins.x)
				newMins.x=vertexPosition.x;
		
			if(vertexPosition.y<newMins.y)
				newMins.y=vertexPosition.y;
		
			if(vertexPosition.z<newMins.z)
				newMins.z=vertexPosition.z;

			if(vertexPosition.x>newMaxes.x)
				newMaxes.x=vertexPosition.x;

			if(vertexPosition.y>newMaxes.y)
				newMaxes.y=vertexPosition.y;

			if(vertexPosition.z>newMaxes.z)
				newMaxes.z=vertexPosition.z;
		}

		patches[currentPatch].boundingBox.SetFromMinsMaxes(newMins, newMaxes);

		//Calculate the neighbour indices
		patches[currentPatch].neighbourIndices=new int[patches[currentPatch].numIndices];
		if(!patches[currentPatch].neighbourIndices)
		{
			LOG::Instance()->OutputError("Unable to allocate space for %d ints",
											patches[currentPatch].numIndices);
			return false;
		}

		//Loop through pairs of triangles
		for(int j=0; j<vertexHeight-1; ++j)
		{
			for(int k=0; k<vertexWidth-1; ++k)
			{
				int triNumber=(j*(vertexWidth-1)+k)*2;
				patches[currentPatch].neighbourIndices[triNumber*3+0]= j==0 ? -1 : triNumber-2*(vertexWidth-1)+1;
				patches[currentPatch].neighbourIndices[triNumber*3+1]=triNumber+1;
				patches[currentPatch].neighbourIndices[triNumber*3+2]= k==0 ? -1 : triNumber-1;

				patches[currentPatch].neighbourIndices[triNumber*3+3]=triNumber;
				patches[currentPatch].neighbourIndices[triNumber*3+4]= k==(vertexWidth-2) ? -1 : triNumber+2;
				patches[currentPatch].neighbourIndices[triNumber*3+5]= j==(vertexHeight-2) ? -1 : triNumber+2*(vertexWidth-1);
			}
		}
				
		//delete temporary memory
		if(controlPoints)
			delete [] controlPoints;
		controlPoints=NULL;

		if(vertices)
			delete [] vertices;
		vertices=NULL;

		if(biquadVertices)
			delete [] biquadVertices;
		biquadVertices=NULL;
		
		//move on to the next patch
		++currentPatch;
	}

	//free temporary memory
	if(loadFaces)
		delete [] loadFaces;
	loadFaces=NULL;

	return true;
}


			



