//////////////////////////////////////////////////////////////////////////////////////////
//	BSP_IsClusterVisible.cpp
//	Is one cluster visible from another?
//	Downloaded from: www.paulsprojects.net
//	Created:	15th December 2002
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <vector>
#include "../GL files/glee.h"			//header for OpenGL 1.4
#include "../Maths/Maths.h"
#include "../Log/LOG.h"
#include "../Render Manager/RENDER_MANAGER.h"
#include "BSP.h"

bool BSP::IsClusterVisible(int cluster1, int cluster2)
{
	//Look up the relationship in the PVS data array
	int index=cluster1*visibilityData.bytesPerCluster+cluster2/8;

	int result=visibilityData.bitset[index] & (1<<(cluster2 & 7));

	return (result!=0);
}