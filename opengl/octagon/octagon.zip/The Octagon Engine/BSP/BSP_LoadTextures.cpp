//////////////////////////////////////////////////////////////////////////////////////////
//	BSP_LoadTextures.cpp
//	Load bsp textures
//	Downloaded from: www.paulsprojects.net
//	Created:	12th December 2002
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <vector>
#include "../GL files/glee.h"			//header for OpenGL 1.4
#include "../Maths/Maths.h"
#include "../Log/LOG.h"
#include "../Render Manager/RENDER_MANAGER.h"
#include "BSP.h"

bool BSP::LoadTextures(FILE * file)
{
	//Calculate number of textures
	numLoadTextures=header.directoryEntries[bspTextures].length/sizeof(BSP_LOAD_TEXTURE);

	//Create space for this many BSP_LOAD_TEXTUREs
	BSP_LOAD_TEXTURE * loadTextures=new BSP_LOAD_TEXTURE[numLoadTextures];
	if(!loadTextures)
	{
		LOG::Instance()->OutputError("Unable to create space for %d BSP_LOAD_TEXTUREs",
										numLoadTextures);
		return false;
	}

	//Read in the BSP_LOAD_TEXTUREs
	fseek(file, header.directoryEntries[bspTextures].offset, SEEK_SET);
	fread(loadTextures, header.directoryEntries[bspTextures].length, 1, file);


	//Create space for this many textureIndices
	tempTextureIndices=new int[numLoadTextures];
	if(!tempTextureIndices)
	{
		LOG::Instance()->OutputError("Unable to create space for %d texture indices",
										numLoadTextures);
		return false;
	}


	//Loop through and create textures, saving the indices in the array
	char filename[128];

	for(int i=0; i<numLoadTextures; ++i)
	{
		//Add "data/" to the start of the filename
		strcpy(filename, "data/");
		strcat(filename, loadTextures[i].filename);

		tempTextureIndices[i]=RENDER_MANAGER::Instance()->CreateGeometryTexture(filename);
	}

	//Free temporary memory
	if(loadTextures)
		delete [] loadTextures;
	loadTextures=NULL;

	return true;
}

	
