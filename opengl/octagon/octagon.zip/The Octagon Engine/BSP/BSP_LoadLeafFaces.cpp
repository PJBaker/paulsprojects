//////////////////////////////////////////////////////////////////////////////////////////
//	BSP_LoadLeafFaces.cpp
//	Load indices for the faces held in each leaf
//	Downloaded from: www.paulsprojects.net
//	Created:	15th December 2002
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <vector>
#include "../GL files/glee.h"			//header for OpenGL 1.4
#include "../Maths/Maths.h"
#include "../Log/LOG.h"
#include "../Render Manager/RENDER_MANAGER.h"
#include "BSP.h"

bool BSP::LoadLeafFaces(FILE * file)
{
	//Calculate the size of the leaf faces array
	int numLeafFaces=header.directoryEntries[bspLeafFaces].length/sizeof(int);

	//Create space for an array of this size
	leafFaces=new int[numLeafFaces];
	if(!leafFaces)
	{
		LOG::Instance()->OutputError("Unable to allocate space for %d leaf faces", numLeafFaces);
		return false;
	}

	//Read in the array
	fseek(file, header.directoryEntries[bspLeafFaces].offset, SEEK_SET);
	fread(leafFaces, header.directoryEntries[bspLeafFaces].length, 1, file);

	return true;
}