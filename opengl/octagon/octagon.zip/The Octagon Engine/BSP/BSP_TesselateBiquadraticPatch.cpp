//////////////////////////////////////////////////////////////////////////////////////////
//	BSP_TesselateBiquadraticPatch.cpp
//	Fill the given vertex array with the vertices for a biquadratic patch
//	Downloaded from: www.paulsprojects.net
//	Created:	7th January 2003
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <vector>
#include "../GL files/glee.h"			//header for OpenGL 1.4
#include "../Maths/Maths.h"
#include "../Log/LOG.h"
#include "../Render Manager/RENDER_MANAGER.h"
#include "BSP.h"

bool BSP::TesselateBiquadraticPatch(const GEOMETRY_VERTEX * controlPoints,
									GEOMETRY_VERTEX * vertices,
									int tesselation)
{
	//Calculate how many vertices across/down there are
	int vertexWidth=tesselation+1;

	//Create space to hold the interpolated vertices up the three columns of control points
	GEOMETRY_VERTEX * column0=new GEOMETRY_VERTEX[vertexWidth];
	GEOMETRY_VERTEX * column1=new GEOMETRY_VERTEX[vertexWidth];
	GEOMETRY_VERTEX * column2=new GEOMETRY_VERTEX[vertexWidth];
	if(!column0 || !column1 || !column2)
	{
		LOG::Instance()->OutputError("Unable to allocate memory for %d vertices", 3*vertexWidth);
		return false;
	}

	//Tesselate along the columns
	for(int i=0; i<vertexWidth; ++i)
	{
		float factor=float(i)/(vertexWidth-1);
		column0[i]=controlPoints[0].QuadraticInterpolate(controlPoints[3], controlPoints[6], factor);
		column1[i]=controlPoints[1].QuadraticInterpolate(controlPoints[4], controlPoints[7], factor);
		column2[i]=controlPoints[2].QuadraticInterpolate(controlPoints[5], controlPoints[8], factor);
	}

	//Tesselate across the rows to get final vertices
	for(int i=0; i<vertexWidth; ++i)
	{
		for(int j=0; j<vertexWidth; ++j)
		{
			vertices[i*vertexWidth+j]=column0[i].QuadraticInterpolate(	column1[i],
																		column2[i],
																		float(j)/(vertexWidth-1));
		}
	}

	//Free temporary memory
	if(column0)
		delete [] column0;
	column0=NULL;

	if(column1)
		delete [] column1;
	column1=NULL;

	if(column2)
		delete [] column2;
	column2=NULL;
	
	return true;
}
