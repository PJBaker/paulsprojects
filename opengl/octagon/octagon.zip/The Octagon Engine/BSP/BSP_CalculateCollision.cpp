//////////////////////////////////////////////////////////////////////////////////////////
//	BSP_CalculateCollision.cpp
//	Collide a camera with the bsp
//	Downloaded from: www.paulsprojects.net
//	Created:	16th February 2003
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <vector>
#include "../GL files/glee.h"			//header for OpenGL 1.4
#include "../Maths/Maths.h"
#include "../Log/LOG.h"
#include "../Render Manager/RENDER_MANAGER.h"
#include "BSP.h"

void BSP::CalculateCollision(WALKING_CAMERA & camera)
{
	//Store the bounding sphere
	BOUNDING_SPHERE & sphere=camera.boundingSphere;

	//Store the faces to collide with
	static BITSET collidableFaces;

	//Calculate the faces to collide with
	CalculateVisibleFaces(sphere.centre, sphere, collidableFaces);

	//Loop through the polygon faces
	for(int i=0; i<numPolygonFaces; ++i)
	{
		const BSP_POLYGON_FACE & currentFace=polygonFaces[i];

		//If this face is not set in the bitset, continue
		if(!collidableFaces.IsSet(currentFace.pvsFaceNumber))
			continue;

		//See if the sphere collides with this face
		if(sphere.IsPolygonInside(	currentFace.planeEquation,
									currentFace.numVertexPositions,
									currentFace.vertexPositions))
		{
			//We have collided. 
			//Calculate the distance from the face to the centre
			float distance=currentFace.planeEquation.GetDistance(sphere.centre);

			//Calculate the distance by which the sphere is inside the face
			float distanceOver=sphere.radius-distance;

			//Move the sphere outside the face
			if(distanceOver>0)
				sphere.centre+=distanceOver*currentFace.planeEquation.normal;
		}
	}
}