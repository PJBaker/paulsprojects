//////////////////////////////////////////////////////////////////////////////////////////
//	BSP_CalculateLeaf.cpp
//	Calculate which leaf a point lies in
//	Downloaded from: www.paulsprojects.net
//	Created:	15th December 2002
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <vector>
#include "../GL files/glee.h"			//header for OpenGL 1.4
#include "../Maths/Maths.h"
#include "../Log/LOG.h"
#include "../Render Manager/RENDER_MANAGER.h"
#include "BSP.h"

int BSP::CalculateLeaf(const VECTOR3D & position)
{
	int currentNode=0;

	//loop until we find a negative index
	while(currentNode>=0)
	{
		//Iteratively traverse the tree
		//If "position" is in front of the splitting plane, set currentNode to be the front node
		//otherwise, currentNode=back node
		if(nodes[currentNode].splittingPlane.ClassifyPoint(position) ==	POINT_IN_FRONT_OF_PLANE)
			currentNode=nodes[currentNode].front;
		else
			currentNode=nodes[currentNode].back;
	}

	//return the leaf index
	return ~currentNode;
}
