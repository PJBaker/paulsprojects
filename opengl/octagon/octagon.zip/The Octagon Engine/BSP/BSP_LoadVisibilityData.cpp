//////////////////////////////////////////////////////////////////////////////////////////
//	BSP_LoadVisibilityData.cpp
//	Load bsp PVS data
//	Downloaded from: www.paulsprojects.net
//	Created:	15th December 2002
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <vector>
#include "../GL files/glee.h"			//header for OpenGL 1.4
#include "../Maths/Maths.h"
#include "../Log/LOG.h"
#include "../Render Manager/RENDER_MANAGER.h"
#include "BSP.h"

bool BSP::LoadVisibilityData(FILE * file)
{
	//Read in the number of clusters and the bytes per cluster
	fseek(file, header.directoryEntries[bspVisData].offset, SEEK_SET);
	fread(&visibilityData, 2, sizeof(int), file);

	//Calculate the size of the bitset
	int bitsetSize=visibilityData.numClusters*visibilityData.bytesPerCluster;

	//Create space for bitset
	visibilityData.bitset=new GLubyte[bitsetSize];
	if(!visibilityData.bitset)
	{
		LOG::Instance()->OutputError("Unable to allocate memory for PVS bitset of %d bytes",
										bitsetSize);
		return false;
	}

	//Read in bitset
	fread(visibilityData.bitset, 1, bitsetSize, file);

	return true;
}