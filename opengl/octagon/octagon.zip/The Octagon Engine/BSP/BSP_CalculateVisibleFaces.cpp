//////////////////////////////////////////////////////////////////////////////////////////
//	BSP_CalculateVisibleFaces.cpp
//	Which faces are visible from a point and within bounding volume?
//	Downloaded from: www.paulsprojects.net
//	Created:	15th December 2002
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <vector>
#include "../GL files/glee.h"			//header for OpenGL 1.4
#include "../Maths/Maths.h"
#include "../Log/LOG.h"
#include "../Render Manager/RENDER_MANAGER.h"
#include "BSP.h"

void BSP::CalculateVisibleFaces(const VECTOR3D & position,
								const BOUNDING_VOLUME & volume,
								BITSET & resultBitset)
{
	//If the bitset is not the correct size, resize it
	if(resultBitset.numBits!=numPVSFaces)
		resultBitset.Init(numPVSFaces);
	else
		resultBitset.ClearAll();

	//Calculate cluster "position" is in
	int currentLeaf=CalculateLeaf(position);
	int currentCluster=leaves[currentLeaf].cluster;

	//Loop through leaves
	for(int i=0; i<numLeaves; ++i)
	{
		//If leaf i is not in the PVS for this point, continue
		if(!IsClusterVisible(currentCluster, leaves[i].cluster))
			continue;

		//If this leaf does not lie in the volume, continue
		if(!volume.IsAABoundingBoxInside(leaves[i].boundingBox))
			continue;

		//Loop through faces in this leaf, and mark them as visible
		for(int j=0; j<leaves[i].numFaces; ++j)
			resultBitset.Set(leafFaces[leaves[i].firstLeafFace+j]);
	}

	//Loop through the polygon faces
	for(int i=0; i<numPolygonFaces; ++i)
	{
		//If this face is not set in the bitset, continue
		if(!resultBitset.IsSet(polygonFaces[i].pvsFaceNumber))
			continue;

		//If this face is not in the volume, clear the bit
		if(!volume.IsPolygonInside(	polygonFaces[i].planeEquation,
									polygonFaces[i].numVertexPositions,
									polygonFaces[i].vertexPositions))
			resultBitset.Clear(polygonFaces[i].pvsFaceNumber);
	}

	//Loop through the patches
	for(int i=0; i<numPatches; ++i)
	{
		//If this patch is not set in the bitset, continue
		if(!resultBitset.IsSet(patches[i].pvsFaceNumber))
			continue;

		//If this patch is not in the volume, clear the bit
		if(!volume.IsAABoundingBoxInside(patches[i].boundingBox))
			resultBitset.Clear(patches[i].pvsFaceNumber);
	}
}
