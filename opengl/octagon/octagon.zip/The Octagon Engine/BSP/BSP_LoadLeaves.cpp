//////////////////////////////////////////////////////////////////////////////////////////
//	BSP_LoadLeaves.cpp
//	Load bsp tree leaves
//	Downloaded from: www.paulsprojects.net
//	Created:	15th December 2002
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <vector>
#include "../GL files/glee.h"			//header for OpenGL 1.4
#include "../Maths/Maths.h"
#include "../Log/LOG.h"
#include "../Render Manager/RENDER_MANAGER.h"
#include "BSP.h"

bool BSP::LoadLeaves(FILE * file)
{
	//Calculate number of leaves
	numLeaves=header.directoryEntries[bspLeaves].length/sizeof(BSP_LOAD_LEAF);

	//Create space for this many BSP_LOAD_LEAFs
	BSP_LOAD_LEAF * loadLeaves=new BSP_LOAD_LEAF[numLeaves];
	if(!loadLeaves)
	{
		LOG::Instance()->OutputError("Unable to allocate memory for %d LOAD_LEAFs", numLeaves);
		return false;
	}

	//Read in the LOAD_LEAFs
	fseek(file, header.directoryEntries[bspLeaves].offset, SEEK_SET);
	fread(loadLeaves, header.directoryEntries[bspLeaves].length, 1, file);


	//Create space for BSP_LEAFs
	leaves=new BSP_LEAF[numLeaves];
	if(!leaves)
	{
		LOG::Instance()->OutputError("Unable to allocate space for %d BSP_LEAFs", numLeaves);
		return false;
	}

	//Convert LOAD_LEAFs to LEAFs
	for(int i=0; i<numLeaves; ++i)
	{
		leaves[i].cluster=loadLeaves[i].cluster;
		leaves[i].firstLeafFace=loadLeaves[i].firstLeafFace;
		leaves[i].numFaces=loadLeaves[i].numFaces;

		//Create the bounding box
		//Convert the mins/maxes to our coordinate system
		VECTOR3D tempMins, tempMaxes;
		tempMins.x= (float)loadLeaves[i].mins[0]/64;
		tempMins.y=	(float)loadLeaves[i].mins[2]/64;
		tempMins.z=-(float)loadLeaves[i].maxes[1]/64;

		tempMaxes.x= (float)loadLeaves[i].maxes[0]/64;
		tempMaxes.y= (float)loadLeaves[i].maxes[2]/64;
		tempMaxes.z=-(float)loadLeaves[i].mins[1]/64;

		leaves[i].boundingBox.SetFromMinsMaxes(tempMins, tempMaxes);
	}

	//Free temporary memory
	if(loadLeaves)
		delete [] loadLeaves;
	loadLeaves=NULL;

	return true;
}

