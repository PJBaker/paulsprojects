//////////////////////////////////////////////////////////////////////////////////////////
//	BSP_SendShadowVolumeIndices.cpp
//	Send the vertex indices for shadow volumes to the render manager
//	Downloaded from: www.paulsprojects.net
//	Created:	28th December 2002
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <vector>
#include "../GL files/glee.h"			//header for OpenGL 1.4
#include "../Maths/Maths.h"
#include "../Log/LOG.h"
#include "../Render Manager/RENDER_MANAGER.h"
#include "../Console/CONSOLE.h"
#include "BSP.h"

void BSP::SendShadowVolumeIndices(const POINT_LIGHT & currentLight,
								  const BOUNDING_VOLUME * volume1,
								  const BOUNDING_VOLUME * volume2)
{
	//Loop through polygon faces
	for(int i=0; i<numPolygonFaces; ++i)
	{
		//If the face is not facing the light, continue
		if(!polygonFaces[i].isFacing)
			continue;

		//If this face is not set in the bitset, continue
		if(!currentLight.visibleFaces.IsSet(polygonFaces[i].pvsFaceNumber))
			continue;

		//Calculate if zfail is required
		bool zFailRequired=currentLight.IsPolygonInsideNearClipVolume(
															polygonFaces[i].planeEquation,
															polygonFaces[i].numVertexPositions,
															polygonFaces[i].vertexPositions);

		//Add the edges
		for(int j=0; j<polygonFaces[i].numEdges; ++j)
		{
			RENDER_MANAGER::Instance()->AddShadowVolumeEdge(zFailRequired,
															polygonFaces[i].edgeIndices[j*2+0],
															polygonFaces[i].edgeIndices[j*2+1]);
		}

		//Add the face as caps if using zFail
		if(zFailRequired)
			RENDER_MANAGER::Instance()->AddShadowVolumeCaps(polygonFaces[i].numIndices,
															polygonFaces[i].indices);
	}

	//Loop through patches
	for(int i=0; i<numPatches; ++i)
	{
		//If this patch is not set in the bitset, continue
		if(!currentLight.visibleFaces.IsSet(patches[i].pvsFaceNumber))
			continue;

		//If this patch is not in a given volume, continue
		if(volume1)
			if(!volume1->IsAABoundingBoxInside(patches[i].boundingBox))
				continue;

		if(volume2)
			if(!volume2->IsAABoundingBoxInside(patches[i].boundingBox))
				continue;

		//Calculate if zfail is required for this patch
		bool zFailRequired=currentLight.IsBoundingBoxInsideNearClipVolume(
																		patches[i].boundingBox);


		//Loop through triangles in this patch
		for(int j=0; j<patches[i].numIndices/3; ++j)
		{
			//if this triangle does not face the light, continue
			if(!patches[i].isFacing[j])
				continue;

			//Add silhouette edges
			for(int k=0; k<3; ++k)
			{
				if(	patches[i].neighbourIndices[j*3+k]==-1 ||
					!patches[i].isFacing[patches[i].neighbourIndices[j*3+k]])
				{
					RENDER_MANAGER::Instance()->AddShadowVolumeEdge(zFailRequired,
																patches[i].indices[j*3+k],
																patches[i].indices[j*3+((k+1)%3)]);
				}
			}

			//Add the triangle as caps if using zFail
			if(zFailRequired)
				RENDER_MANAGER::Instance()->AddShadowVolumeCaps(3, &patches[i].indices[j*3]);
		}
	}
}