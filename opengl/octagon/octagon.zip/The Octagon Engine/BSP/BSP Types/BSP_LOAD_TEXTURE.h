//////////////////////////////////////////////////////////////////////////////////////////
//	BSP_LOAD_TEXTURE.h
//	BSP file texture declaration
//	Downloaded from: www.paulsprojects.net
//	Created:	21st November 2002
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////

#ifndef BSP_LOAD_TEXTURE_H
#define BSP_LOAD_TEXTURE_H

//bsp texture as loaded from file
class BSP_LOAD_TEXTURE
{
public:
	char filename[64];
	int flags, contents;
};

#endif	//BSP_LOAD_TEXTURE_H