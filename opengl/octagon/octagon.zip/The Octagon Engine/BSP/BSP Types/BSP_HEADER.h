//////////////////////////////////////////////////////////////////////////////////////////
//	BSP_HEADER.h
//	BSP file header declaration
//	Downloaded from: www.paulsprojects.net
//	Created:	20th November 2002
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////

#ifndef BSP_HEADER_H
#define BSP_HEADER_H

//BSP header directory entry
class BSP_DIRECTORY_ENTRY
{
public:
	int offset;
	int length;
};

//Directory entry types
enum BSP_DIRECTORY_ENTRY_TYPE
{
	bspEntities=0,
	bspTextures,
	bspPlanes,
	bspNodes,
	bspLeaves,
	bspLeafFaces,
	bspLeafBrushes,
	bspModels,
	bspBrushes,
	bspBrushSides,
	bspVertices,
	bspMeshIndices,
	bspEffects,
	bspFaces,
	bspLightmaps,
	bspLightVols,
	bspVisData
};

//BSP file header
class BSP_HEADER
{
public:
	char string[4];
	int version;
	BSP_DIRECTORY_ENTRY directoryEntries[17];
};

#endif	//BSP_HEADER_H