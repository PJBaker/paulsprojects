//////////////////////////////////////////////////////////////////////////////////////////
//	BSP_VISIBILITY_DATA.h
//	BSP PVS holder declaration
//	Downloaded from: www.paulsprojects.net
//	Created:	21st November 2002
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////

#ifndef BSP_VISIBILITY_DATA_H
#define BSP_VISIBILITY_DATA_H

//VIS data table
class BSP_VISIBILITY_DATA
{
public:
	int numClusters;		//number of clusters
	int bytesPerCluster;	//bytes per cluster
	GLubyte * bitset;

	BSP_VISIBILITY_DATA() : bitset(NULL)
	{}
	~BSP_VISIBILITY_DATA()
	{
		if(bitset)
			delete [] bitset;
		bitset=NULL;
	}
};

#endif	//BSP_VISIBILITY_DATA_H