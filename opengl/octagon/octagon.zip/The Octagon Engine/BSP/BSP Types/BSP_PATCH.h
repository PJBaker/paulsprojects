//////////////////////////////////////////////////////////////////////////////////////////
//	BSP_PATCH.h
//	BSP curved surface class
//	Downloaded from: www.paulsprojects.net
//	Created:	3rd January 2003
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////

#ifndef BSP_PATCH_H
#define BSP_PATCH_H

class BSP_PATCH
{
public:
	int surfaceTextureIndex;	//texture index in TEXTURE_MANAGER vector

	//Indices
	int numIndices;
	unsigned int * indices;

	//Plane equation for each triangle after tesselation. (numIndices/3 of them)
	PLANE * planeEquations;

	//Is each triangle facing a given point?
	bool * isFacing;

	// Set isFacing
	void CalculateFacing(const VECTOR3D & point)
	{
		for(int i=0; i<numIndices/3; ++i)
			isFacing[i]=(planeEquations[i].ClassifyPoint(point)==POINT_IN_FRONT_OF_PLANE);
	}

	//Connectivity information
	int * neighbourIndices;

	//The number this face as referred to by the PVS.
	//This is the number of the face in the file
	int pvsFaceNumber;

	//bounding box for this patch
	AA_BOUNDING_BOX boundingBox;

	BSP_PATCH()	:	indices(NULL), planeEquations(NULL), isFacing(NULL), neighbourIndices(NULL)
	{}
	~BSP_PATCH()
	{
		if(indices)
			delete [] indices;
		indices=NULL;

		if(planeEquations)
			delete [] planeEquations;
		planeEquations=NULL;

		if(isFacing)
			delete [] isFacing;
		isFacing=NULL;

		if(neighbourIndices)
			delete [] neighbourIndices;
		neighbourIndices=NULL;
	}
};

#endif	//BSP_PATCH_H