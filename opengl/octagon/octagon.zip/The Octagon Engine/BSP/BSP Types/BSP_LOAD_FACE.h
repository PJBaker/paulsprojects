//////////////////////////////////////////////////////////////////////////////////////////
//	BSP_LOAD_FACE.h
//	BSP file face declaration
//	Downloaded from: www.paulsprojects.net
//	Created:	20th November 2002
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////

#ifndef BSP_LOAD_FACE_H
#define BSP_LOAD_FACE_H

//types of face in the bsp file
enum BSP_LOAD_FACE_TYPE
{
	bspPolygonFace=1,
	bspPatch,
	bspMesh,
	bspBillboard
};

//bsp face as loaded from file
class BSP_LOAD_FACE
{
public:
	int texture;	//texture number
	
	int effect;
	
	int type;		//of BSP_LOAD_FACE_TYPE
	
	int firstVertexIndex;	//in tempVertices array
	int numVertices;
	
	int firstMeshIndex;
	int numMeshIndices;
	
	int lightMapIndex;
	int lightMapStart[2];
	int lightMapSize[2];
	VECTOR3D lightMapOrigin;
	
	VECTOR3D sTangent, tTangent;
	VECTOR3D normal;
	
	int patchSize[2];
};

#endif	//BSP_LOAD_FACE_H