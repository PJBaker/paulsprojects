//////////////////////////////////////////////////////////////////////////////////////////
//	BSP_NODE.h
//	BSP node declaration (splitting point of tree)
//	Downloaded from: www.paulsprojects.net
//	Created:	21st November 2002
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////

#ifndef BSP_NODE_H
#define BSP_NODE_H

//BSP tree node as found in file
class BSP_LOAD_NODE
{
public:
	int planeIndex;				//splitting plane for this node
	int front, back;			//child nodes
	int mins[3];
	int maxes[3];				//AABB
};

//BSP tree node as stored
class BSP_NODE
{
public:
	PLANE splittingPlane;
	int front, back;			//child nodes	
};

#endif	//BSP_NODE_H