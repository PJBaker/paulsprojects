//////////////////////////////////////////////////////////////////////////////////////////
//	BSP_LEAF.h
//	BSP leaf declaration
//	Downloaded from: www.paulsprojects.net
//	Created:	21st November 2002
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////

#ifndef BSP_LEAF_H
#define BSP_LEAF_H

//BSP tree leaf as found in file
class BSP_LOAD_LEAF
{
public:
	int cluster;			//cluster index in VIS data
	int area;				//area portal index
	int mins[3];
	int maxes[3];			//AABB
	int firstLeafFace;		//first index into leaf faces array
	int numFaces;
	int firstLeafBrush;		//first index into leaf brush array
	int numBrushes;
};

//BSP tree leaf as stored
class BSP_LEAF
{
public:
	int cluster;					//VIS data cluster index
	AA_BOUNDING_BOX boundingBox;
	int firstLeafFace;				//first index in the leaf faces array for the leaves in this
	int numFaces;					//leaf. There are numFaces of them.
};

#endif	//BSP_LEAF_H