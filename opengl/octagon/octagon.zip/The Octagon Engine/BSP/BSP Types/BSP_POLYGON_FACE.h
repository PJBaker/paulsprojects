//////////////////////////////////////////////////////////////////////////////////////////
//	BSP_POLYGON_FACE.h
//	BSP polygon face declaration
//	Downloaded from: www.paulsprojects.net
//	Created:	20th November 2002
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////

#ifndef BSP_POLYGON_FACE_H
#define BSP_POLYGON_FACE_H

class BSP_POLYGON_FACE
{
public:
	int surfaceTextureIndex;	//texture index in TEXTURE_MANAGER vector

	int numIndices;			//number of indices for this face
	GLuint * indices;			//indices

	int numVertexPositions;
	VECTOR3D * vertexPositions;	//vertex positions

	//Indices for the end points of each edge, used for shadow volumes
	int numEdges;
	GLuint * edgeIndices;
	
	//The number this face as referred to by the PVS.
	//This is the number of the face in the file
	int pvsFaceNumber;

	PLANE planeEquation;

	//Is this face facing a given point?
	bool isFacing;

	// Set isFacing
	void CalculateFacing(const VECTOR3D & point)
	{	isFacing=(planeEquation.ClassifyPoint(point)==POINT_IN_FRONT_OF_PLANE);	}

	BSP_POLYGON_FACE()	:	indices(NULL), vertexPositions(NULL), edgeIndices(NULL)
	{}
	~BSP_POLYGON_FACE()
	{
		if(indices)
			delete [] indices;
		indices=NULL;

		if(vertexPositions)
			delete [] vertexPositions;
		vertexPositions=NULL;

		if(edgeIndices)
			delete [] edgeIndices;
		edgeIndices=NULL;
	}
};

#endif	//BSP_POLYGON_FACE_H