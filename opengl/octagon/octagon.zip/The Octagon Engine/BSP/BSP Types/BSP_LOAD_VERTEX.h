//////////////////////////////////////////////////////////////////////////////////////////
//	BSP_LOAD_VERTEX.h
//	BSP file vertex declaration
//	Downloaded from: www.paulsprojects.net
//	Created:	20th November 2002
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////

#ifndef BSP_LOAD_VERTEX_H
#define BSP_LOAD_VERTEX_H

//bsp vertex as loaded from file
class BSP_LOAD_VERTEX
{
public:
	VECTOR3D position;
	VECTOR2D decalCoords;
	VECTOR2D lightmapCoords;
	VECTOR3D normal;

	GLubyte color[4];
};

#endif	//BSP_LOAD_VERTEX_H