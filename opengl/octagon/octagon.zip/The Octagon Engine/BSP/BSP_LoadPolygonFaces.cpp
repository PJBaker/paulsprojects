//////////////////////////////////////////////////////////////////////////////////////////
//	BSP_LoadPolygonFaces.cpp
//	Load bsp polygon faces
//	Downloaded from: www.paulsprojects.net
//	Created:	12th December 2002
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <vector>
#include "../GL files/glee.h"			//header for OpenGL 1.4
#include "../Maths/Maths.h"
#include "../Log/LOG.h"
#include "../Render Manager/RENDER_MANAGER.h"
#include "BSP.h"

bool BSP::LoadPolygonFaces(FILE * file)
{
	//Calculate the number of BSP_LOAD_FACEs
	int numLoadFaces=header.directoryEntries[bspFaces].length/sizeof(BSP_LOAD_FACE);

	//Create space for the load faces
	BSP_LOAD_FACE * loadFaces=new BSP_LOAD_FACE[numLoadFaces];
	if(!loadFaces)
	{
		LOG::Instance()->OutputError("Unable to allocate space for %d BSP_LOAD_FACEs",
										numLoadFaces);
		return false;
	}

	//read in the BSP_LOAD_FACEs
	fseek(file, header.directoryEntries[bspFaces].offset, SEEK_SET);
	fread(loadFaces, header.directoryEntries[bspFaces].length, 1, file);


	//Save the number of PVS faces
	numPVSFaces=numLoadFaces;

	//Calculate how many polygon faces there are
	numPolygonFaces=0;

	for(int i=0; i<numLoadFaces; ++i)
	{
		//skip this face if it is not a polygon face
		if(loadFaces[i].type!=bspPolygonFace)
			continue;

		//skip this face if the texture was not loaded
		if(tempTextureIndices[loadFaces[i].texture]==-1)
			continue;

		//skip this face if it has fewer than 3 vertices
		if(loadFaces[i].numVertices<3)
			continue;
		
		++numPolygonFaces;
	}


	//Create space for this many polygon faces
	polygonFaces=new BSP_POLYGON_FACE[numPolygonFaces];
	if(!polygonFaces)
	{
		LOG::Instance()->OutputError("Unable to allocate space for %d BSP_POLYGON_FACEs",
										numPolygonFaces);
		return false;
	}



	//Fill in the polygon faces
	int currentPolygonFace=0;

	for(int i=0; i<numLoadFaces; ++i)
	{
		//skip this face if it is not a polygon face
		if(loadFaces[i].type!=bspPolygonFace)
			continue;

		//skip this face if the texture was not loaded
		if(tempTextureIndices[loadFaces[i].texture]==-1)
			continue;

		//skip this face if it has fewer than 3 vertices
		if(loadFaces[i].numVertices<3)
			continue;

		int numVertices=loadFaces[i].numVertices;

		//Fill in the properties of the face
		polygonFaces[currentPolygonFace].pvsFaceNumber=i;
		polygonFaces[currentPolygonFace].surfaceTextureIndex=
												tempTextureIndices[loadFaces[i].texture];

		//Create space for a temporary array of the vertices for this face
		GEOMETRY_VERTEX * faceVertices=new GEOMETRY_VERTEX[numVertices];
		if(!faceVertices)
		{
			LOG::Instance()->OutputError("Unable to allocate memory for temporary vertex array");
			return false;
		}

		//Fill in the array of vertices
		//reverse winding, and convert to our coordinate system
		for(int j=0; j<numVertices; ++j)
		{
			faceVertices[numVertices-j-1].position.x=
				 tempVertices[loadFaces[i].firstVertexIndex+j].position.x/64;
			faceVertices[numVertices-j-1].position.y=
				 tempVertices[loadFaces[i].firstVertexIndex+j].position.z/64;
			faceVertices[numVertices-j-1].position.z=
				-tempVertices[loadFaces[i].firstVertexIndex+j].position.y/64;

			faceVertices[numVertices-j-1].texCoords.x=
				 tempVertices[loadFaces[i].firstVertexIndex+j].decalCoords.x;
			faceVertices[numVertices-j-1].texCoords.y=
				-tempVertices[loadFaces[i].firstVertexIndex+j].decalCoords.y;
		}

		//Calculate the TSB. Use the first 3 vertices of the face before they were reversed,
		//but in the reversed order.
		//If we use the last 3 before reverse (facevertices[0, 1, 2], we hit problems,
		//probably due to degenerate triangles (stangent=ttangent=normal=0)
		VECTOR3D sTangent, tTangent, normal;
		RENDER_MANAGER::Instance()->CalculateTSB(	faceVertices[numVertices-3],
													faceVertices[numVertices-2],
													faceVertices[numVertices-1],
													normal,	sTangent, tTangent);

		//Save the normal into the plane equation
		polygonFaces[currentPolygonFace].planeEquation.normal=normal;

		//Calculate the intercept of the plane
		polygonFaces[currentPolygonFace].planeEquation.CalculateIntercept(
														faceVertices[numVertices-1].position);

		//Save the tangents & normal into the vertices
		for(int j=0; j<numVertices; ++j)
		{
			faceVertices[j].sTangent=sTangent;
			faceVertices[j].tTangent=tTangent;
			faceVertices[j].normal=normal;
		}

		//send the vertices to the render manager, saving the first index
		int firstVertexIndex=RENDER_MANAGER::Instance()->AddTempGeometryVertex(faceVertices[0]);
		
		for(int j=1; j<numVertices; ++j)
			RENDER_MANAGER::Instance()->AddTempGeometryVertex(faceVertices[j]);


		//Create and fill the array of vertex positions
		polygonFaces[currentPolygonFace].numVertexPositions=numVertices;
		polygonFaces[currentPolygonFace].vertexPositions=new VECTOR3D[numVertices];
		if(!polygonFaces[currentPolygonFace].vertexPositions)
		{
			LOG::Instance()->OutputError("Unable to allocate space for %d vertex positions",
											numVertices);
			return false;
		}
		for(int j=0; j<numVertices; ++j)
			polygonFaces[currentPolygonFace].vertexPositions[j]=faceVertices[j].position;


		//delete temporary vertex array
		if(faceVertices)
			delete [] faceVertices;
		faceVertices=NULL;


		//Fill in the face indices
		//The face is made of a triangle fan with numVertices vertices,
		//first index firstVertexIndex. We need to decompose this to triangles
		polygonFaces[currentPolygonFace].numIndices=3*(numVertices-2);

		//Create space for the indices
		polygonFaces[currentPolygonFace].indices=new GLuint[3*(numVertices-2)];
		if(!polygonFaces[currentPolygonFace].indices)
		{
			LOG::Instance()->OutputError("Unable to allocate space for %d vertex indices",
											3*(numVertices-2));
			return false;
		}

		//Fill in the indices
		int currentIndex=0;

		for(int j=2; j<numVertices; ++j)
		{
			polygonFaces[currentPolygonFace].indices[currentIndex++]=firstVertexIndex;
			polygonFaces[currentPolygonFace].indices[currentIndex++]=firstVertexIndex+j-1;
			polygonFaces[currentPolygonFace].indices[currentIndex++]=firstVertexIndex+j;
		}


		//Fill in the edge indices. These are indices for the end points of each edge
		polygonFaces[currentPolygonFace].numEdges=numVertices;

		polygonFaces[currentPolygonFace].edgeIndices=new GLuint[numVertices*2];
		if(!polygonFaces[currentPolygonFace].edgeIndices)
		{
			LOG::Instance()->OutputError("Unable to allocate space for %d vertex indices",
											numVertices*2);
			return false;
		}

		for(int j=0; j<numVertices; ++j)
		{
			int index1=firstVertexIndex+j;
			int index2=firstVertexIndex+j+1;
			
			//make sure index2 is not too big. If it is, wrap
			if(index2>firstVertexIndex+numVertices-1)
				index2=firstVertexIndex;
			
			polygonFaces[currentPolygonFace].edgeIndices[j*2+0]=index1;
			polygonFaces[currentPolygonFace].edgeIndices[j*2+1]=index2;
		}

		//move on to the next polygon face
		++currentPolygonFace;
	}

	//free temporary memory
	if(loadFaces)
		delete [] loadFaces;
	loadFaces=NULL;

	return true;
}


			


