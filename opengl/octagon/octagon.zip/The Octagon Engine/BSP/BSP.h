//////////////////////////////////////////////////////////////////////////////////////////
//	BSP.h
//	Main header for .bsp map
//	Downloaded from: www.paulsprojects.net
//	Created:	12th December 2002
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	

#ifndef BSP_H
#define BSP_H

#include "../Maths/Maths.h"
#include "../Bounding Volumes/Bounding Volumes.h"
#include "../Bitset/BITSET.h"

#include "BSP types/BSP_HEADER.h"

#include "BSP types/BSP_LOAD_VERTEX.h"

#include "BSP types/BSP_LOAD_TEXTURE.h"

#include "BSP types/BSP_LOAD_FACE.h"
#include "BSP types/BSP_POLYGON_FACE.h"
#include "BSP types/BSP_PATCH.h"

#include "BSP types/BSP_LEAF.h"
#include "BSP types/BSP_NODE.h"
#include "BSP types/BSP_VISIBILITY_DATA.h"

class BSP
{
public:
	//Load BSP
	bool Load(char * filename);

	//Calculate which faces face a given point
	void CalculateFacing(const VECTOR3D & point)
	{
		for(int i=0; i<numPolygonFaces; ++i)
			polygonFaces[i].CalculateFacing(point);

		for(int i=0; i<numPatches; ++i)
			patches[i].CalculateFacing(point);
	}

	//Send indices to render manager
	//return false if none sent
	bool SendPolygonFaceIndices(const BITSET & facesToDraw, bool drawNonFacing);
	bool SendPatchIndices(	const BITSET & facesToDraw, //only draw if the patch is in the volumes
							const BOUNDING_VOLUME * volume1,
							const BOUNDING_VOLUME * volume2);
	void SendShadowVolumeIndices(	const POINT_LIGHT & currentLight,
									const BOUNDING_VOLUME * volume1,
									const BOUNDING_VOLUME * volume2);

	//Collide a camera with the bsp
	void CalculateCollision(WALKING_CAMERA & camera);

	//Draw the bounding boxes of the patches
	void DrawPatchBoundingBoxes(void)
	{
		for(int i=0; i<numPatches; ++i)
			patches[i].boundingBox.Draw();
	}

	//number of faces in the PVS
	int numPVSFaces;
protected:
	//Header
	BSP_HEADER header;



	//Temporary storage for vertices
	int numTempVertices;
	BSP_LOAD_VERTEX * tempVertices;

	bool LoadVertices(FILE * file);




	//Textures

	//Temporarily store the index in the render manager for each texture in the file
	int numLoadTextures;
	int * tempTextureIndices;

	bool LoadTextures(FILE * file);



	//Polygon faces
	int numPolygonFaces;
	BSP_POLYGON_FACE * polygonFaces;

	bool LoadPolygonFaces(FILE * file);


	//Patches
	int numPatches;
	BSP_PATCH * patches;
	
	bool LoadPatches(FILE * file);
	bool TesselateBiquadraticPatch(	const GEOMETRY_VERTEX * controlPoints,
									GEOMETRY_VERTEX * vertices,
									int tesselation);


	//VIS data
public:
	//Which faces are visible from a point & within bounding volume?
	void CalculateVisibleFaces(	const VECTOR3D & position, const BOUNDING_VOLUME & volume,
								BITSET & bitset);

protected:
	//Calculate which leaf a point lies in
	int CalculateLeaf(const VECTOR3D & position);

	//Is one cluster visible from the other?
	bool IsClusterVisible(int cluster1, int cluster2);

	
	//Leaves
	int numLeaves;
	BSP_LEAF * leaves;
	bool LoadLeaves(FILE * file);

	//Leaf faces array
	int * leafFaces;
	bool LoadLeafFaces(FILE * file);

	//nodes
	int numNodes;
	BSP_NODE * nodes;
	bool LoadNodes(FILE * file);

	//VIS data
	BSP_VISIBILITY_DATA visibilityData;
	bool LoadVisibilityData(FILE * file);

public:
	BSP()	:	tempVertices(NULL), tempTextureIndices(NULL),	polygonFaces(NULL),
				patches(NULL),		leaves(NULL),				leafFaces(NULL),
				nodes(NULL)
	{}

	~BSP()
	{
		if(tempVertices)
			delete [] tempVertices;
		if(tempTextureIndices)
			delete [] tempTextureIndices;
		if(polygonFaces)
			delete [] polygonFaces;
		if(patches)
			delete [] patches;
		if(leaves)
			delete [] leaves;
		if(leafFaces)
			delete [] leafFaces;
		if(nodes)
			delete [] nodes;
	}
};

#endif	//BSP_H
