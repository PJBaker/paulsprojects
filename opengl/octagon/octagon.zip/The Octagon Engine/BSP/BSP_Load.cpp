//////////////////////////////////////////////////////////////////////////////////////////
//	BSP_Load.cpp
//	Main bsp loading file
//	Downloaded from: www.paulsprojects.net
//	Created:	12th December 2002
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <vector>
#include "../GL files/glee.h"			//header for OpenGL 1.4
#include "../Maths/Maths.h"
#include "../Log/LOG.h"
#include "../Render Manager/RENDER_MANAGER.h"
#include "BSP.h"

bool BSP::Load(char * filename)
{
	LOG::Instance()->OutputNewLine();
	LOG::Instance()->OutputSuccess("Loading %s", filename);

	FILE * file;

	//Open the BSP file
	file=fopen(filename, "rb");
	if(!file)
	{
		LOG::Instance()->OutputError("Unable to open %s", filename);
		return false;
	}

	//Read in the header
	fread(&header, sizeof(BSP_HEADER), 1, file);

	//Verify the header is correct
	if(strncmp(header.string, "IBSP", 4)!=0 || header.version!=0x2E)
	{
		LOG::Instance()->OutputError("%s is not a legal Quake 3 .bsp file", filename);
		return false;
	}

	//Load vertices
	if(!LoadVertices(file))
		return false;

	//Load textures
	if(!LoadTextures(file))
		return false;

	//Load polygon faces
	if(!LoadPolygonFaces(file))
		return false;

	//Load patches
	if(!LoadPatches(file))
		return false;

	//Load leaves of BSP tree
	if(!LoadLeaves(file))
		return false;

	//Load leaf faces array
	//Holds indices of faces in a leaf
	if(!LoadLeafFaces(file))
		return false;

	//Load nodes of BSP tree
	if(!LoadNodes(file))
		return false;

	//Load PVS Data
	if(!LoadVisibilityData(file))
		return false;

	//close file
	fclose(file);

	//Delete temporary arrays
	if(tempVertices)
		delete [] tempVertices;
	tempVertices=NULL;

	if(tempTextureIndices)
		delete [] tempTextureIndices;
	tempTextureIndices=NULL;

	LOG::Instance()->OutputSuccess("%s loaded successfully!", filename);
	LOG::Instance()->OutputNewLine();
	return true;
}