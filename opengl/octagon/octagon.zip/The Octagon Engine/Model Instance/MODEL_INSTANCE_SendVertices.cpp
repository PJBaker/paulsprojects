//////////////////////////////////////////////////////////////////////////////////////////
//	MODEL_INSTANCE_SendVertices.cpp
//	Send vertices to the render manager
//	Downloaded from: www.paulsprojects.net
//	Created:	2nd January 2003
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <vector>
#include "../GL files/glee.h"
#include "../Maths/Maths.h"
#include "../Log/LOG.h"
#include "../Bounding Volumes/Bounding Volumes.h"
#include "../Render Manager/RENDER_MANAGER.h"
#include "../Console/CONSOLE.h"
#include "../Point Light/POINT_LIGHT.h"
#include "../Models/MODEL_MANAGER.h"
#include "MODEL_INSTANCE.h"

bool MODEL_INSTANCE::SendVertices(const VECTOR3D & position, const float angleYaw)
{
	firstGeometryVertexIndex=MODEL_MANAGER::Instance()->SendVertices(	modelDataIndex,
																		position,
																		angleYaw);
	
	numGeometryVertices=MODEL_MANAGER::Instance()->GetNumVertices(modelDataIndex);

	numTriangles=MODEL_MANAGER::Instance()->GetNumTriangles(modelDataIndex);

	//Create space for the plane equations
	planeEquations=new PLANE[numTriangles];
	if(!planeEquations)
	{
		LOG::Instance()->OutputError("Unable to create space for %d planes", numTriangles);
		return false;
	}

	return true;
}

