//////////////////////////////////////////////////////////////////////////////////////////
//	MODEL_INSTANCE_Update.cpp
//	Update vertices in the render manager
//	Downloaded from: www.paulsprojects.net
//	Created:	2nd January 2003
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <vector>
#include "../GL files/glee.h"
#include "../Maths/Maths.h"
#include "../Log/LOG.h"
#include "../Bounding Volumes/Bounding Volumes.h"
#include "../Render Manager/RENDER_MANAGER.h"
#include "../Console/CONSOLE.h"
#include "../Point Light/POINT_LIGHT.h"
#include "../Models/MODEL_MANAGER.h"
#include "MODEL_INSTANCE.h"

void MODEL_INSTANCE::Update(ANIM_SEQUENCE animSequence, float distanceThroughAnimSequence,
							const VECTOR3D & position, const float angleYaw)
{
	//Update model vertices
	MODEL_MANAGER::Instance()->UpdateVertices(	modelDataIndex,
												animSequence,
												distanceThroughAnimSequence,
												firstGeometryVertexIndex,
												position,
												angleYaw);

	//Update plane equations
	MODEL_MANAGER::Instance()->GetPlaneEquations(	modelDataIndex,
													firstGeometryVertexIndex,
													planeEquations);
}

