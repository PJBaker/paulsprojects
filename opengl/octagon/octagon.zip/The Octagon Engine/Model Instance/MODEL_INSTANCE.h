//////////////////////////////////////////////////////////////////////////////////////////
//	MODEL_INSTANCE.h
//	A single instance of a model
//	Downloaded from: www.paulsprojects.net
//	Created:	2nd January 2003
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	

#ifndef MODEL_INSTANCE_H
#define MODEL_INSTANCE_H

class MODEL_INSTANCE
{
public:
	bool Init(char * filename, const VECTOR3D & position, float angleYaw)
	{
		modelDataIndex=MODEL_MANAGER::Instance()->CreateModel(filename);
		
		if(modelDataIndex==-1)
			return false;

		//Send vertices to render manager
		SendVertices(position, angleYaw);

		return true;
	}

	//Send the vertices to the render manager
	bool SendVertices(const VECTOR3D & position, const float angleYaw);

	//Update (inc. vertices)
	void Update(ANIM_SEQUENCE animSequence, float distanceThroughAnimSequence,
				const VECTOR3D & position, const float angleYaw);

	//Send Indices
	void SendGeometryIndices()
	{
		MODEL_MANAGER::Instance()->SendIndices(modelDataIndex, firstGeometryVertexIndex);
	}

	void SendShadowVolumeIndices(bool zFailRequired, const POINT_LIGHT & currentLight)
	{
		MODEL_MANAGER::Instance()->SendShadowVolumeIndices(	zFailRequired,
															currentLight.boundingSphere.centre,
															modelDataIndex,
															firstGeometryVertexIndex,
															planeEquations);
	}

	//Model data index in the model manager
	int modelDataIndex;

	//Vertices
	int firstGeometryVertexIndex;
	int numGeometryVertices;

	//Plane equations for each triangle in the current frame & position
	int numTriangles;
	PLANE * planeEquations;

public:
	MODEL_INSTANCE()	:	planeEquations(NULL)
	{}
	~MODEL_INSTANCE()
	{
		if(planeEquations)
			delete [] planeEquations;
		planeEquations=NULL;
	}
};

#endif	//MODEL_INSTANCE_H
