//////////////////////////////////////////////////////////////////////////////////////////
//	PARTICLE_SYSTEM_SendIndices.cpp
//	Send particle indices to draw to the render manager
//	Downloaded from: www.paulsprojects.net
//	Created:	22nd December 2002
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <vector>
#include "../GL files/glee.h"			//header for OpenGL 1.4
#include "../Maths/Maths.h"
#include "../Log/LOG.h"
#include "../Bounding Volumes/Bounding Volumes.h"
#include "../List/LIST.h"
#include "../Render Manager/RENDER_MANAGER.h"
#include "PARTICLE_SYSTEM.h"

bool PARTICLE_SYSTEM::SendIndices(bool sendSelfLit, bool sendNonSelfLit)
{
	bool anySent=false;

	if((selfLit && sendSelfLit) || (!selfLit && sendNonSelfLit))
	{
		RENDER_MANAGER::Instance()->AddParticleArray(	particleTextureIndex,
														firstParticleIndex,
														maxParticles);
		anySent=true;
	}

	return anySent;
}
