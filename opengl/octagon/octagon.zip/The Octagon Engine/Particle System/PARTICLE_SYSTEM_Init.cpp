//////////////////////////////////////////////////////////////////////////////////////////
//	PARTICLE_SYSTEM_Init.cpp
//	Initiate particle system loading parameters from a file
//	Downloaded from: www.paulsprojects.net
//	Created:	22nd December 2002
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <vector>
#include "../GL files/glee.h"			//header for OpenGL 1.4
#include "../Maths/Maths.h"
#include "../Log/LOG.h"
#include "../Bounding Volumes/Bounding Volumes.h"
#include "../List/LIST.h"
#include "../Render Manager/RENDER_MANAGER.h"
#include "PARTICLE_SYSTEM.h"

bool PARTICLE_SYSTEM::Init(char * filename)
{
	//Open the file to read in the properties of this system
	FILE * file=fopen(filename, "rt");
	if(!file)
	{
		LOG::Instance()->OutputError("Unable to open %s", filename);
		return false;
	}

	//Read in the texture filename
	char textureFilename[128];
	fscanf(file, "Texture Filename: %s ", textureFilename);

	if(particleTextureIndex=
					RENDER_MANAGER::Instance()->CreateParticleTexture(textureFilename)==-1)
		return false;

	//Read in the maximum number of particles
	fscanf(file, "Max Particles: %d ", &maxParticles);

	//Create space
	particles=new PARTICLE[maxParticles];
	particleProperties=new PARTICLE_PROPERTIES[maxParticles];
	if(!particles || !particleProperties)
	{
		LOG::Instance()->OutputError("Unable to create space for %d particles", maxParticles);
		return false;
	}

	firstParticleIndex=RENDER_MANAGER::Instance()->AddParticles(maxParticles);

	//Set the particles to be reset
	for(int i=0; i<maxParticles; ++i)
		particleProperties[i].lifeLeft=0.0f;

	//Set the particle system properties
	fscanf(file, "Emitter Position: (%f, %f, %f) ", &emitterPosition.x,
													&emitterPosition.y,
													&emitterPosition.z);
	
	fscanf(file, "Emitter Range: (%f, %f, %f) ",&emitterRange.x,
												&emitterRange.y,
												&emitterRange.z);

	int systemSelfLit;
	fscanf(file, "Self Lit: %d ", &systemSelfLit);
	selfLit=systemSelfLit==0 ? false : true;		//convert to bool
	
	fscanf(file, "Average Life: %f ",&avLife);
	fscanf(file, "Life Range: %f ",&rangeLife);

	fscanf(file, "Average Velocity: (%f, %f, %f) ",	&avVelocity.x,
													&avVelocity.y,
													&avVelocity.z);

	fscanf(file, "Velocity Range: (%f, %f, %f) ",	&rangeVelocity.x,
													&rangeVelocity.y,
													&rangeVelocity.z);

	fscanf(file, "Average Initial Color: (%f, %f, %f, %f) ",&avInitColor.r,
															&avInitColor.g,
															&avInitColor.b,
															&avInitColor.a);

	fscanf(file, "Initial Color Range: (%f, %f, %f, %f) ",	&rangeInitColor.r,
															&rangeInitColor.g,
															&rangeInitColor.b,
															&rangeInitColor.a);

	fscanf(file, "Average Final Color: (%f, %f, %f, %f) ",	&avFinalColor.r,
															&avFinalColor.g,
															&avFinalColor.b,
															&avFinalColor.a);

	fscanf(file, "Final Color Range: (%f, %f, %f, %f) ",	&rangeFinalColor.r,
															&rangeFinalColor.g,
															&rangeFinalColor.b,
															&rangeFinalColor.a);

	fscanf(file, "Average Initial Size: %f ",&avInitSize);
	fscanf(file, "Initial Size Range: %f ",&rangeInitSize);
	
	fscanf(file, "Average Final Size: %f ",&avFinalSize);
	fscanf(file, "Final Size Range: %f ",&rangeFinalSize);

	fscanf(file, "Acceleration: (%f, %f, %f) ",	&acceleration.x,
												&acceleration.y,
												&acceleration.z);

	fclose(file);
	
	return true;
}
