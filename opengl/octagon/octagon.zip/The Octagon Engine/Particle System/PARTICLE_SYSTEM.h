//////////////////////////////////////////////////////////////////////////////////////////
//	PARTICLE_SYSTEM.h
//	Main header for a particle system
//	Downloaded from: www.paulsprojects.net
//	Created:	20th December 2002
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	

#ifndef PARTICLE_SYSTEM_H
#define PARTICLE_SYSTEM_H

#include "PARTICLE_PROPERTIES.h"

class PARTICLE_SYSTEM
{
public:
	bool Init(char * filename);

	void Update(double timePassed,
				const VECTOR3D & entityPosition,
				float entityAngleYaw);

	bool SendIndices(bool sendSelfLit, bool sendNonSelfLit);

	//Accessors
	int GetMaxParticles()
	{	return maxParticles;	}

	VECTOR3D GetParticlePosition(int particleNumber)
	{	return particles[particleNumber].position;	}

protected:
	//first particle index in the render manager
	int firstParticleIndex;

	//texture index in render manager
	int particleTextureIndex;

	int maxParticles;
	
	PARTICLE * particles;			//kept separate for easy transfer to render manager
									
	PARTICLE_PROPERTIES * particleProperties;

	//Emitter position
	VECTOR3D emitterPosition;

	//Are the particles self-lit?
	bool selfLit;
	
	//Particle properties when reset
	//average and deviation. Vectors are treated componentwise
	VECTOR3D emitterRange;

	float avLife, rangeLife;
			
	VECTOR3D avVelocity, rangeVelocity;

	COLOR avInitColor, rangeInitColor;
	COLOR avFinalColor, rangeFinalColor;

	float avInitSize, rangeInitSize;
	float avFinalSize, rangeFinalSize;

	//Properties of all particles
	VECTOR3D acceleration;

public:

	PARTICLE_SYSTEM()	:	particles(NULL), particleProperties(NULL)
	{}
	~PARTICLE_SYSTEM()
	{
		if(particles)
			delete [] particles;
		particles=NULL;

		if(particleProperties)
			delete [] particleProperties;
		particleProperties=NULL;
	}
};

#endif	//PARTICLE_SYSTEM_H
