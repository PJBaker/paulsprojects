//////////////////////////////////////////////////////////////////////////////////////////
//	PARTICLE_SYSTEM_Update.cpp
//	Update the particle system
//	Downloaded from: www.paulsprojects.net
//	Created:	22nd December 2002
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <vector>
#include "../GL files/glee.h"			//header for OpenGL 1.4
#include "../Maths/Maths.h"
#include "../Log/LOG.h"
#include "../Bounding Volumes/Bounding Volumes.h"
#include "../List/LIST.h"
#include "../Render Manager/RENDER_MANAGER.h"
#include "PARTICLE_SYSTEM.h"

void PARTICLE_SYSTEM::Update(	double timePassed,
								const VECTOR3D & entityPosition,
								float entityAngleYaw)
{
	//Work with time in seconds
	float timeInSecs=float(timePassed/1000);

	//Calculate emitterPosition in world space
	VECTOR3D worldEmitterPos=emitterPosition.GetRotatedY(entityAngleYaw);
	worldEmitterPos+=entityPosition;

	//Update particles
	for(int i=0; i<maxParticles; ++i)
	{
		//If the particle is dead, reset it
		if(particleProperties[i].lifeLeft<=0.0)
		{
			particles[i].position.x=worldEmitterPos.x +
											2*(((float)rand()/RAND_MAX)-0.5f)*emitterRange.x;
			particles[i].position.y=worldEmitterPos.y +
											2*(((float)rand()/RAND_MAX)-0.5f)*emitterRange.y;
			particles[i].position.z=worldEmitterPos.z +
											2*(((float)rand()/RAND_MAX)-0.5f)*emitterRange.z;

			particleProperties[i].initialColor.r=avInitColor.r+
											2*(((float)rand()/RAND_MAX)-0.5f)*rangeInitColor.r;
			particleProperties[i].initialColor.g=avInitColor.g+
											2*(((float)rand()/RAND_MAX)-0.5f)*rangeInitColor.g;
			particleProperties[i].initialColor.b=avInitColor.b+
											2*(((float)rand()/RAND_MAX)-0.5f)*rangeInitColor.b;
			particleProperties[i].initialColor.a=avInitColor.a+
											2*(((float)rand()/RAND_MAX)-0.5f)*rangeInitColor.a;

			particleProperties[i].finalColor.r=avFinalColor.r+
											2*(((float)rand()/RAND_MAX)-0.5f)*rangeFinalColor.r;
			particleProperties[i].finalColor.g=avFinalColor.g+
											2*(((float)rand()/RAND_MAX)-0.5f)*rangeFinalColor.g;
			particleProperties[i].finalColor.b=avFinalColor.b+
											2*(((float)rand()/RAND_MAX)-0.5f)*rangeFinalColor.b;
			particleProperties[i].finalColor.a=avFinalColor.a+
											2*(((float)rand()/RAND_MAX)-0.5f)*rangeFinalColor.a;

			particles[i].color=particleProperties[i].initialColor;

			particleProperties[i].initialSize=avInitSize+
												2*(((float)rand()/RAND_MAX)-0.5f)*rangeInitSize;
			particleProperties[i].finalSize=avFinalSize+
												2*(((float)rand()/RAND_MAX)-0.5f)*rangeFinalSize;
			
			particles[i].size=particleProperties[i].initialSize;
			
			particleProperties[i].totalLife=avLife + 2*(((float)rand()/RAND_MAX)-0.5f)*rangeLife;
			particleProperties[i].lifeLeft=particleProperties[i].totalLife;
						
			particleProperties[i].velocity.x=avVelocity.x+2*(((float)rand()/RAND_MAX)-0.5f)*rangeVelocity.x;
			particleProperties[i].velocity.y=avVelocity.y+2*(((float)rand()/RAND_MAX)-0.5f)*rangeVelocity.y;
			particleProperties[i].velocity.z=avVelocity.z+2*(((float)rand()/RAND_MAX)-0.5f)*rangeVelocity.z;
	
			particleProperties[i].acceleration=acceleration;

			particles[i].selfLit=selfLit;

			continue;
		}

		//Otherwise, update it
				
		//Calculate new life
		particleProperties[i].lifeLeft-=timeInSecs;

		//Calculate the interpolation factor for color, size etc
		float interpolationFactor=1.0f-particleProperties[i].lifeLeft/
																particleProperties[i].totalLife;

		//Calculate new velocity (v=u+at)
		VECTOR3D newVelocity=particleProperties[i].velocity+
													particleProperties[i].acceleration*timeInSecs;

		//Calculate new position (s=t*(u+v)/2)
		particles[i].position+=timeInSecs*(particleProperties[i].velocity+newVelocity)/2;

		particleProperties[i].velocity=newVelocity;

		//Calculate new color
		particles[i].color=
			particleProperties[i].initialColor.lerp(particleProperties[i].finalColor, 
													interpolationFactor);

		//Calculate new size
		particles[i].size=	particleProperties[i].initialSize*(1.0f-interpolationFactor)+
							particleProperties[i].finalSize*interpolationFactor;
															
	}
	
	//Send to render manager
	RENDER_MANAGER::Instance()->UpdateParticles(firstParticleIndex,
												maxParticles,
												particles);
}