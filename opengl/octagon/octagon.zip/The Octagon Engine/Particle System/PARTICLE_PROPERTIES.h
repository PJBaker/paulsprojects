//////////////////////////////////////////////////////////////////////////////////////////
//	PARTICLE_PROPERTIES.h
//	Class for an individual particle.
//	Holds properties which are not required by the render manager
//	Downloaded from: www.paulsprojects.net
//	Created:	20th December 2002
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	

#ifndef PARTICLE_PROPERTIES_H
#define PARTICLE_PROPERTIES_H

class PARTICLE_PROPERTIES
{
public:
	VECTOR3D velocity;
	VECTOR3D acceleration;

	float totalLife;	//total life in seconds
	float lifeLeft;	//life remaining

	COLOR initialColor;	//color when born
	COLOR finalColor;	//color at lifeLeft==0

	float initialSize;
	float finalSize;
};

#endif	//PARTICLE_PROPERTIES_H