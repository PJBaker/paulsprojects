//////////////////////////////////////////////////////////////////////////////////////////
//	States.h
//	Header for different state settings
//	Downloaded from: www.paulsprojects.net
//	Created:	15th November 2002
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////

#ifndef STATES_H
#define STATES_H

#include "../Point Light/POINT_LIGHT.h"

//Orthographic states
void SetOrthoStates(void);
void EndOrthoStates(void);

//Ambient pass states
void SetAmbientStates(void);
void EndAmbientStates(void);

//Shadow volume states
void SetShadowStates(void);
void SetShadowPass1States(bool useZFail);
bool SetShadowPass2States(bool useZFail);
void EndShadowStates(void);

//States for drawing particles
void SetSelfLitParticleStates(void);
void EndSelfLitParticleStates(void);

void SetNonSelfLitParticleStates(const POINT_LIGHT & currentLight);
void EndNonSelfLitParticleStates(const POINT_LIGHT & currentLight);

//States for performing an occlusion test
void SetOcclusionTestStates(void);
GLboolean EndOcclusionTestStates(void);

#endif	//STATES_H