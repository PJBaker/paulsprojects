//////////////////////////////////////////////////////////////////////////////////////////
//	ParticleStates.cpp
//	Set and end states for drawing particles
//	Downloaded from: www.paulsprojects.net
//	Created:	2nd January 2003
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <vector>
#include "../GL files/glee.h"	//library for OGL 1.4
#include <GL/glu.h>
#include "../Maths/Maths.h"
#include "../Log/LOG.h"
#include "../Render Manager/RENDER_MANAGER.h"
#include "States.h"

void SetSelfLitParticleStates(void)
{
	//Enable textures
	glEnable(GL_TEXTURE_2D);

	//Disable depth writes
	glDepthMask(0);

	//Enable blend
	glBlendFunc(GL_SRC_ALPHA, GL_ONE);
	glEnable(GL_BLEND);
}

void EndSelfLitParticleStates(void)
{
	glDisable(GL_TEXTURE_2D);

	glDepthMask(1);
	
	glDisable(GL_BLEND);
}

void SetNonSelfLitParticleStates(const POINT_LIGHT & currentLight)
{
	//If we have a projected cube map, enable texgen and set up texture matrix on unit 1
	if(currentLight.hasCubeMap)
	{
		glActiveTexture(GL_TEXTURE1);
	
		//Object linear texgen
		glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);
		glTexGenfv(GL_S, GL_OBJECT_PLANE, VECTOR4D(1.0f, 0.0f, 0.0f, 0.0f));
		glEnable(GL_TEXTURE_GEN_S);

		glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);
		glTexGenfv(GL_T, GL_OBJECT_PLANE, VECTOR4D(0.0f, 1.0f, 0.0f, 0.0f));
		glEnable(GL_TEXTURE_GEN_T);

		glTexGeni(GL_R, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);
		glTexGenfv(GL_R, GL_OBJECT_PLANE, VECTOR4D(0.0f, 0.0f, 1.0f, 0.0f));
		glEnable(GL_TEXTURE_GEN_R);

		//set up texture matrix to calculate light->vertex vector
		glMatrixMode(GL_TEXTURE);
		glLoadIdentity();
		VECTOR3D translation=-currentLight.boundingSphere.centre;
		glTranslatef(translation.x, translation.y, translation.z);
		glMatrixMode(GL_MODELVIEW);

		glActiveTexture(GL_TEXTURE0);
	}

	//Enable textures
	//Unit 0 - decal
	glEnable(GL_TEXTURE_2D);

	//Unit 1 - light's projected cube map if it has one
	if(currentLight.hasCubeMap)
	{
		glActiveTexture(GL_TEXTURE1);
		RENDER_MANAGER::Instance()->BindCubeMapTexture(currentLight.cubeMapIndex);
		glEnable(GL_TEXTURE_CUBE_MAP);
		glActiveTexture(GL_TEXTURE0);
	}
	
	//Use COMBINE texenv:	rgb=col0*tex0(*tex1)
	//						alpha=col0
	glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_COMBINE);

	glTexEnvi(GL_TEXTURE_ENV, GL_SOURCE0_RGB, GL_PRIMARY_COLOR);
	glTexEnvi(GL_TEXTURE_ENV, GL_COMBINE_RGB, GL_MODULATE);
	glTexEnvi(GL_TEXTURE_ENV, GL_SOURCE1_RGB, GL_TEXTURE);

	glTexEnvi(GL_TEXTURE_ENV, GL_SOURCE0_ALPHA, GL_PRIMARY_COLOR);
	glTexEnvi(GL_TEXTURE_ENV, GL_COMBINE_ALPHA, GL_REPLACE);
	
	if(currentLight.hasCubeMap)
	{
		glActiveTexture(GL_TEXTURE1);

		glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_COMBINE);

		glTexEnvi(GL_TEXTURE_ENV, GL_SOURCE0_RGB, GL_PREVIOUS);
		glTexEnvi(GL_TEXTURE_ENV, GL_COMBINE_RGB, GL_MODULATE);
		glTexEnvi(GL_TEXTURE_ENV, GL_SOURCE1_RGB, GL_TEXTURE);

		glTexEnvi(GL_TEXTURE_ENV, GL_SOURCE0_ALPHA, GL_PREVIOUS);
		glTexEnvi(GL_TEXTURE_ENV, GL_COMBINE_ALPHA, GL_REPLACE);
	
		glActiveTexture(GL_TEXTURE0);
	}

	//Disable depth writes
	glDepthMask(0);

	//Enable blend
	glBlendFunc(GL_SRC_ALPHA, GL_ONE);
	glEnable(GL_BLEND);
}

void EndNonSelfLitParticleStates(const POINT_LIGHT & currentLight)
{
	//Reset texgen if necessary
	if(currentLight.hasCubeMap)
	{
		glActiveTexture(GL_TEXTURE1);
	
		glDisable(GL_TEXTURE_GEN_S);
		glDisable(GL_TEXTURE_GEN_T);
		glDisable(GL_TEXTURE_GEN_R);

		glMatrixMode(GL_TEXTURE);
		glLoadIdentity();
		glMatrixMode(GL_MODELVIEW);

		glActiveTexture(GL_TEXTURE0);
	}

	//disable textures
	glDisable(GL_TEXTURE_2D);

	if(currentLight.hasCubeMap)
	{
		glActiveTexture(GL_TEXTURE1);
		glDisable(GL_TEXTURE_CUBE_MAP);
		glActiveTexture(GL_TEXTURE0);
	}

	//reset to modulate texenv
	glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);

	if(currentLight.hasCubeMap)
	{
		glActiveTexture(GL_TEXTURE1);
		glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
		glActiveTexture(GL_TEXTURE0);
	}

	glDepthMask(1);
	
	glDisable(GL_BLEND);
}

