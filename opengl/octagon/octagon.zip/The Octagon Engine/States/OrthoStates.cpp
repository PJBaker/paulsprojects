//////////////////////////////////////////////////////////////////////////////////////////
//	OrthoStates.cpp
//	Set and end states for ortho mode
//	Downloaded from: www.paulsprojects.net
//	Created:	15th November 2002
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include "../GL files/glee.h"	//library for OGL 1.4
#include <GL/glu.h>
#include "../Maths/Maths.h"
#include "../Log/LOG.h"
#include "States.h"

void SetOrthoStates(void)
{
	//Set matrices
	glMatrixMode(GL_PROJECTION);
	glPushMatrix();
	glLoadIdentity();
	gluOrtho2D(-1.0f, 1.0f, -1.0f, 1.0f);

	glMatrixMode(GL_MODELVIEW);
	glPushMatrix();
	glLoadIdentity();

	//other states
	glDisable(GL_DEPTH_TEST);
}

void EndOrthoStates(void)
{
	//Restore matrices
	glMatrixMode(GL_PROJECTION);
	glPopMatrix();
	glMatrixMode(GL_MODELVIEW);
	glPopMatrix();

	//restore other states
	glEnable(GL_DEPTH_TEST);
}