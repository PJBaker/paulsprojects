//////////////////////////////////////////////////////////////////////////////////////////
//	ShadowStates.cpp
//	Set and end states for shadow volumes
//	Downloaded from: www.paulsprojects.net
//	Created:	28th December 2002
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include "../GL files/glee.h"	//library for OGL 1.4
#include <GL/glu.h>
#include "../Maths/Maths.h"
#include "../Log/LOG.h"
#include "States.h"

void SetShadowStates(void)
{
	glDepthFunc(GL_LESS);
	glDepthMask(0);

	glShadeModel(GL_FLAT);
	glColorMask(0, 0, 0, 0);

	glStencilFunc(GL_ALWAYS, 1, ~0);
	glEnable(GL_STENCIL_TEST);

	//begin with pass 1 states
	SetShadowPass1States(true);
}

//Set states for pass 1
void SetShadowPass1States(bool useZFail)
{
	if(useZFail)
	{
		glCullFace(GL_FRONT);
		glStencilOp(GL_KEEP, GL_INCR, GL_KEEP);
	}
	else
	{
		glCullFace(GL_BACK);
		glStencilOp(GL_KEEP, GL_KEEP, GL_INCR);
	}
}

//Set states for pass 2. Return false if no 2nd pass is required
//2 sided stencil - todo
bool SetShadowPass2States(bool useZFail)
{
	if(useZFail)
	{
		glCullFace(GL_BACK);
		glStencilOp(GL_KEEP, GL_DECR, GL_KEEP);
	}
	else
	{
		glCullFace(GL_FRONT);
		glStencilOp(GL_KEEP, GL_KEEP, GL_DECR);
	}

	return true;
}

void EndShadowStates(void)
{
	glDepthFunc(GL_LEQUAL);
	glDepthMask(1);

	glShadeModel(GL_SMOOTH);
	glColorMask(1, 1, 1, 1);

	glDisable(GL_STENCIL_TEST);

	glCullFace(GL_BACK);
}