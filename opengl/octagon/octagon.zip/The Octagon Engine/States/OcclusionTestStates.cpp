//////////////////////////////////////////////////////////////////////////////////////////
//	OcclusionStates.cpp
//	Set and end states for doing an occlusion test
//	Downloaded from: www.paulsprojects.net
//	Created:	20th December 2002
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include "../GL files/glee.h"	//library for OGL 1.4
#include "../Maths/Maths.h"
#include "../Log/LOG.h"
#include "States.h"

void SetOcclusionTestStates()
{
	//Prevent buffer writes
	glColorMask(0, 0, 0, 0);
	glDepthMask(0);

	glShadeModel(GL_FLAT);

	//enable occlusion test
	glEnable(GL_OCCLUSION_TEST_HP);
}

GLboolean EndOcclusionTestStates()
{
	//Disable occlusion test
	glDisable(GL_OCCLUSION_TEST_HP);

	glColorMask(1, 1, 1, 1);
	glDepthMask(1);

	glShadeModel(GL_SMOOTH);

	//read the result
	GLboolean result;
	glGetBooleanv(GL_OCCLUSION_TEST_RESULT_HP, &result);
	
	return result;
}