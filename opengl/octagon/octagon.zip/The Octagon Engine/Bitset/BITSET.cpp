//////////////////////////////////////////////////////////////////////////////////////////
//	BITSET.cpp
//	Functions for class for set of bits used to represent an array of booleans
//	Downloaded from: www.paulsprojects.net
//	Created:	8th August 2002
//	Modified:	10th November 2002	-	Added OR, XOR
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	
#include <memory.h>
#include "../Log/LOG.h"
#include "BITSET.h"

//Init bitset
bool BITSET::Init(int newNumBits)
{
	//delete any memory already allocated to bits
	if(bits)
		delete [] bits;
	bits=NULL;

	//set size
	numBits=newNumBits;
	numBytes=(numBits>>3)+1;

	//Allocate memory for bits
	bits=new unsigned char[numBytes];
	if(!bits)
	{
		LOG::Instance()->OutputError("Unable to allocate space for a bitset of %d bits", numBits);
		return false;
	}

	ClearAll();

	return true;
}

//Clear bits
void BITSET::ClearAll()
{
	memset(bits, 0, numBytes);
}

//Set a bit
void BITSET::Set(int bitNumber)
{
	if(bitNumber<numBits)
		bits[bitNumber>>3] |= 1<<(bitNumber & 7);
}

//Clear a bit
void BITSET::Clear(int bitNumber)
{
	if(bitNumber<numBits)
		bits[bitNumber>>3] &= ~(1<<(bitNumber & 7));
}

//Is a bit set?
bool BITSET::IsSet(int bitNumber) const
{
	if(bitNumber<numBits && (bits[bitNumber>>3] & (1<<(bitNumber & 7)))!=0)
		return true;

	return false;
}

//Are any bits set?
bool BITSET::AreAnySet() const
{
	for(int i=0; i<numBytes; ++i)
	{
		if(bits[i]!=0)
			return true;
	}

	return false;
}

//Logical AND two equally sized bitsets
void BITSET::And(const BITSET & rhs, BITSET & result) const
{
	if(numBits!=rhs.numBits)
	{
		LOG::Instance()->OutputError("Trying to AND two non-equal bitsets");
		return;
	}

	//If the result bitset is not the correct size, resize it
	if(result.numBits!=numBits)
		result.Init(numBits);
	else
		result.ClearAll();

	for(int i=0; i<numBytes; ++i)
	{
		result.bits[i]=bits[i] & rhs.bits[i];
	}
}

//Logical OR two equally sized bitsets
void BITSET::Or(const BITSET & rhs, BITSET & result) const
{
	if(numBits!=rhs.numBits)
	{
		LOG::Instance()->OutputError("Trying to OR two non-equal bitsets");
		return;
	}

	result.ClearAll();

	for(int i=0; i<numBytes; ++i)
	{
		result.bits[i]=bits[i] | rhs.bits[i];
	}
}

//Logical XOR two equally sized bitsets
void BITSET::Xor(const BITSET & rhs, BITSET & result) const
{
	if(numBits!=rhs.numBits)
	{
		LOG::Instance()->OutputError("Trying to XOR two non-equal bitsets");
		return;
	}

	result.ClearAll();

	for(int i=0; i<numBytes; ++i)
	{
		result.bits[i]=bits[i] ^ rhs.bits[i];
	}
}

