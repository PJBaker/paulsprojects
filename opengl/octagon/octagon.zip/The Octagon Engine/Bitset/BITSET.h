//////////////////////////////////////////////////////////////////////////////////////////
//	BITSET.h
//	Class declaration for a set of bits, representing array of booleans
//	Downloaded from: www.paulsprojects.net
//	Created:	8th August 2002
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	

#ifndef BITSET_H
#define BITSET_H

class BITSET
{
public:
	BITSET()	:	numBits(0), numBytes(0), bits(NULL)
	{}

	~BITSET()
	{
		if(bits)
			delete [] bits;
		bits=NULL;
	}

	bool Init(int newNumBits);
	
	void ClearAll();		//Clear all bits

	void Set(int bitNumber);		//set a bit
	void Clear(int bitNumber);		//clear a bit

	bool IsSet(int bitNumber) const;//Is a bit set?
	bool AreAnySet() const;			//Are any bits set?

	//Logical ops
	void And(const BITSET & rhs, BITSET & result)	const;
	void Or(const BITSET & rhs, BITSET & result)	const;
	void Xor(const BITSET & rhs, BITSET & result)	const;

	int numBits;	//number of bits
protected:
	int numBytes;	//number of bytes in the array

	unsigned char * bits;
};

#endif	//BITSET_H