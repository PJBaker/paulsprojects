//////////////////////////////////////////////////////////////////////////////////////////
//	DrawLoadingScreen.h
//	Draw a simple screen to be displayed while loading
//	Downloaded from: www.paulsprojects.net
//	Created:	18th December 2002
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	

#ifndef DRAWLOADINGSCREEN_H
#define DRAWLOADINGSCREEN_H

void DrawLoadingScreen();

#endif	//DRAWLOADINGSCREEN_H