**************************************************************************
**	The Octagon Engine
**
**	www.paulsprojects.net
**
**	paul@paulsprojects.net
**************************************************************************

Description:

A game engine demonstrating per-pixel lighting, bump mapping, shadow volumes and particles. It displays Quake 3 bsp maps, Quake 2 md2 and Quake 3 md3 models.

Everything visible is rendered with its decal texture multiplied by a small constant plus its emissive texture, in order to provide the base for adding light. Then, for each light, stencil shadows are cast for each object which the light influences, and then a hardware-specific codepath lights the surface. After all lights have been considered, particles are added.

For a more in-depth look at how the Octagon Engine works, see "technical.txt". 


Requirements:

For standard codepath:
OpenGL 1.3 support
2 texture units
8 bit destination alpha buffer. If you want to run in windowed mode therefore, you must be using a 32 bit desktop.

For NV20 codepath:
4 texture units
ARB_vertex_program
EXT_blend_color
NV_register_combiners
NV_texture_shader

For R200 codepath:
6 texture units
ARB_vertex_program
ATI_fragment_shader

Optional:
SGIS_generate_mipmap
HP_occlusion_test
NV_vertex_array_range, NV_vertex_array_range2 and NV_fence
ATI_vertex_array_object


Benchmarks:

I have tested this program on my AMD Athlon XP 2000+ with four different graphics cards. The frame rates were:

nVidia GeForce 2 Integrated GPU (32 MB)  5.4 fps
ATi Radeon 9000 (64 MB)                 15.9 fps
nVidia Geforce 3 Ti200 (64 MB)          21.2 fps
nVidia Geforce FX 5900 XT (128 MB) 	37.4 fps


References:

Quake 3 BSP:
Quake 3 BSP Format, Ben Humphrey. From www.gametutorials.com
Unofficial Quake 3 map specs, Kekoa Proudfoot. From graphics.stanford.edu

MD3 Models:
http://linux.ucla.edu/~phaethon/q3/formats/md3format.html

MD2 Models:
OpenGL Game Programming, Hawkins and Astle.

Shadow Volumes:
Practical & Robust Stenciled Shadow Volumes for Hardware-Accelerated Rendering, by Cass Everitt and Mark J Kilgard. From developer.nvidia.com
Nehe tutorials lesson 28 - stencil shadow volumes. From nehe.gamedev.net

Lighting:
"Per-Pixel Lighting", Philip Taylor. From msdn.microsoft.com
"Real-Time Per-Pixel Point Lights and Spot Lights", Ron Frazier. From www.ronfrazier.net/apparition
"Texture Compositing with Register Combiners", John Spitzer. From developer.nvidia.com

Extension Specifications for the above extensions.


Keys:

F1		-	Take a screenshot
Escape		-	Quit

Up,W / Down,S 	-	Walk forward/backward
Left,A / Right,D-	Strafe left/right

Mouse		-	Look around/up/down

F2		-	Toggle Console
