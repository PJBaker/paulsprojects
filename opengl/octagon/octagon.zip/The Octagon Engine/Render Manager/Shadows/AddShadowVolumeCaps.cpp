//////////////////////////////////////////////////////////////////////////////////////////
//	AddShadowVolumeCaps.cpp
//	Add a list to the index list of caps, then reverse the order and add as projected verts
//	Downloaded from: www.paulsprojects.net
//	Created:	28th December 2002
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <vector>
#include "../../GL files/glee.h"			//header for OpenGL 1.4
#include "../../Maths/Maths.h"
#include "../../List/LIST.h"
#include "../RENDER_MANAGER.h"

void RENDER_MANAGER::AddShadowVolumeCaps(int count, unsigned int * indices)
{
	//Add the indices to the list
	capIndices.AddElements(count, indices);

	//Add the indices reversed, with an offset of the number of geometryVertices
	capIndices.AddElementsEx(count, indices, true, geometryData.numVertices);
}