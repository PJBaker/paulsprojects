//////////////////////////////////////////////////////////////////////////////////////////
//	DrawShadowVolumes.cpp
//	Draw the shadow volumes
//	Downloaded from: www.paulsprojects.net
//	Created:	28th December 2002
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <vector>
#include "../../GL files/glee.h"			//header for OpenGL 1.4
#include "../../Maths/Maths.h"
#include "../../List/LIST.h"
#include "../RENDER_MANAGER.h"

void RENDER_MANAGER::DrawShadowVolumes(bool drawZFail, bool drawZPass)
{
	if(drawZFail)
	{
		//Draw extruded edges
		if(zFailEdgeIndices.GetSize()>0)
			glDrawElements(	GL_QUADS, zFailEdgeIndices.GetSize(), GL_UNSIGNED_INT,
							zFailEdgeIndices.entries);

		//Draw caps
		if(capIndices.GetSize()>0)
			glDrawElements(	GL_TRIANGLES, capIndices.GetSize(), GL_UNSIGNED_INT,
							capIndices.entries);
	}

	if(drawZPass)
	{
		//Draw extruded edges
		if(zPassEdgeIndices.GetSize()>0)
			glDrawElements(	GL_QUADS, zPassEdgeIndices.GetSize(), GL_UNSIGNED_INT,
							zPassEdgeIndices.entries);

		//No caps
	}
}
