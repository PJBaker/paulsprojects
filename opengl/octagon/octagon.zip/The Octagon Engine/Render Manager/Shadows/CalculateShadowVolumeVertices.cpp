//////////////////////////////////////////////////////////////////////////////////////////
//	CalculateShadowVolumeVertices.cpp
//	Calculate the shadow volume vertices
//	Downloaded from: www.paulsprojects.net
//	Created:	28th December 2002
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <vector>
#include "../../GL files/glee.h"			//header for OpenGL 1.4
#include "../../Maths/Maths.h"
#include "../../List/LIST.h"
#include "../../Point Light/POINT_LIGHT.h"
#include "../RENDER_MANAGER.h"

void RENDER_MANAGER::CalculateShadowVolumeVertices(	const POINT_LIGHT & light,
													bool calculateNonProjected,
													bool calculateProjected)
{
	const VECTOR3D & lightPosition=light.boundingSphere.centre;

	if(calculateNonProjected)
	{
		//Calculate all nonprojected vertices since this is called only once per frame
		for(int i=0; i<geometryData.numVertices; ++i)
		{
			const VECTOR3D & vertexPosition=geometryData.vertices[i].position;

			VECTOR4D & nonProjectedShadowVertex=shadowVolumeVertices[i];

			nonProjectedShadowVertex.x=vertexPosition.x;
			nonProjectedShadowVertex.y=vertexPosition.y;
			nonProjectedShadowVertex.z=vertexPosition.z;
			nonProjectedShadowVertex.w=1.0f;
		}
	}

	//Only calculate the projected vertices which will be referenced
	if(calculateProjected)
	{
		//Calculate z pass vertices
		for(int i=0; i<zPassEdgeIndices.GetSize(); ++i)
		{
			int index=zPassEdgeIndices[i];
			
			//If this is not the index of a projected vertex, skip it
			if(index<geometryData.numVertices)
				continue;

			const VECTOR3D & vertexPosition=geometryData.
												vertices[index-geometryData.numVertices].position;

			VECTOR4D & projectedShadowVertex=shadowVolumeVertices[index];

			projectedShadowVertex.x=vertexPosition.x-lightPosition.x;
			projectedShadowVertex.y=vertexPosition.y-lightPosition.y;
			projectedShadowVertex.z=vertexPosition.z-lightPosition.z;
			projectedShadowVertex.w=0.0f;
		}

		//All zfail verts will be in capIndices
		for(int i=0; i<capIndices.GetSize(); ++i)
		{
			int index=capIndices[i];
			
			//If this is not the index of a projected vertex, skip it
			if(index<geometryData.numVertices)
				continue;

			const VECTOR3D & vertexPosition=geometryData.
												vertices[index-geometryData.numVertices].position;

			VECTOR4D & projectedShadowVertex=shadowVolumeVertices[index];

			projectedShadowVertex.x=vertexPosition.x-lightPosition.x;
			projectedShadowVertex.y=vertexPosition.y-lightPosition.y;
			projectedShadowVertex.z=vertexPosition.z-lightPosition.z;
			projectedShadowVertex.w=0.0f;
		}
	}
}

