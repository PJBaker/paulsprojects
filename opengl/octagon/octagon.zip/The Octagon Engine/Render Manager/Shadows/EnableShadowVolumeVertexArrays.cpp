//////////////////////////////////////////////////////////////////////////////////////////
//	EnableShadowVolumeVertexArrays.cpp
//	Enable shadow volume vertex arrays
//	Downloaded from: www.paulsprojects.net
//	Created:	28th December 2002
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <vector>
#include "../../GL files/glee.h"			//header for OpenGL 1.4
#include "../../Maths/Maths.h"
#include "../../List/LIST.h"
#include "../../Console/CONSOLE.h"
#include "../RENDER_MANAGER.h"

void RENDER_MANAGER::EnableShadowVolumeVertexArrays()
{
	//Disable the current arrays
	DisableShadowVolumeVertexArrays();

	//Enable new arrays

	//vertex array
	VECTOR4D * firstVertex;

	if(usingVAR && CONSOLE::Instance()->variables.useFastShadowVerts)
		firstVertex=(VECTOR4D *)(varVertices+varShadowDataOffset);
	else
		firstVertex=&shadowVolumeVertices[0];


	if(usingVAO && CONSOLE::Instance()->variables.useFastShadowVerts)
		glArrayObjectATI(	GL_VERTEX_ARRAY, 4, GL_FLOAT, sizeof(VECTOR4D),
							shadowVAO, 0);
	else
		glVertexPointer(4, GL_FLOAT, sizeof(VECTOR4D), firstVertex);

	glEnableClientState(GL_VERTEX_ARRAY);
	shadowVolumeVertexArrayEnabled=true;
}
