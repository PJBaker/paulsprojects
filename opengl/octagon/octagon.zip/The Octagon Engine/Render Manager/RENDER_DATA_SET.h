//////////////////////////////////////////////////////////////////////////////////////////
//	RENDER_DATA_SET.h
//	Header for a set of data to draw. Templated so it can hold different vertex/texture types
//	Downloaded from: www.paulsprojects.net
//	Created:	21st January 2003
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	

#ifndef RENDER_DATA_SET_H
#define RENDER_DATA_SET_H

template <class VERTEX_TYPE, class TEXTURE_TYPE>

class RENDER_DATA_SET
{
	friend class RENDER_MANAGER;	//Let RENDER_MANAGER access the protected data

protected:

//VERTICES
	//Temporary storage for vertices
	LIST <VERTEX_TYPE> tempVertices;

	//Final array of vertices, filled after LockNumVertices
	int numVertices;
	VERTEX_TYPE * vertices;

	//Add a vertex to the tempVertices
	int AddTempVertex(const VERTEX_TYPE & newVertex)
	{	
		tempVertices.AddElements(1, &newVertex);
		return tempVertices.GetSize()-1;
	}

	//Lock the number of vertices and fill the "vertices" array
	bool LockNumVertices()
	{
		numVertices=tempVertices.GetSize();
		vertices=new VERTEX_TYPE[numVertices];
		if(!vertices)
		{
			LOG::Instance()->OutputError("Unable to allocate space for vertices");
			return false;
		}

		for(int i=0; i<numVertices; ++i)
			vertices[i]=tempVertices[i];

		tempVertices.Clear();

		return true;
	}



//INDICES
	//One list per texture
	std::vector <LIST <GLuint> > indexLists;

	//Add elements to a list
	void AddElements(int textureNumber, int count, const GLuint * indices)
	{	indexLists[textureNumber].AddElements(count, indices);	}

	void AddElementsEx( int textureNumber, bool reverse, GLuint offset,
						int count, const GLuint * indices)
	{	indexLists[textureNumber].AddElementsEx(count, indices, reverse, offset);	}

	void ClearLists()
	{
		for(unsigned int i=0; i<indexLists.size(); ++i)
			indexLists[i].Clear();
	}




//TEXTURES
	std::vector <TEXTURE_TYPE> textures;



	RENDER_DATA_SET()	:	vertices(NULL)
	{}
	~RENDER_DATA_SET()
	{
		if(vertices)
			delete [] vertices;
		vertices=NULL;
	}
};

#endif	//RENDER_DATA_SET_H
