//////////////////////////////////////////////////////////////////////////////////////////
//	GEOMETRY_VERTEX.cpp
//	Geometry vertex methods
//	Downloaded from: www.paulsprojects.net
//	Created:	16th December 2002
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <vector>
#include "../../GL files/glee.h"			//header for OpenGL 1.4
#include "../../Maths/Maths.h"
#include "../../List/LIST.h"
#include "../RENDER_MANAGER.h"

//Apply a model space -> world space transform
void GEOMETRY_VERTEX::ModelTransform(const VECTOR3D & translation, float angleYaw)
{
	(*this)=GetModelTransformed(translation, angleYaw);
}

GEOMETRY_VERTEX GEOMETRY_VERTEX::GetModelTransformed(	const VECTOR3D & translation,
														float angleYaw) const
{
	//First deal with angleYaw==0
	if(angleYaw==0.0f)
		return GEOMETRY_VERTEX(	position+translation,
								sTangent,
								tTangent,
								normal,
								texCoords);

	static MATRIX4X4 rotationMatrix;
	static float lastAngleYaw=0.0;

	//Update the rotation matrix if necessary
	if(angleYaw!=lastAngleYaw)
	{
		rotationMatrix.SetRotationY(angleYaw);
		lastAngleYaw=angleYaw;
	}

	//return transformed vertex
	return GEOMETRY_VERTEX(	rotationMatrix.GetRotatedVector3D(position)+translation,
							rotationMatrix.GetRotatedVector3D(sTangent),
							rotationMatrix.GetRotatedVector3D(tTangent),
							rotationMatrix.GetRotatedVector3D(normal),
							texCoords);
}

GEOMETRY_VERTEX GEOMETRY_VERTEX::Lerp(const GEOMETRY_VERTEX & v2, float factor) const
{
	return GEOMETRY_VERTEX(	position.lerp(v2.position, factor),
							sTangent.lerp(v2.sTangent, factor),
							tTangent.lerp(v2.tTangent, factor),
							normal.lerp(v2.normal, factor),
							texCoords.lerp(v2.texCoords, factor));
}

GEOMETRY_VERTEX GEOMETRY_VERTEX::QuadraticInterpolate(	const GEOMETRY_VERTEX & v2,
														const GEOMETRY_VERTEX & v3,
														float factor) const
{
	return GEOMETRY_VERTEX(	position.QuadraticInterpolate(v2.position, v3.position, factor),
							sTangent.QuadraticInterpolate(v2.sTangent, v3.sTangent, factor),
							tTangent.QuadraticInterpolate(v2.tTangent, v3.tTangent, factor),
							normal.QuadraticInterpolate(v2.normal, v3.normal, factor),
							texCoords.QuadraticInterpolate(v2.texCoords, v3.texCoords, factor));
}
