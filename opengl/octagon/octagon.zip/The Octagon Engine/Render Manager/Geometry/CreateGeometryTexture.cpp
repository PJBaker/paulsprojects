//////////////////////////////////////////////////////////////////////////////////////////
//	CreateGeometryTexture.cpp
//	return the ID of a geometry texture, creating it if necessary. -1 if error
//	Downloaded from: www.paulsprojects.net
//	Created:	9th December 2002
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <vector>
#include "../../GL files/glee.h"			//header for OpenGL 1.4
#include "../../Maths/Maths.h"
#include "../../List/LIST.h"
#include "../RENDER_MANAGER.h"

int RENDER_MANAGER::CreateGeometryTexture(char * filename)
{
	//See if this texture has already been created
	//If so, return its ID
	for(std::size_t i=0; i<geometryData.textures.size(); ++i)
	{
		if(strcmp(filename, geometryData.textures[i].filename)==0)
			return i;
	}

	//If not, create temporary texture
	GEOMETRY_TEXTURE tempGeometryTexture;

	//Save the filename into the temporary texture
	strcpy(tempGeometryTexture.filename, filename);

	//Load our temporary texture
	if(!tempGeometryTexture.Load())
		return -1;

	//If loaded correctly, save the temp texture into the vector
	geometryData.textures.push_back(tempGeometryTexture);

	//Also create a new index list for this texture
	LIST <unsigned int> tempIndexList;
	geometryData.indexLists.push_back(tempIndexList);

	//return the ID
	return geometryData.textures.size()-1;
}