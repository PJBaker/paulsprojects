//////////////////////////////////////////////////////////////////////////////////////////
//	GEOMETRY_TEXTURE_Bind.cpp
//	Bind a geometry texture
//	Downloaded from: www.paulsprojects.net
//	Created:	9th December 2002
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <vector>
#include "../../GL files/glee.h"			//header for OpenGL 1.4
#include <GL/glu.h>
#include "../../Image/IMAGE.h"
#include "../../Maths/Maths.h"
#include "../../List/LIST.h"
#include "../RENDER_MANAGER.h"

void GEOMETRY_TEXTURE::Bind(GLenum decalTextureUnit,
							GLenum normalMapTextureUnit,
							GLenum emissiveTextureUnit)
{
	if(decalTextureUnit!=0)
	{
		glActiveTexture(decalTextureUnit);
		glBindTexture(GL_TEXTURE_2D, decalID);
	}

	if(normalMapTextureUnit!=0)
	{
		glActiveTexture(normalMapTextureUnit);
		glBindTexture(GL_TEXTURE_2D, normalID);
	}

	if(emissiveTextureUnit!=0)
	{
		glActiveTexture(emissiveTextureUnit);
		glBindTexture(GL_TEXTURE_2D, emissiveID);
	}

	//reset active texture
	glActiveTexture(GL_TEXTURE0);
}
