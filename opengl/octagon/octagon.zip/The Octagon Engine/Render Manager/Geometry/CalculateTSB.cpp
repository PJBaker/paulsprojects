//////////////////////////////////////////////////////////////////////////////////////////
//	CalculateTSB.cpp
//	Calculate the tangent space basis given 3 vertices
//	Downloaded from: www.paulsprojects.net
//	Created:	13th December 2002
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <vector>
#include "../../GL files/glee.h"			//header for OpenGL 1.4
#include "../../Maths/Maths.h"
#include "../../List/LIST.h"
#include "../RENDER_MANAGER.h"

void RENDER_MANAGER::CalculateTSB(	const GEOMETRY_VERTEX & v0,
									const GEOMETRY_VERTEX & v1,
									const GEOMETRY_VERTEX & v2,
									VECTOR3D & normal, VECTOR3D & sTangent, VECTOR3D & tTangent)
{
	//Calculate vectors along polygon sides
	VECTOR3D side0=v0.position-v1.position;
	VECTOR3D side1=v2.position-v1.position;

	//Calculate normal
	normal=side1.CrossProduct(side0);
	normal.Normalize();

	//Calculate s tangent
	float deltaT0=v0.texCoords.y-v1.texCoords.y;
	float deltaT1=v2.texCoords.y-v1.texCoords.y;
	VECTOR3D tempSTangent=deltaT1*side0-deltaT0*side1;
	tempSTangent.Normalize();

	//Calculate t tangent
	float deltaS0=v0.texCoords.x-v1.texCoords.x;
	float deltaS1=v2.texCoords.x-v1.texCoords.x;
	VECTOR3D tempTTangent=deltaS1*side0-deltaS0*side1;
	tempTTangent.Normalize();

	//reverse tangents if necessary
	VECTOR3D tangentCross=tempSTangent.CrossProduct(tempTTangent);
	if(tangentCross.DotProduct(normal)<0.0f)
	{
		tempSTangent=-tempSTangent;
		tempTTangent=-tempTTangent;
	}

	//Output results
	sTangent=tempSTangent;
	tTangent=tempTTangent;
}