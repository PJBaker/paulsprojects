//////////////////////////////////////////////////////////////////////////////////////////
//	StoreTangentSpaceLightVectors.cpp
//	Store the tangent space light vector in the "spare" of each vertex referenced in the indices
//	Downloaded from: www.paulsprojects.net
//	Created:	13th December 2002
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <vector>
#include "../../GL files/glee.h"			//header for OpenGL 1.4
#include "../../Maths/Maths.h"
#include "../../List/LIST.h"
#include "../RENDER_MANAGER.h"

//Store tangent space light vectors in the geometry vertices
//Only those which are referenced in the indices
void RENDER_MANAGER::StoreTangentSpaceLightVectors(const VECTOR3D & lightPosition)
{
	VECTOR3D lightVector;

	for(std::size_t i=0; i<geometryData.indexLists.size(); ++i)
	{
		for(int j=0; j<geometryData.indexLists[i].GetSize(); ++j)
		{
			int index=geometryData.indexLists[i].entries[j];

			//Calculate the light vector in world space
			lightVector=lightPosition-geometryData.vertices[index].position;

			//Convert to tangent space and save
			VECTOR3D & spareVector=spareVectors[index];
			spareVector.x=geometryData.vertices[index].sTangent.DotProduct(lightVector);
			
			spareVector.y=geometryData.vertices[index].tTangent.DotProduct(lightVector);

			spareVector.z=geometryData.vertices[index].normal.DotProduct(lightVector);
		}
	}
}
