//////////////////////////////////////////////////////////////////////////////////////////
//	EnableGeometryVertexArrays.cpp
//	Enable geometry vertex arrays
//	Downloaded from: www.paulsprojects.net
//	Created:	9th December 2002
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <vector>
#include "../../GL files/glee.h"			//header for OpenGL 1.4
#include "../../Maths/Maths.h"
#include "../../List/LIST.h"
#include "../../Console/CONSOLE.h"
#include "../RENDER_MANAGER.h"

void RENDER_MANAGER::EnableGeometryVertexArrays(bool useNormalArray,
												GLenum textureCoordUnit1,
												GLenum textureCoordUnit2,
												GLenum sTangentUnit,
												GLenum tTangentUnit,
												GLenum spareUnit)
{
	//Disable the current arrays
	DisableGeometryVertexArrays();

	//Calculate the base of the vertex array
	GEOMETRY_VERTEX * firstVertex;
	if(usingVAR && CONSOLE::Instance()->variables.useFastGeoVerts)
		firstVertex=(GEOMETRY_VERTEX *)varVertices+varVertexDataOffset;
	else
		firstVertex=&geometryData.vertices[0];

	VECTOR3D * firstSpareVector;
	if(usingVAR && CONSOLE::Instance()->variables.useFastGeoVerts)
		firstSpareVector=(VECTOR3D *)
								(varVertices+varSpareDataOffset);
	else
		firstSpareVector=&spareVectors[0];

	
	
	//Enable new arrays

	//vertex array
	if(usingVAO && CONSOLE::Instance()->variables.useFastGeoVerts)
		glArrayObjectATI(	GL_VERTEX_ARRAY, 3, GL_FLOAT, sizeof(GEOMETRY_VERTEX),
							vertexVAO, GLuint(&firstVertex->position)-GLuint(firstVertex));
	else
		glVertexPointer(3, GL_FLOAT, sizeof(GEOMETRY_VERTEX), &firstVertex->position);
	
	glEnableClientState(GL_VERTEX_ARRAY);
	geometryVertexArrayEnabled=true;


	//Normal array
	if(useNormalArray)
	{
		if(usingVAO && CONSOLE::Instance()->variables.useFastGeoVerts)
			glArrayObjectATI(	GL_NORMAL_ARRAY, 3, GL_FLOAT, sizeof(GEOMETRY_VERTEX),
								vertexVAO, GLuint(&firstVertex->normal)-GLuint(firstVertex));
		else
			glNormalPointer(GL_FLOAT, sizeof(GEOMETRY_VERTEX), &firstVertex->normal);

		glEnableClientState(GL_NORMAL_ARRAY);
	}

	//Update current array
	geometryNormalArrayEnabled=useNormalArray;

		
	//texture coord array 1
	if(textureCoordUnit1 != 0)
	{
		glClientActiveTexture(textureCoordUnit1);
		
		if(usingVAO && CONSOLE::Instance()->variables.useFastGeoVerts)
			glArrayObjectATI(	GL_TEXTURE_COORD_ARRAY, 2, GL_FLOAT, sizeof(GEOMETRY_VERTEX),
								vertexVAO, GLuint(&firstVertex->texCoords)-GLuint(firstVertex));
		else
			glTexCoordPointer(2, GL_FLOAT, sizeof(GEOMETRY_VERTEX), &firstVertex->texCoords);
		
		glEnableClientState(GL_TEXTURE_COORD_ARRAY);
	}

	//Update current array
	currentGeometryTextureCoordUnit1=textureCoordUnit1;


	//texture coord array 2
	if(textureCoordUnit2 != 0)
	{
		glClientActiveTexture(textureCoordUnit2);
		
		if(usingVAO && CONSOLE::Instance()->variables.useFastGeoVerts)
			glArrayObjectATI(	GL_TEXTURE_COORD_ARRAY, 2, GL_FLOAT, sizeof(GEOMETRY_VERTEX),
								vertexVAO, GLuint(&firstVertex->texCoords)-GLuint(firstVertex));
		else
			glTexCoordPointer(2, GL_FLOAT, sizeof(GEOMETRY_VERTEX), &firstVertex->texCoords);
		
		glEnableClientState(GL_TEXTURE_COORD_ARRAY);
	}

	//Update current array
	currentGeometryTextureCoordUnit2=textureCoordUnit2;


	//S Tangent array
	if(sTangentUnit!=0)
	{
		glClientActiveTexture(sTangentUnit);

		if(usingVAO && CONSOLE::Instance()->variables.useFastGeoVerts)
			glArrayObjectATI(	GL_TEXTURE_COORD_ARRAY, 3, GL_FLOAT, sizeof(GEOMETRY_VERTEX),
								vertexVAO, GLuint(&firstVertex->sTangent)-GLuint(firstVertex));
		else
			glTexCoordPointer(3, GL_FLOAT, sizeof(GEOMETRY_VERTEX), &firstVertex->sTangent);

		glEnableClientState(GL_TEXTURE_COORD_ARRAY);
	}

	//Update current array
	currentGeometrySTangentUnit=sTangentUnit;


	//T Tangent array
	if(tTangentUnit!=0)
	{
		glClientActiveTexture(tTangentUnit);

		if(usingVAO && CONSOLE::Instance()->variables.useFastGeoVerts)
			glArrayObjectATI(	GL_TEXTURE_COORD_ARRAY, 3, GL_FLOAT, sizeof(GEOMETRY_VERTEX),
								vertexVAO, GLuint(&firstVertex->tTangent)-GLuint(firstVertex));
		else
			glTexCoordPointer(3, GL_FLOAT, sizeof(GEOMETRY_VERTEX), &firstVertex->tTangent);
		
		glEnableClientState(GL_TEXTURE_COORD_ARRAY);
	}

	//Update current array
	currentGeometryTTangentUnit=tTangentUnit;


	//Spare array
	if(spareUnit!=0)
	{
		glClientActiveTexture(spareUnit);
		
		if(usingVAO && CONSOLE::Instance()->variables.useFastGeoVerts)
			glArrayObjectATI(	GL_TEXTURE_COORD_ARRAY, 3, GL_FLOAT, sizeof(VECTOR3D),
								spareVAO, 0);
		else
			glTexCoordPointer(3, GL_FLOAT, 0, firstSpareVector);

		glEnableClientState(GL_TEXTURE_COORD_ARRAY);
	}

	//Update current array
	currentGeometrySpareUnit=spareUnit;
	
	
	//restore client active texture
	glClientActiveTexture(GL_TEXTURE0);
}