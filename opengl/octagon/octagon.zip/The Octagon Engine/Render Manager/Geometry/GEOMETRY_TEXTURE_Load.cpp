//////////////////////////////////////////////////////////////////////////////////////////
//	GEOMETRY_TEXTURE_Load.cpp
//	Load a geometry texture
//	Downloaded from: www.paulsprojects.net
//	Created:	9th December 2002
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <vector>
#include "../../GL files/glee.h"			//header for OpenGL 1.4
#include <GL/glu.h>
#include "../../Image/IMAGE.h"
#include "../../Maths/Maths.h"
#include "../../Console/CONSOLE.h"
#include "../../List/LIST.h"
#include "../RENDER_MANAGER.h"

bool GEOMETRY_TEXTURE::Load()
{
	//Delete the textures if already loaded
	if(decalID!=0)
		glDeleteTextures(1, &decalID);
	if(normalID!=0)
		glDeleteTextures(1, &normalID);
	if(emissiveID!=0)
		glDeleteTextures(1, &emissiveID);

	//Calculate the filename of the decal, normal, gloss & emissive maps
	char decalName[128];
	strcpy(decalName, filename);
	strcat(decalName, ".tga");

	char normalName[128];
	strcpy(normalName, filename);
	strcat(normalName, "n.tga");

	char glossName[128];
	strcpy(glossName, filename);
	strcat(glossName, "g.tga");

	char emissiveName[128];
	strcpy(emissiveName, filename);
	strcat(emissiveName, "e.tga");

	//Temporary images for loading
	IMAGE decalImage, normalImage, glossImage, emissiveImage;

	//Load the images

	//decal image - required
	if(!decalImage.Load(decalName))
		return false;

	if(decalImage.paletted)
		decalImage.ExpandPalette();


	//Normal map
	if(!normalImage.Load(normalName))
	{
		//Create a normal map from the decal texture - todo

		//If all failed, load flat normal map
		normalImage.Load("data/textures/flat.tga");
	}

	if(normalImage.paletted)
		normalImage.ExpandPalette();


	//Gloss map. Set hasGloss=false if not found
	if(glossImage.Load(glossName))
	{
		hasGloss=true;

		//Invert the gloss map
		//If no gloss map is found, the alpha will be white. We want gloss to default to black,
		//so store 1-gloss.
		glossImage.Invert();

		//Put the gloss into the alpha of the normal map
		normalImage.LoadAlpha(glossImage);
	}
	else
	{
		hasGloss=false;

		//If there is no gloss map, clear the alpha channel of the normal map to white
		normalImage.ClearAlpha(1.0f);
	}


	//Emissive texture. Load black if not found
	if(!emissiveImage.Load(emissiveName))
		emissiveImage.Load("data/textures/black.tga");

	if(emissiveImage.paletted)
		emissiveImage.ExpandPalette();



	//Create textures

	//decal texture
	glGenTextures(1, &decalID);
	glBindTexture(GL_TEXTURE_2D, decalID);

	//Set parameters
	GLenum decalTextureFilter=	GL_NEAREST_MIPMAP_NEAREST+
								CONSOLE::Instance()->variables.decalTextureFilter-1;

	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, decalTextureFilter);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

	if(GLEE_EXT_texture_filter_anisotropic)
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAX_ANISOTROPY_EXT,
						CONSOLE::Instance()->variables.decalTextureMaxAnisotropy);


	//Send texture data. Use compressed textures if requested
	GLenum internalFormat;

	if(CONSOLE::Instance()->variables.useCompressedTextures)
		internalFormat=GL_COMPRESSED_RGBA;
	else
		internalFormat=GL_RGBA8;

	if(GLEE_SGIS_generate_mipmap)
	{
		glTexParameteri(GL_TEXTURE_2D, GL_GENERATE_MIPMAP_SGIS, true);
		glTexImage2D(	GL_TEXTURE_2D, 0, internalFormat, decalImage.width, decalImage.height, 0,
						decalImage.format, GL_UNSIGNED_BYTE, decalImage.data);
	}
	else
		gluBuild2DMipmaps(	GL_TEXTURE_2D, internalFormat, decalImage.width, decalImage.height,
							decalImage.format, GL_UNSIGNED_BYTE, decalImage.data);

		

	//normal map - do not compress
	glGenTextures(1, &normalID);
	glBindTexture(GL_TEXTURE_2D, normalID);

	//Set parameters
	GLenum normalTextureFilter=	GL_NEAREST_MIPMAP_NEAREST+
								CONSOLE::Instance()->variables.normalTextureFilter-1;

	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, normalTextureFilter);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	
	if(GLEE_EXT_texture_filter_anisotropic)
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAX_ANISOTROPY_EXT,
						CONSOLE::Instance()->variables.normalTextureMaxAnisotropy);

	if(GLEE_SGIS_generate_mipmap)
	{
		glTexParameteri(GL_TEXTURE_2D, GL_GENERATE_MIPMAP_SGIS, true);
		glTexImage2D(	GL_TEXTURE_2D, 0, GL_RGBA8, normalImage.width, normalImage.height, 0,
						normalImage.format, GL_UNSIGNED_BYTE, normalImage.data);
	}
	else
		gluBuild2DMipmaps(	GL_TEXTURE_2D, GL_RGBA8, normalImage.width, normalImage.height,
							normalImage.format, GL_UNSIGNED_BYTE, normalImage.data);

	

	
	
	//emissive texture
	glGenTextures(1, &emissiveID);
	glBindTexture(GL_TEXTURE_2D, emissiveID);

	//Set parameters
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, decalTextureFilter);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

	if(GLEE_EXT_texture_filter_anisotropic)
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAX_ANISOTROPY_EXT,
						CONSOLE::Instance()->variables.decalTextureMaxAnisotropy);
	
	//Send texture data. Use compressed textures if requested
	if(GLEE_SGIS_generate_mipmap)
	{
		glTexParameteri(GL_TEXTURE_2D, GL_GENERATE_MIPMAP_SGIS, true);
		glTexImage2D(	GL_TEXTURE_2D, 0, internalFormat, emissiveImage.width,
						emissiveImage.height, 0, emissiveImage.format, GL_UNSIGNED_BYTE,
						emissiveImage.data);
	}
	else
		gluBuild2DMipmaps(	GL_TEXTURE_2D, internalFormat, emissiveImage.width,
							emissiveImage.height, emissiveImage.format, GL_UNSIGNED_BYTE,
							emissiveImage.data);

	return true;
}