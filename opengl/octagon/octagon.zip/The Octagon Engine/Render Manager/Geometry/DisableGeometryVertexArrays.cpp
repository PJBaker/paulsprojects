//////////////////////////////////////////////////////////////////////////////////////////
//	DisableGeometryVertexArrays.cpp
//	Disable geometry vertex arrays
//	Downloaded from: www.paulsprojects.net
//	Created:	9th December 2002
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <vector>
#include "../../GL files/glee.h"			//header for OpenGL 1.4
#include "../../Maths/Maths.h"
#include "../../List/LIST.h"
#include "../RENDER_MANAGER.h"

void RENDER_MANAGER::DisableGeometryVertexArrays()
{
	//vertex array
	if(geometryVertexArrayEnabled)
	{
		glDisableClientState(GL_VERTEX_ARRAY);
		geometryVertexArrayEnabled=false;
	}

	//normal array
	if(geometryNormalArrayEnabled)
	{
		glDisableClientState(GL_NORMAL_ARRAY);
		geometryNormalArrayEnabled=false;
	}

	//texture coord arrays
	if(currentGeometryTextureCoordUnit1!=0)
	{
		glClientActiveTexture(currentGeometryTextureCoordUnit1);
		glDisableClientState(GL_TEXTURE_COORD_ARRAY);
		currentGeometryTextureCoordUnit1=0;
	}

	if(currentGeometryTextureCoordUnit2!=0)
	{
		glClientActiveTexture(currentGeometryTextureCoordUnit2);
		glDisableClientState(GL_TEXTURE_COORD_ARRAY);
		currentGeometryTextureCoordUnit2=0;
	}

	//s tangent array
	if(currentGeometrySTangentUnit!=0)
	{
		glClientActiveTexture(currentGeometrySTangentUnit);
		glDisableClientState(GL_TEXTURE_COORD_ARRAY);
		currentGeometrySTangentUnit=0;
	}

	//t tangent array
	if(currentGeometryTTangentUnit!=0)
	{
		glClientActiveTexture(currentGeometryTTangentUnit);
		glDisableClientState(GL_TEXTURE_COORD_ARRAY);
		currentGeometryTTangentUnit=0;
	}

	//spare array
	if(currentGeometrySpareUnit!=0)
	{
		glClientActiveTexture(currentGeometrySpareUnit);
		glDisableClientState(GL_TEXTURE_COORD_ARRAY);
		currentGeometrySpareUnit=0;
	}

	//restore client active texture
	glClientActiveTexture(GL_TEXTURE0);
}