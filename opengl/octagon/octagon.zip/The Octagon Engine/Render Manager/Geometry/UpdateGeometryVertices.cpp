//////////////////////////////////////////////////////////////////////////////////////////
//	UpdateGeometryVertices.cpp
//	Update the geometry vertex array
//	Downloaded from: www.paulsprojects.net
//	Created:	18th December 2002
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <vector>
#include "../../GL files/glee.h"			//header for OpenGL 1.4
#include "../../Maths/Maths.h"
#include "../../List/LIST.h"
#include "../RENDER_MANAGER.h"

void RENDER_MANAGER::UpdateGeometryVertices(int firstVertexIndex,
											int numVertices,
											const GEOMETRY_VERTEX * newVertices)
{
	if(firstVertexIndex+numVertices>geometryData.numVertices)
		return;

	memcpy(	&geometryData.vertices[firstVertexIndex],
			newVertices,
			numVertices*sizeof(GEOMETRY_VERTEX));
}
