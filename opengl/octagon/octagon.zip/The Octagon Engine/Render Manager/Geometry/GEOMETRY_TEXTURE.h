//////////////////////////////////////////////////////////////////////////////////////////
//	GEOMETRY_TEXTURE.h
//	Class for a geometry texture
//	Downloaded from: www.paulsprojects.net
//	Created:	8th December 2002
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	

#ifndef GEOMETRY_TEXTURE_H
#define GEOMETRY_TEXTURE_H

class GEOMETRY_TEXTURE
{
public:
	//Load this texture from a file
	bool Load();

	//Bind this texture
	void Bind(	GLenum decalTextureUnit,
				GLenum normalMapTextureUnit,
				GLenum emissiveTextureUnit);

	//filename of this texture
	char filename[128];

	//OpenGL IDs for decal, normal map and emissive images
	GLuint decalID;
	GLuint normalID;
	GLuint emissiveID;

	//Does this texture have a gloss map (in the alpha of the normal map?)
	bool hasGloss;

	GEOMETRY_TEXTURE()	:	decalID(0), normalID(0), emissiveID(0), hasGloss(false)
	{}
	~GEOMETRY_TEXTURE()
	{}
};

#endif	//GEOMETRY_TEXTURE_H