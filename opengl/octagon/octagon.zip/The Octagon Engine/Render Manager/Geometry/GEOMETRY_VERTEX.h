//////////////////////////////////////////////////////////////////////////////////////////
//	GEOMETRY_VERTEX.h
//	Class for a geometry vertex
//	Downloaded from: www.paulsprojects.net
//	Created:	9th December 2002
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	

#ifndef GEOMETRY_VERTEX_H
#define GEOMETRY_VERTEX_H

class GEOMETRY_VERTEX
{
public:
	//constructors
	GEOMETRY_VERTEX()
	{}
	GEOMETRY_VERTEX(VECTOR3D newPosition, VECTOR3D newSTangent, VECTOR3D newTTangent,
					VECTOR3D newNormal, VECTOR2D newTexCoords)
					: position(newPosition), sTangent(newSTangent), tTangent(newTTangent),
					  normal(newNormal), texCoords(newTexCoords)
	{}
	~GEOMETRY_VERTEX()
	{}

	VECTOR3D position;

	VECTOR3D sTangent, tTangent;
	VECTOR3D normal;

	VECTOR2D texCoords;

	//Apply a model space->world space transform
	void ModelTransform(const VECTOR3D & translation, float angleYaw);
	GEOMETRY_VERTEX GetModelTransformed(const VECTOR3D & translation, float angleYaw) const;

	void operator+=(const GEOMETRY_VERTEX & rhs)
	{	position+=rhs.position;	sTangent+=rhs.sTangent;		tTangent+=rhs.tTangent;
		normal+=rhs.normal;		texCoords+=rhs.texCoords;	}

	void operator-=(const GEOMETRY_VERTEX & rhs)
	{	position-=rhs.position;	sTangent-=rhs.sTangent;		tTangent-=rhs.tTangent;
		normal-=rhs.normal;		texCoords-=rhs.texCoords;	}

	void operator*=(const float rhs)
	{	position*=rhs;	sTangent*=rhs;		tTangent*=rhs;
		normal*=rhs;	texCoords*=rhs;	}

	void operator/=(const float rhs)
	{	position/=rhs;	sTangent/=rhs;		tTangent/=rhs;
		normal/=rhs;	texCoords/=rhs;	}

	GEOMETRY_VERTEX Lerp(const GEOMETRY_VERTEX & v2, float factor) const;

	GEOMETRY_VERTEX QuadraticInterpolate(	const GEOMETRY_VERTEX & v2,
											const GEOMETRY_VERTEX & v3,
											float factor) const;
};

#endif	//GEOMETRY_VERTEX_H