//////////////////////////////////////////////////////////////////////////////////////////
//	DrawGeometry.cpp
//	Draw the geometry!
//	Downloaded from: www.paulsprojects.net
//	Created:	9th December 2002
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <vector>
#include "../../GL files/glee.h"			//header for OpenGL 1.4
#include "../../Maths/Maths.h"
#include "../../List/LIST.h"
#include "../RENDER_MANAGER.h"

void RENDER_MANAGER::DrawGeometry(	bool drawNonGloss,
									GLenum decalTextureUnit,
									GLenum normalMapTextureUnit,
									GLenum emissiveTextureUnit)
{
	//Loop through textures, bind & draw
	for(std::size_t i=0; i<geometryData.textures.size(); ++i)
	{
		//Skip this if it has no gloss map and we are not drawing those
		if(!drawNonGloss && !geometryData.textures[i].hasGloss)
			continue;

		if(geometryData.indexLists[i].GetSize()>0)
		{
			geometryData.textures[i].Bind(	decalTextureUnit,
											normalMapTextureUnit,
											emissiveTextureUnit);

			glDrawElements(	GL_TRIANGLES,
							geometryData.indexLists[i].GetSize(),
							GL_UNSIGNED_INT,
							geometryData.indexLists[i].entries);
		}
	}
}

