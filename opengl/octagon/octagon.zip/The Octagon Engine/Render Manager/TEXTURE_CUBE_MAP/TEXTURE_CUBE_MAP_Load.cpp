//////////////////////////////////////////////////////////////////////////////////////////
//	TEXTURE_CUBE_MAP_Load.cpp
//	Load a cube map texture
//	Downloaded from: www.paulsprojects.net
//	Created:	16th December 2002
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <vector>
#include "../../GL files/glee.h"			//header for OpenGL 1.4
#include <GL/glu.h>
#include "../../Image/IMAGE.h"
#include "../../Maths/Maths.h"
#include "../../Console/CONSOLE.h"
#include "../../List/LIST.h"
#include "../RENDER_MANAGER.h"

bool TEXTURE_CUBE_MAP::Load()
{
	//Delete the texture if already loaded
	if(textureID!=0)
		glDeleteTextures(1, &textureID);

	//Calculate the filename for each face
	char pxName[128], nxName[128];
	char pyName[128], nyName[128];
	char pzName[128], nzName[128];

	strcpy(pxName, filename);
	strcat(pxName, "px.tga");

	strcpy(nxName, filename);
	strcat(nxName, "nx.tga");
	
	strcpy(pyName, filename);
	strcat(pyName, "py.tga");
	
	strcpy(nyName, filename);
	strcat(nyName, "ny.tga");
	
	strcpy(pzName, filename);
	strcat(pzName, "pz.tga");
	
	strcpy(nzName, filename);
	strcat(nzName, "nz.tga");

	//Calculate the filename with "all" on the end, used for all faces
	char allName[128];
	strcpy(allName, filename);
	strcat(allName, "all.tga");

	
	//Temporary image for loading
	IMAGE tempImage;

	//Create and bind the texture
	glGenTextures(1, &textureID);
	glBindTexture(GL_TEXTURE_CUBE_MAP, textureID);

	//Set parameters
	glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_WRAP_T, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
	glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_GENERATE_MIPMAP, true);

	GLenum internalFormat;
	if(CONSOLE::Instance()->variables.useCompressedTextures)
		internalFormat=GL_COMPRESSED_RGBA;
	else
		internalFormat=GL_RGBA8;

	//Try to load the "all" image, and send as all faces
	if(tempImage.Load(allName))
	{
		if(tempImage.paletted)
			tempImage.ExpandPalette();

		glTexImage2D(	GL_TEXTURE_CUBE_MAP_POSITIVE_X, 0, internalFormat, tempImage.width,
						tempImage.height, 0, tempImage.format, GL_UNSIGNED_BYTE, tempImage.data);
		glTexImage2D(	GL_TEXTURE_CUBE_MAP_NEGATIVE_X, 0, internalFormat, tempImage.width,
						tempImage.height, 0, tempImage.format, GL_UNSIGNED_BYTE, tempImage.data);
		glTexImage2D(	GL_TEXTURE_CUBE_MAP_POSITIVE_Y, 0, internalFormat, tempImage.width,
						tempImage.height, 0, tempImage.format, GL_UNSIGNED_BYTE, tempImage.data);
		glTexImage2D(	GL_TEXTURE_CUBE_MAP_NEGATIVE_Y, 0, internalFormat, tempImage.width,
						tempImage.height, 0, tempImage.format, GL_UNSIGNED_BYTE, tempImage.data);
		glTexImage2D(	GL_TEXTURE_CUBE_MAP_POSITIVE_Z, 0, internalFormat, tempImage.width,
						tempImage.height, 0, tempImage.format, GL_UNSIGNED_BYTE, tempImage.data);
		glTexImage2D(	GL_TEXTURE_CUBE_MAP_NEGATIVE_Z, 0, internalFormat, tempImage.width,
						tempImage.height, 0, tempImage.format, GL_UNSIGNED_BYTE, tempImage.data);
	}
	else	//if failed, load each face separately
	{
		if(!tempImage.Load(pxName))
			return false;
		if(tempImage.paletted)
			tempImage.ExpandPalette();
		glTexImage2D(	GL_TEXTURE_CUBE_MAP_POSITIVE_X, 0, internalFormat, tempImage.width,
						tempImage.height, 0, tempImage.format, GL_UNSIGNED_BYTE, tempImage.data);

		if(!tempImage.Load(nxName))
			return false;
		if(tempImage.paletted)
			tempImage.ExpandPalette();
		glTexImage2D(	GL_TEXTURE_CUBE_MAP_NEGATIVE_X, 0, internalFormat, tempImage.width,
						tempImage.height, 0, tempImage.format, GL_UNSIGNED_BYTE, tempImage.data);

		if(!tempImage.Load(pyName))
			return false;
		if(tempImage.paletted)
			tempImage.ExpandPalette();
		glTexImage2D(	GL_TEXTURE_CUBE_MAP_POSITIVE_Y, 0, internalFormat, tempImage.width,
						tempImage.height, 0, tempImage.format, GL_UNSIGNED_BYTE, tempImage.data);

		if(!tempImage.Load(nyName))
			return false;
		if(tempImage.paletted)
			tempImage.ExpandPalette();
		glTexImage2D(	GL_TEXTURE_CUBE_MAP_NEGATIVE_Y, 0, internalFormat, tempImage.width,
						tempImage.height, 0, tempImage.format, GL_UNSIGNED_BYTE, tempImage.data);

		if(!tempImage.Load(pzName))
			return false;
		if(tempImage.paletted)
			tempImage.ExpandPalette();
		glTexImage2D(	GL_TEXTURE_CUBE_MAP_POSITIVE_Z, 0, internalFormat, tempImage.width,
						tempImage.height, 0, tempImage.format, GL_UNSIGNED_BYTE, tempImage.data);

		if(!tempImage.Load(nzName))
			return false;
		if(tempImage.paletted)
			tempImage.ExpandPalette();
		glTexImage2D(	GL_TEXTURE_CUBE_MAP_NEGATIVE_Z, 0, internalFormat, tempImage.width,
						tempImage.height, 0, tempImage.format, GL_UNSIGNED_BYTE, tempImage.data);
	}
	
	return true;
}