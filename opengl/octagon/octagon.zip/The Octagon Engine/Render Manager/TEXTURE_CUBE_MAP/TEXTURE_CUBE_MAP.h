//////////////////////////////////////////////////////////////////////////////////////////
//	TEXTURE_CUBE_MAP.h
//	Class for a cube map texture
//	Downloaded from: www.paulsprojects.net
//	Created:	22nd December 2002
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	

#ifndef TEXTURE_CUBE_MAP_H
#define TEXTURE_CUBE_MAP_H

class TEXTURE_CUBE_MAP
{
public:
	//Load this texture from a file
	bool Load();

	//Bind this texture
	void Bind()
	{	glBindTexture(GL_TEXTURE_CUBE_MAP, textureID);	}

	//filename of this texture
	char filename[64];

	//OpenGL ID
	GLuint textureID;
	
	TEXTURE_CUBE_MAP()	:	textureID(0)
	{}
	~TEXTURE_CUBE_MAP()
	{}
};

#endif	//TEXTURE_CUBE_MAP_H