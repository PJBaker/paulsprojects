//////////////////////////////////////////////////////////////////////////////////////////
//	TEXTURE_2D_Load.cpp
//	Load a 2d texture
//	Downloaded from: www.paulsprojects.net
//	Created:	23rd December 2002
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <vector>
#include "../../GL files/glee.h"			//header for OpenGL 1.4
#include <GL/glu.h>
#include "../../Image/IMAGE.h"
#include "../../Maths/Maths.h"
#include "../../Console/CONSOLE.h"
#include "../../List/LIST.h"
#include "../RENDER_MANAGER.h"

bool TEXTURE_2D::Load()
{
	//Delete the texture if already loaded
	if(textureID!=0)
		glDeleteTextures(1, &textureID);

	//Calculate the filename with suffix
	char name[128];

	strcpy(name, filename);
	strcat(name, ".tga");
	
	//Temporary image for loading
	IMAGE tempImage;
	tempImage.Load(name);

	if(tempImage.paletted)
		tempImage.ExpandPalette();

	//Create and bind the texture
	glGenTextures(1, &textureID);
	glBindTexture(GL_TEXTURE_2D, textureID);

	//Set parameters
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

	GLenum internalFormat;
	if(CONSOLE::Instance()->variables.useCompressedTextures)
		internalFormat=GL_COMPRESSED_RGBA;
	else
		internalFormat=GL_RGBA8;
	
	if(GLEE_SGIS_generate_mipmap)
	{
		glTexParameteri(GL_TEXTURE_2D, GL_GENERATE_MIPMAP_SGIS, true);
		glTexImage2D(	GL_TEXTURE_2D, 0, internalFormat, tempImage.width, tempImage.height, 0,
						tempImage.format, GL_UNSIGNED_BYTE, tempImage.data);
	}
	else
		gluBuild2DMipmaps(	GL_TEXTURE_2D, internalFormat, tempImage.width, tempImage.height,
							tempImage.format, GL_UNSIGNED_BYTE, tempImage.data);
	

	return true;
}