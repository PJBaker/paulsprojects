//////////////////////////////////////////////////////////////////////////////////////////
//	TEXTURE_2D.h
//	Class for a 2d texture
//	Downloaded from: www.paulsprojects.net
//	Created:	22nd December 2002
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	

#ifndef TEXTURE_2D_H
#define TEXTURE_2D_H

class TEXTURE_2D
{
public:
	//Load this texture from a file
	bool Load();

	//Bind this texture
	void Bind()
	{	glBindTexture(GL_TEXTURE_2D, textureID);	}

	//filename of this texture
	char filename[64];

	//OpenGL ID
	GLuint textureID;
	
	TEXTURE_2D()	:	textureID(0)
	{}
	~TEXTURE_2D()
	{}
};

#endif	//TEXTURE_2D_H