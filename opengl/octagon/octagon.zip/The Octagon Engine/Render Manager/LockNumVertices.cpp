//////////////////////////////////////////////////////////////////////////////////////////
//	LockNumVertices.cpp
//	Lock the number of vertices
//	Downloaded from: www.paulsprojects.net
//	Created:	22nd January 2003
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <vector>
#include "../GL files/glee.h"			//header for OpenGL 1.4
#include "../Maths/Maths.h"
#include "../List/LIST.h"
#include "../Console/CONSOLE.h"
#include "RENDER_MANAGER.h"

bool RENDER_MANAGER::LockNumVertices()
{
	//Lock geometry vertices
	if(!geometryData.LockNumVertices())
		return false;

	//Create space for spare vectors
	spareVectors=new VECTOR3D[geometryData.numVertices];
	if(!spareVectors)
	{
		LOG::Instance()->OutputError("Unable to allocate space for spare vectors");
		return false;
	}

	//Create space for shadow volume vertices
	//need space for all vertices, non-projected and projected
	shadowVolumeVertices=new VECTOR4D[geometryData.numVertices*2];
	if(!shadowVolumeVertices)
	{
		LOG::Instance()->OutputError("Unable to allocate space for shadow volume vertices");
		return false;
	}

	//Create space for particle vertices & particles
	particleData.numVertices=4*numParticles;
	particleData.vertices=new PARTICLE_VERTEX[4*numParticles];
	particles=new PARTICLE[numParticles];
	if(!particleData.vertices || !particles)
	{
		LOG::Instance()->OutputError("Unable to allocate space for %d particles", numParticles);
		return false;
	}

	//Try to use VAR if supported
	usingVAR=	GLEE_NV_vertex_array_range &&
				GLEE_NV_vertex_array_range2 &&
				GLEE_NV_fence;
	
	if(usingVAR)
	{
		//Start optimistic
		usingVAR=true;

		//Get the maximum index VAR can deal with
		int maxVARIndex;
		glGetIntegerv(GL_MAX_VERTEX_ARRAY_RANGE_ELEMENT_NV, &maxVARIndex);

		//Calculate the maximum index we require
		int maxRequiredIndex=geometryData.numVertices*2;

		//Don't use VAR if the maximum required index is larger than the maximum possible index
		if(maxRequiredIndex>maxVARIndex)
			usingVAR=false;
	}

	//Set up VAR
	if(usingVAR)
	{
		//Calculate sizes and offsets from the start of the buffer
		varVertexDataSize=geometryData.numVertices*sizeof(GEOMETRY_VERTEX);
		varVertexDataOffset=0;

		varSpareDataSize=geometryData.numVertices*sizeof(VECTOR3D);
		varSpareDataOffset=varVertexDataSize;
		varSpareDataOffset=(varSpareDataOffset&(~0xFF))+0x100;	//round up to multiple of 256

		varShadowDataSize=2*geometryData.numVertices*sizeof(VECTOR4D);
		varShadowDataOffset=varSpareDataOffset+varSpareDataSize;
		varShadowDataOffset=(varShadowDataOffset&(~0xFF))+0x100;//round up to multiple of 256

		//Calculate size of VAR buffer
		varSize=varShadowDataOffset+varShadowDataSize;

		//Allocate this much AGP memory. Stop using VAR if failed
		varVertices=(unsigned char *)wglAllocateMemoryNV(varSize, 0.2f, 0.2f, 0.5f);
		if(!varVertices)
		{
			LOG::Instance()->OutputError("Unable to allocate AGP memory for VAR");
			usingVAR=false;
		}

		LOG::Instance()->OutputMisc("%dKB VAR buffer allocated", varSize/1024);
	}

	if(usingVAR)
	{
		glVertexArrayRangeNV(varSize, varVertices);

		//Generate fence
		glGenFencesNV(1, &fence);
		bool fenceSet=false;

		//Tell the user we are using VAR
		LOG::Instance()->OutputSuccess("VAR available");
	}
	else
		LOG::Instance()->OutputMisc("VAR not available");


	//If not using VAR, try to use VAO if supported
	usingVAO=	!usingVAR &&
				GLEE_ATI_vertex_array_object;
	
	if(usingVAO)
	{
		//Calculate sizes of each VAO
		vertexVAOSize=geometryData.numVertices*sizeof(GEOMETRY_VERTEX);
		spareVAOSize=geometryData.numVertices*sizeof(VECTOR3D);
		shadowVAOSize=2*geometryData.numVertices*sizeof(VECTOR4D);
		
		//Create the VAO buffers
		vertexVAO=glNewObjectBufferATI(vertexVAOSize, NULL, GL_DYNAMIC_ATI);
		spareVAO=glNewObjectBufferATI(spareVAOSize, NULL, GL_DYNAMIC_ATI);
		shadowVAO=glNewObjectBufferATI(shadowVAOSize, NULL, GL_DYNAMIC_ATI);

		if(vertexVAO==0 || spareVAO==0)
			usingVAO=false;
	}

	if(usingVAO)
	{
		LOG::Instance()->OutputSuccess("VAO available");
	}
	else
		LOG::Instance()->OutputMisc("VAO not available");

	//Fill the VAR/VAOs with the initial data
	BeginDataUpdate();
	EndDataUpdate(true, true, true);

	return true;
}
