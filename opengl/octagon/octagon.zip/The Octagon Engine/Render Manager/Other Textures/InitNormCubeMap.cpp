//////////////////////////////////////////////////////////////////////////////////////////
//	InitNormCubeMap.cpp
//	Initiate the normalisation cube map texture
//	Downloaded from: www.paulsprojects.net
//	Created:	13th December 2002
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <vector>
#include "../../GL files/glee.h"			//header for OpenGL 1.4
#include <GL/glu.h>
#include "../../Image/IMAGE.h"
#include "../../Maths/Maths.h"
#include "../../Log/LOG.h"
#include "../../List/LIST.h"
#include "../RENDER_MANAGER.h"

bool RENDER_MANAGER::InitNormCubeMap()
{
	int size=64;

	//Generate & bind the normalisation cube map ID
	glGenTextures(1, &normCubeMap);
	glBindTexture(GL_TEXTURE_CUBE_MAP, normCubeMap);

	//Create space to hold data for one face
	unsigned char * data=new unsigned char[size*size*3];
	if(!data)
	{
		LOG::Instance()->OutputError("Unable to allocate memory for texture data for cube map\n");
		return false;
	}

	//some useful variables
	float offset=0.5f;
	float halfSize=(float)size/2;
	VECTOR3D tempVector;
	unsigned char * bytePtr;

	//positive x
	bytePtr=data;

	for(int j=0; j<size; j++)
	{
		for(int i=0; i<size; i++)
		{
			tempVector.SetX(halfSize);
			tempVector.SetY(-(j+offset-halfSize));
			tempVector.SetZ(-(i+offset-halfSize));

			tempVector.Normalize();
			tempVector.PackTo01();

			bytePtr[0]=(unsigned char)(tempVector.GetX()*255);
			bytePtr[1]=(unsigned char)(tempVector.GetY()*255);
			bytePtr[2]=(unsigned char)(tempVector.GetZ()*255);

			bytePtr+=3;
		}
	}
	glTexImage2D(	GL_TEXTURE_CUBE_MAP_POSITIVE_X,
					0, GL_RGBA8, size, size, 0, GL_RGB, GL_UNSIGNED_BYTE, data);

	//negative x
	bytePtr=data;

	for(int j=0; j<size; j++)
	{
		for(int i=0; i<size; i++)
		{
			tempVector.SetX(-halfSize);
			tempVector.SetY(-(j+offset-halfSize));
			tempVector.SetZ((i+offset-halfSize));

			tempVector.Normalize();
			tempVector.PackTo01();

			bytePtr[0]=(unsigned char)(tempVector.GetX()*255);
			bytePtr[1]=(unsigned char)(tempVector.GetY()*255);
			bytePtr[2]=(unsigned char)(tempVector.GetZ()*255);

			bytePtr+=3;
		}
	}
	glTexImage2D(	GL_TEXTURE_CUBE_MAP_NEGATIVE_X,
					0, GL_RGBA8, size, size, 0, GL_RGB, GL_UNSIGNED_BYTE, data);

	//positive y
	bytePtr=data;

	for(int j=0; j<size; j++)
	{
		for(int i=0; i<size; i++)
		{
			tempVector.SetX(i+offset-halfSize);
			tempVector.SetY(halfSize);
			tempVector.SetZ((j+offset-halfSize));

			tempVector.Normalize();
			tempVector.PackTo01();

			bytePtr[0]=(unsigned char)(tempVector.GetX()*255);
			bytePtr[1]=(unsigned char)(tempVector.GetY()*255);
			bytePtr[2]=(unsigned char)(tempVector.GetZ()*255);

			bytePtr+=3;
		}
	}
	glTexImage2D(	GL_TEXTURE_CUBE_MAP_POSITIVE_Y,
					0, GL_RGBA8, size, size, 0, GL_RGB, GL_UNSIGNED_BYTE, data);

	//negative y
	bytePtr=data;

	for(int j=0; j<size; j++)
	{
		for(int i=0; i<size; i++)
		{
			tempVector.SetX(i+offset-halfSize);
			tempVector.SetY(-halfSize);
			tempVector.SetZ(-(j+offset-halfSize));

			tempVector.Normalize();
			tempVector.PackTo01();

			bytePtr[0]=(unsigned char)(tempVector.GetX()*255);
			bytePtr[1]=(unsigned char)(tempVector.GetY()*255);
			bytePtr[2]=(unsigned char)(tempVector.GetZ()*255);

			bytePtr+=3;
		}
	}
	glTexImage2D(	GL_TEXTURE_CUBE_MAP_NEGATIVE_Y,
					0, GL_RGBA8, size, size, 0, GL_RGB, GL_UNSIGNED_BYTE, data);

	//positive z
	bytePtr=data;

	for(int j=0; j<size; j++)
	{
		for(int i=0; i<size; i++)
		{
			tempVector.SetX(i+offset-halfSize);
			tempVector.SetY(-(j+offset-halfSize));
			tempVector.SetZ(halfSize);

			tempVector.Normalize();
			tempVector.PackTo01();

			bytePtr[0]=(unsigned char)(tempVector.GetX()*255);
			bytePtr[1]=(unsigned char)(tempVector.GetY()*255);
			bytePtr[2]=(unsigned char)(tempVector.GetZ()*255);

			bytePtr+=3;
		}
	}
	glTexImage2D(	GL_TEXTURE_CUBE_MAP_POSITIVE_Z,
					0, GL_RGBA8, size, size, 0, GL_RGB, GL_UNSIGNED_BYTE, data);

	//negative z
	bytePtr=data;

	for(int j=0; j<size; j++)
	{
		for(int i=0; i<size; i++)
		{
			tempVector.SetX(-(i+offset-halfSize));
			tempVector.SetY(-(j+offset-halfSize));
			tempVector.SetZ(-halfSize);

			tempVector.Normalize();
			tempVector.PackTo01();

			bytePtr[0]=(unsigned char)(tempVector.GetX()*255);
			bytePtr[1]=(unsigned char)(tempVector.GetY()*255);
			bytePtr[2]=(unsigned char)(tempVector.GetZ()*255);

			bytePtr+=3;
		}
	}
	glTexImage2D(	GL_TEXTURE_CUBE_MAP_NEGATIVE_Z,
					0, GL_RGBA8, size, size, 0, GL_RGB, GL_UNSIGNED_BYTE, data);

	if(data)
		delete [] data;
	data=NULL;

	//Set parameters
	glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
	glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);

	return true;
}
