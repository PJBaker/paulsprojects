//////////////////////////////////////////////////////////////////////////////////////////
//	InitAttenuationTextures.cpp
//	Initiate the attenuation textures
//	Downloaded from: www.paulsprojects.net
//	Created:	13th December 2002
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <vector>
#include "../../GL files/glee.h"			//header for OpenGL 1.4
#include <GL/glu.h>
#include "../../Image/IMAGE.h"
#include "../../Maths/Maths.h"
#include "../../Log/LOG.h"
#include "../../List/LIST.h"
#include "../RENDER_MANAGER.h"

bool RENDER_MANAGER::InitAttenuationTextures()
{
	//Create a strip of data for our 1d texture
	const int attenSize=128;
	GLubyte * attenData=new GLubyte[attenSize];
	if(!attenData)
	{
		LOG::Instance()->OutputError("Unable to create space to hold attenuation texture data");
		return false;
	}

	for(int i=0; i<attenSize; ++i)
	{
		//Get distance from centre to this point
		float dist=(float)i;
		dist-=(float)attenSize/2-0.5f;
		dist/=(float)attenSize/2-0.5f;

		//square and Clamp to [0,1]
		dist=dist*dist;

		if(dist>1.0f)
			dist=1.0f;

		if(dist<0.0f)
			dist=0.0f;

		//Fill this in as color
		attenData[i]=GLubyte(dist*255);

		//Make sure the color is 255 at the edges
		attenData[0]=255;
		attenData[attenSize-1]=255;
	}

	//Make 1d attenuation texture
	glGenTextures(1, &atten1DTexture);
	glBindTexture(GL_TEXTURE_1D, atten1DTexture);
	glTexImage1D(	GL_TEXTURE_1D, 0, GL_INTENSITY8, attenSize,
					0, GL_LUMINANCE, GL_UNSIGNED_BYTE, attenData);
	glTexParameteri(GL_TEXTURE_1D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_1D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_1D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);


	
	//Create data for our 2d texture by adding the 1d strips
	//since the attenuation function is separable by addition
	//do 1- the result. Then attenuation=2d-1d.
	GLubyte * attenData2D=new GLubyte[attenSize*attenSize];
	if(!attenData2D)
	{
		LOG::Instance()->OutputError("Unable to create space to hold attenuation texture data");
		return false;
	}
	
	int currentByte=0;
	GLubyte dataI, dataJ;

	for(int i=0; i<attenSize; ++i)
	{
		dataI=attenData[i];
	
		for(int j=0; j<attenSize; ++j)
		{
			GLuint newData;

			dataJ=attenData[j];

			newData=dataI+dataJ;
			if(newData>255)
				newData=255;
			
			attenData2D[currentByte]=255-newData;
			++currentByte;
		}
	}		

	//2d attenuation
	glGenTextures(1, &atten2DTexture);
	glBindTexture(GL_TEXTURE_2D, atten2DTexture);
	glTexImage2D(	GL_TEXTURE_2D, 0, GL_INTENSITY8, attenSize, attenSize,
					0, GL_LUMINANCE, GL_UNSIGNED_BYTE, attenData2D);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);

	//delete temporary data
	if(attenData)
		delete [] attenData;
	attenData=NULL;

	if(attenData2D)
		delete [] attenData2D;
	attenData2D=NULL;

	return true;
}