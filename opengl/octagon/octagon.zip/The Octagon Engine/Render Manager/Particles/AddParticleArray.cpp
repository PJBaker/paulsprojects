//////////////////////////////////////////////////////////////////////////////////////////
//	AddParticleArray.cpp
//	Add an array of indices to be drawn
//	Downloaded from: www.paulsprojects.net
//	Created:	23rd December 2002
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <vector>
#include "../../GL files/glee.h"			//header for OpenGL 1.4
#include "../../Maths/Maths.h"
#include "../../List/LIST.h"
#include "../RENDER_MANAGER.h"

void RENDER_MANAGER::AddParticleArray(int textureIndex, int first, int count)
{
	//Multiply by 4 to convert a list of particles to a list of particle vertices
	particleData.indexLists[textureIndex].AddArray(first*4, count*4);
}