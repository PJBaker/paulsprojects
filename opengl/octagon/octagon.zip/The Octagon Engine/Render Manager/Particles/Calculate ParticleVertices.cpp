//////////////////////////////////////////////////////////////////////////////////////////
//	CalculateParticleVertices.cpp
//	Calculate the position & texture coords of particle vertices based on the individual particles
//	Downloaded from: www.paulsprojects.net
//	Created:	23rd December 2002
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <vector>
#include "../../GL files/glee.h"			//header for OpenGL 1.4
#include "../../Maths/Maths.h"
#include "../../List/LIST.h"
#include "../RENDER_MANAGER.h"

void RENDER_MANAGER::CalculateParticleVertices()
{
	static float sizeScale=0.02f;
	
	PARTICLE_VERTEX * currentVertex=&particleData.vertices[0];

	//Loop through particles
	for(int i=0; i<numParticles; ++i)
	{
		float size=particles[i].size*sizeScale;
		VECTOR3D scaledBillboardRight=size*billboardRight;
		VECTOR3D scaledBillboardUp=size*billboardUp;

		VECTOR3D & particlePosition=particles[i].position;
		COLOR & color=particles[i].color;

		currentVertex->position=particlePosition
											-scaledBillboardRight
											-scaledBillboardUp;
		currentVertex->texCoords.Set(0.0f, 0.0f);
		currentVertex++->color=color;

		currentVertex->position=particlePosition
											+scaledBillboardRight
											-scaledBillboardUp;
		currentVertex->texCoords.Set(1.0f, 0.0f);
		currentVertex++->color=color;

		currentVertex->position=particlePosition
											+scaledBillboardRight
											+scaledBillboardUp;
		currentVertex->texCoords.Set(1.0f, 1.0f);
		currentVertex++->color=color;

		currentVertex->position=particlePosition
											-scaledBillboardRight
											+scaledBillboardUp;
		currentVertex->texCoords.Set(0.0f, 1.0f);
		currentVertex++->color=color;
	}
}

