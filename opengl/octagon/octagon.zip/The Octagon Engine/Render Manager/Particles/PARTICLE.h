//////////////////////////////////////////////////////////////////////////////////////////
//	PARTICLE.h
//	Class for a particle as stored in the render manager
//	Downloaded from: www.paulsprojects.net
//	Created:	24th December 2002
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	

#ifndef PARTICLE_H
#define PARTICLE_H

class PARTICLE
{
public:
	VECTOR3D position;

	COLOR color;

	float size;

	bool selfLit;
};

#endif	//PARTICLE_H