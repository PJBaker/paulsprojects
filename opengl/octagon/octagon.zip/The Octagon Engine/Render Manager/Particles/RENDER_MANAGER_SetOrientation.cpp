//////////////////////////////////////////////////////////////////////////////////////////
//	RENDER_MANAGER_SetOrientation.cpp.cpp
//	Set the vectors for billboarding
//	Downloaded from: www.paulsprojects.net
//	Created:	9th December 2002
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <vector>
#include "../../GL files/glee.h"			//header for OpenGL 1.4
#include "../../Maths/Maths.h"
#include "../../List/LIST.h"
#include "../RENDER_MANAGER.h"

void RENDER_MANAGER::SetOrientation(const MATRIX4X4 & viewMatrix)
{
	billboardRight.Set(viewMatrix.entries[0], viewMatrix.entries[4], viewMatrix.entries[8]);
	billboardUp.Set(viewMatrix.entries[1], viewMatrix.entries[5], viewMatrix.entries[9]);
}