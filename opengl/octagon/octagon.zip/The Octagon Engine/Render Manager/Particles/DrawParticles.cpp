//////////////////////////////////////////////////////////////////////////////////////////
//	DrawParticles.cpp
//	Draw the particles
//	Downloaded from: www.paulsprojects.net
//	Created:	23rd Deecember 2002
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <vector>
#include "../../GL files/glee.h"			//header for OpenGL 1.4
#include "../../Maths/Maths.h"
#include "../../List/LIST.h"
#include "../RENDER_MANAGER.h"

void RENDER_MANAGER::DrawParticles(GLenum decalTextureUnit)
{
	//Loop through particle textures, bind & draw
	for(std::size_t i=0; i<particleData.textures.size(); ++i)
	{
		particleData.textures[i].Bind();

		if(particleData.indexLists[i].GetSize()>0)
		{
			glDrawElements(	GL_QUADS,
							particleData.indexLists[i].GetSize(),
							GL_UNSIGNED_INT,
							particleData.indexLists[i].entries);
		}
	}
}

