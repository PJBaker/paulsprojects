//////////////////////////////////////////////////////////////////////////////////////////
//	DisableParticleVertexArrays.cpp
//	Disable particle vertex arrays
//	Downloaded from: www.paulsprojects.net
//	Created:	23rd December 2002
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <vector>
#include "../../GL files/glee.h"			//header for OpenGL 1.4
#include "../../Maths/Maths.h"
#include "../../List/LIST.h"
#include "../RENDER_MANAGER.h"

void RENDER_MANAGER::DisableParticleVertexArrays()
{
	//vertex array
	if(particleVertexArrayEnabled)
	{
		glDisableClientState(GL_VERTEX_ARRAY);
		particleVertexArrayEnabled=false;
	}

	//color array
	if(particleColorArrayEnabled)
	{
		glDisableClientState(GL_COLOR_ARRAY);
		particleColorArrayEnabled=false;
	}

	//texture coord array
	if(currentParticleTextureCoordUnit!=0)
	{
		glClientActiveTexture(currentParticleTextureCoordUnit);
		glDisableClientState(GL_TEXTURE_COORD_ARRAY);
		currentParticleTextureCoordUnit=0;
	}

	//restore client active texture
	glClientActiveTexture(GL_TEXTURE0);
}