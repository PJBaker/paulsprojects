//////////////////////////////////////////////////////////////////////////////////////////
//	PARTICLE_VERTEX.h
//	Class for a particle vertex
//	Downloaded from: www.paulsprojects.net
//	Created:	19th December 2002
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	

#ifndef PARTICLE_VERTEX_H
#define PARTICLE_VERTEX_H

class PARTICLE_VERTEX
{
public:
	//constructors
	PARTICLE_VERTEX()
	{}
	PARTICLE_VERTEX(VECTOR3D newPosition, VECTOR2D newTexCoords)
					: position(newPosition), texCoords(newTexCoords)
	{}
	~PARTICLE_VERTEX()
	{}

	
	VECTOR3D position;

	VECTOR2D texCoords;

	COLOR color;

	COLOR attenuatedColor;	//color with attenuation factor pre-multiplied with opacity in alpha
};

#endif	//PARTICLE_VERTEX_H