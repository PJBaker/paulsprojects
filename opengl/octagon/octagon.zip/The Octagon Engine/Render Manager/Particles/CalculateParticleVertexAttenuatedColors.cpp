//////////////////////////////////////////////////////////////////////////////////////////
//	CalculateParticleVertexAttenuatedColors.cpp
//	Calculate the position & texture coords of particle vertices based on the individual particles
//	Downloaded from: www.paulsprojects.net
//	Created:	23rd December 2002
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <vector>
#include "../../GL files/glee.h"			//header for OpenGL 1.4
#include "../../Maths/Maths.h"
#include "../../List/LIST.h"
#include "../RENDER_MANAGER.h"

void RENDER_MANAGER::CalculateParticleVertexAttenuatedColors(const POINT_LIGHT & currentLight)
{
	for(int i=0; i<numParticles; ++i)
	{
		//If this particle is self lit, continue
		if(particles[i].selfLit)
			continue;

		//If this particle lies outside the bounding sphere of the light, color is black
		if(!currentLight.boundingSphere.IsPointInside(particles[i].position))
		{
			for(int j=0; j<4; ++j)
			{
				int currentVertex=i*4+j;

				particleData.vertices[currentVertex].attenuatedColor=black;
			}

			continue;
		}

		for(int j=0; j<4; ++j)
		{
			int currentVertex=i*4+j;

			particleData.vertices[currentVertex].attenuatedColor.r=
									particleData.vertices[currentVertex].color.r*currentLight.color.r;
			
			particleData.vertices[currentVertex].attenuatedColor.g=
									particleData.vertices[currentVertex].color.g*currentLight.color.g;
			
			particleData.vertices[currentVertex].attenuatedColor.b=
									particleData.vertices[currentVertex].color.b*currentLight.color.b;

			float squaredDistance=(currentLight.boundingSphere.centre-
									particleData.vertices[currentVertex].position).GetSquaredLength();
			squaredDistance/=currentLight.boundingSphere.radius*currentLight.boundingSphere.radius;

			float attenuationFactor=1.0f-squaredDistance;
			if(attenuationFactor<0.0f)
				attenuationFactor=0.0f;

			particleData.vertices[currentVertex].attenuatedColor.a=
								particleData.vertices[currentVertex].color.a*attenuationFactor;
		}
	}
}


