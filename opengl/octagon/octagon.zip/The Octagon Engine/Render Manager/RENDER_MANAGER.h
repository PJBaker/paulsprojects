//////////////////////////////////////////////////////////////////////////////////////////
//	RENDER_MANAGER.h
//	Main header for the Octagon render manager
//	Downloaded from: www.paulsprojects.net
//	Created:	8th December 2002
//	Largely Rewritten:	21st January 2003
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	

#ifndef RENDER_MANAGER_H
#define RENDER_MANAGER_H

#include <vector>
#include "../List/LIST.h"

#include "../Point Light/POINT_LIGHT.h"

#include "RENDER_DATA_SET.h"

#include "TEXTURE_2D/TEXTURE_2D.h"
#include "TEXTURE_CUBE_MAP/TEXTURE_CUBE_MAP.h"

#include "Geometry/GEOMETRY_VERTEX.h"
#include "Geometry/GEOMETRY_TEXTURE.h"

#include "Particles/PARTICLE.h"
#include "Particles/PARTICLE_VERTEX.h"


class RENDER_MANAGER
{
protected:
	//protected constructor & copy constructor to prevent >1 instances
	RENDER_MANAGER()	:	spareVectors(NULL), particles(NULL), shadowVolumeVertices(NULL),
							varVertices(NULL)
	{}
	RENDER_MANAGER(const RENDER_MANAGER &)
	{}
	RENDER_MANAGER & operator=(const RENDER_MANAGER &)
	{}

public:
	//public function to access the instance
	static RENDER_MANAGER * Instance()
	{
		static RENDER_MANAGER instance;	//our sole instance
		return &instance;
	}

	//Reload textures
	void ReloadTextures(void)
	{
		for(std::size_t i=0; i<geometryData.textures.size(); ++i)
			geometryData.textures[i].Load();
		for(std::size_t i=0; i<particleData.textures.size(); ++i)
			geometryData.textures[i].Load();
		for(std::size_t i=0; i<cubeMapTextures.size(); ++i)
			cubeMapTextures[i].Load();
	}

//GEOMETRY
	RENDER_DATA_SET <GEOMETRY_VERTEX, GEOMETRY_TEXTURE> geometryData;

	VECTOR3D * spareVectors;	//store tangent space light vectors etc
	
	int AddTempGeometryVertex(const GEOMETRY_VERTEX & newVertex)
	{	return geometryData.AddTempVertex(newVertex);	}

	void UpdateGeometryVertices(int firstVertexIndex, int numVertices,
								const GEOMETRY_VERTEX * newVertices);

	GEOMETRY_VERTEX & GetGeometryVertex(int index)
	{	return geometryData.vertices[index];	}

	void AddGeometryElements(int textureIndex, int count, GLuint * indices)
	{	geometryData.AddElements(textureIndex, count, indices);	}

	void AddGeometryElementsEx(	int textureIndex, bool reverse, GLuint offset,
								int count, GLuint * indices)
	{	geometryData.AddElementsEx(textureIndex, reverse, offset, count, indices);	}

	int CreateGeometryTexture(char * filename);

	bool AreAnyActiveGeometryVerticesBehind(const PLANE & plane);

	void EnableGeometryVertexArrays(bool useNormalArray,
									GLenum textureCoordUnit1,
									GLenum textureCoordUnit2,
									GLenum sTangentUnit,
									GLenum tTangentUnit,
									GLenum spareUnit);
	void DisableGeometryVertexArrays();

//Which arrays are enabled?
protected:
	bool geometryVertexArrayEnabled;
	bool geometryNormalArrayEnabled;
	GLenum currentGeometryTextureCoordUnit1, currentGeometryTextureCoordUnit2;
	GLenum currentGeometrySTangentUnit, currentGeometryTTangentUnit;
	GLenum currentGeometrySpareUnit;

public:
	void DrawGeometry(	bool drawNonGloss,
						GLenum decalTextureUnit,
						GLenum normalMapTextureUnit,
						GLenum emissiveTextureUnit);

	void ClearGeometryLists()
	{	geometryData.ClearLists();	}

	//Calculate the TSB given 3 vertices
	void CalculateTSB(	const GEOMETRY_VERTEX & v1,
						const GEOMETRY_VERTEX & v2,
						const GEOMETRY_VERTEX & v3,
						VECTOR3D & normal, VECTOR3D & sTangent, VECTOR3D & tTangent);

	//Store the tangent space light vectors in "spare"
	void StoreTangentSpaceLightVectors(const VECTOR3D & lightPosition);



//PARTICLES
public:
	//Add a number of particles, returning the first index
	int AddParticles(int number)
	{
		int temp=numParticles;

		numParticles+=number;
		return temp;		
	}

	//Add a list of particles
	void AddParticleArray(int textureIndex, int first, int count);

	void UpdateParticles(	int firstParticle,
							int numNewParticles,
							PARTICLE * newParticles);

	int CreateParticleTexture(char * filename);

	
	//Calculate the position of the particle vertices, from the individual particle positions
	void CalculateParticleVertices();

	//Calculate attenuated colors for each vertex, based on a light
	void CalculateParticleVertexAttenuatedColors(const POINT_LIGHT & currentLight);

	//Enable vertex arrays
	void EnableParticleVertexArrays(bool useColorArray,
									bool useAttenuatedColorArray,
									GLenum textureCoordUnit);
	void DisableParticleVertexArrays();

	void SetOrientation(const MATRIX4X4 & viewMatrix);	//set the billboarding vectors

	//Draw the saved indices
	void DrawParticles(GLenum decalTextureUnit);

	//Clear the lists of particle indices
	void ClearParticleLists(void)
	{
		particleData.ClearLists();
	}

protected:
	RENDER_DATA_SET <PARTICLE_VERTEX, TEXTURE_2D> particleData;

	//Vectors used for billboarding
	VECTOR3D billboardRight, billboardUp;

	int numParticles;

	//particles. Filled after LockNumVertices
	PARTICLE * particles;

	//Current texture units used for each array. 0 if disabled
	bool particleVertexArrayEnabled;
	bool particleColorArrayEnabled;
	GLenum currentParticleTextureCoordUnit;













	
//SHADOW VOLUMES
public:
	void CalculateShadowVolumeVertices(	const POINT_LIGHT & light,
										bool calculateNonProjected, bool calculateProjected);

	void EnableShadowVolumeVertexArrays();
	void DisableShadowVolumeVertexArrays();

	//Add a silhouette edge
	void AddShadowVolumeEdge(bool zFail, unsigned int vertex1, unsigned int vertex2);

	//Add triangles as caps
	void AddShadowVolumeCaps(int count, unsigned int * indices);
	//Draw the shadow volumes
	void DrawShadowVolumes(bool drawZFail, bool drawZPass);

	void ClearShadowVolumeLists()
	{
		zPassEdgeIndices.Clear();
		zFailEdgeIndices.Clear();
		capIndices.Clear();
	}

protected:
	VECTOR4D * shadowVolumeVertices;

	bool shadowVolumeVertexArrayEnabled;
	
	LIST <GLuint> zPassEdgeIndices;
	LIST <GLuint> zFailEdgeIndices;
	LIST <GLuint> capIndices;


//CUBE MAP TEXTURES
public:
	void BindCubeMapTexture(int index)
	{	cubeMapTextures[index].Bind();	}

	int CreateTextureCubeMap(char * filename);

protected:
	std::vector <TEXTURE_CUBE_MAP> cubeMapTextures;


//OPTIMISATIONS
public:
	//Begin/end blocks of use
	//cannot be in 2 blocks at once
	void BeginDataUpdate(void);
	void EndDataUpdate(bool verticesUpdated, bool spareVectorsUpdated, bool shadowVolumesUpdated);

	void BeginGeometryDrawing(void);
	void EndGeometryDrawing(void);

	void BeginShadowDrawing(void);
	void EndShadowDrawing(void);

	void BeginParticleDrawing(void);
	void EndParticleDrawing(void);

protected:
	//VAR
	bool usingVAR;

	GLuint fence;	//fence for synchronisation
	bool fenceSet;	//is fence set?

	unsigned char * varVertices;		//pointer to AGP memory for VAR vertices
	int varSize;						//size of VAR buffer

	//Offsets and sizes within the VAR buffer
	int varVertexDataSize;
	int varVertexDataOffset;

	int varSpareDataSize;
	int varSpareDataOffset;
	
	int varShadowDataSize;
	int varShadowDataOffset;

	//VAO
	bool usingVAO;

	//Vertex array objects
	GLuint vertexVAO;
	int vertexVAOSize;

	GLuint spareVAO;
	int spareVAOSize;

	GLuint shadowVAO;
	int shadowVAOSize;
//MISC
public:
	//Lock the number of vertices
	bool LockNumVertices();

//OTHER TEXTURES
	GLuint atten2DTexture, atten1DTexture;
	bool InitAttenuationTextures();
	
	GLuint normCubeMap;
	bool InitNormCubeMap();

	bool InitTextures()
	{
		if(!InitAttenuationTextures() || !InitNormCubeMap())
			return false;
		return true;
	}

	//DESTRUCTOR
	~RENDER_MANAGER()
	{
		if(spareVectors)
			delete [] spareVectors;
		spareVectors=NULL;
		
		if(particles)
			delete [] particles;
		particles=NULL;
		
		if(shadowVolumeVertices)
			delete [] shadowVolumeVertices;
		shadowVolumeVertices=NULL;

		if(varVertices)
			wglFreeMemoryNV(varVertices);
		varVertices=NULL;
	}
};

#endif	//RENDER_MANAGER_H
