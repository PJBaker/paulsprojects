//////////////////////////////////////////////////////////////////////////////////////////
//	BeginEndBlocks.cpp
//	Begin/End blocks of usage of the render manager
//	Downloaded from: www.paulsprojects.net
//	Created:	22nd January 2003
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <vector>
#include "../../GL files/glee.h"			//header for OpenGL 1.4
#include "../../Maths/Maths.h"
#include "../../List/LIST.h"
#include "../../Console/CONSOLE.h"
#include "../RENDER_MANAGER.h"

//Begin updating data in the render manager
void RENDER_MANAGER::BeginDataUpdate()
{

}

void RENDER_MANAGER::EndDataUpdate(	bool verticesUpdated,
									bool spareVectorsUpdated,
									bool shadowVolumesUpdated)
{
	//Update the data in the VAR
	if(usingVAR && ((CONSOLE::Instance()->variables.useFastGeoVerts && verticesUpdated) ||
					(CONSOLE::Instance()->variables.useFastGeoVerts && spareVectorsUpdated) ||
					(CONSOLE::Instance()->variables.useFastShadowVerts && shadowVolumesUpdated)))
	{
		//Finish the fence before updating
		if(fenceSet)
		{
			glFinishFenceNV(fence);
			fenceSet=false;
		}


		//update vertices
		if(CONSOLE::Instance()->variables.useFastGeoVerts && verticesUpdated)
		{
			memcpy(	varVertices+varVertexDataOffset,
					geometryData.vertices,
					varVertexDataSize);
		}

		//Update the spare vectors
		if(CONSOLE::Instance()->variables.useFastGeoVerts && spareVectorsUpdated)
		{
			memcpy(	varVertices+varSpareDataOffset,
					spareVectors,
					varSpareDataSize);
		}

		//update shadow volume vertices
		if(CONSOLE::Instance()->variables.useFastShadowVerts && shadowVolumesUpdated)
		{
			memcpy(	varVertices+varShadowDataOffset,
					shadowVolumeVertices,
					varShadowDataSize);
		}
	}

	//Update the VAOs
	if(usingVAO)
	{
		if(CONSOLE::Instance()->variables.useFastGeoVerts && verticesUpdated)
		{
			//use DISCARD since we are overwriting the whole buffer
			glUpdateObjectBufferATI(vertexVAO, 0, vertexVAOSize,
									geometryData.vertices, GL_DISCARD_ATI);
		}

		if(CONSOLE::Instance()->variables.useFastGeoVerts && spareVectorsUpdated)
		{
			glUpdateObjectBufferATI(spareVAO, 0, spareVAOSize,
									spareVectors, GL_DISCARD_ATI);
		}

		if(CONSOLE::Instance()->variables.useFastShadowVerts && shadowVolumesUpdated)
		{
			glUpdateObjectBufferATI(shadowVAO, 0, shadowVAOSize,
									shadowVolumeVertices, GL_DISCARD_ATI);
		}
	}
}



void RENDER_MANAGER::BeginGeometryDrawing()
{
	if(usingVAR && CONSOLE::Instance()->variables.useFastGeoVerts)
		glEnableClientState(GL_VERTEX_ARRAY_RANGE_WITHOUT_FLUSH_NV);
}

void RENDER_MANAGER::EndGeometryDrawing()
{
	//Set the fence if we are using VAR
	if(usingVAR && CONSOLE::Instance()->variables.useFastGeoVerts)
	{
		glDisableClientState(GL_VERTEX_ARRAY_RANGE_WITHOUT_FLUSH_NV);
		
		glSetFenceNV(fence, GL_ALL_COMPLETED_NV);
		fenceSet=true;
	}
}


void RENDER_MANAGER::BeginShadowDrawing()
{
	if(usingVAR && CONSOLE::Instance()->variables.useFastShadowVerts)
		glEnableClientState(GL_VERTEX_ARRAY_RANGE_WITHOUT_FLUSH_NV);
}

void RENDER_MANAGER::EndShadowDrawing()
{
	//Set the fence if we are using VAR
	if(usingVAR && CONSOLE::Instance()->variables.useFastShadowVerts)
	{
		glDisableClientState(GL_VERTEX_ARRAY_RANGE_WITHOUT_FLUSH_NV);
		
		glSetFenceNV(fence, GL_ALL_COMPLETED_NV);
		fenceSet=true;
	}
}

void RENDER_MANAGER::BeginParticleDrawing()
{
	
}

void RENDER_MANAGER::EndParticleDrawing()
{
	
}
