//////////////////////////////////////////////////////////////////////////////////////////
//	IMAGE_ClearAlpha.cpp
//	Clear the alpha of an image to a given value
//	Downloaded from: www.paulsprojects.net
//	Created:	10th February 2003
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <GL/gl.h>
#include <GL/glext.h>
#include "../Log/LOG.h"
#include "IMAGE.h"

void IMAGE::ClearAlpha(float value)
{
	if(format==GL_RGBA || format==GL_BGRA)
	{
		for(unsigned int i=0; i<width*height; ++i)
		{
			data[i*4+3]=GLubyte(255*value);
		}
	}
	else
		LOG::Instance()->OutputError("Unsuitable format for clearing alpha");
}
