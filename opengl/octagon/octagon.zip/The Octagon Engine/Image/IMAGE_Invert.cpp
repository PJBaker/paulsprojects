//////////////////////////////////////////////////////////////////////////////////////////
//	IMAGE_Invert.cpp
//	Invert an image
//	Downloaded from: www.paulsprojects.net
//	Created:	10th February 2003
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <GL/gl.h>
#include "../Log/LOG.h"
#include "IMAGE.h"

void IMAGE::Invert()
{
	for(unsigned int i=0; i<stride*height*bpp/8; ++i)
		data[i]=255-data[i];
}