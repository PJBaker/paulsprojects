//////////////////////////////////////////////////////////////////////////////////////////
//	WALKING_CAMERA.h
//	Class declaration for a first person camera
//	Downloaded from: www.paulsprojects.net
//	Created:	21st November 2002
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////

#ifndef WALKING_CAMERA_H
#define WALKING_CAMERA_H

#include "../Maths/Maths.h"
#include "../Bounding Volumes/Bounding Volumes.h"
#include "../Bitset/BITSET.h"

class WALKING_CAMERA
{
public:
	BOUNDING_SPHERE boundingSphere;	//sphere centre is camera position
	float angleYaw, anglePitch;
	float speed;

	float nearDistance;	//distance of near plane (positive)
	float fovy;			//field ov view
	float aspectRatio;

	MATRIX4X4 viewMatrix;
	MATRIX4X4 projectionMatrix;

	FRUSTUM viewFrustum;

	//visible bsp faces
	BITSET visibleFaces;

	void Init(	VECTOR3D newPosition,
				float newAngleYaw,
				float newAnglePitch,
				float newSpeed,
				float newRadius);

	bool Update(double timePassed, int call);
	void FinishUpdate();

	const VECTOR3D & GetPosition()
	{	return boundingSphere.centre;	}
};

#endif	//WALKING_CAMERA_H