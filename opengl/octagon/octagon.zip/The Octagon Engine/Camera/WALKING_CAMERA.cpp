//////////////////////////////////////////////////////////////////////////////////////////
//	WALKING_CAMERA.cpp
//	Functions for a first person camera
//	Downloaded from: www.paulsprojects.net
//	Created:	21st November 2002
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include "../GL files/glee.h"	//library for OGL 1.4
#include "../Window/WINDOW.h"
#include "../Maths/Maths.h"
#include "../Log/LOG.h"
#include "../Bounding Volumes/Bounding Volumes.h"
#include "../Console/CONSOLE.h"
#include "WALKING_CAMERA.h"

//Init the camera
void WALKING_CAMERA::Init(	VECTOR3D newPosition,
							float newAngleYaw,
							float newAnglePitch,
							float newSpeed,
							float newRadius)
{
	speed=newSpeed;
	angleYaw=newAngleYaw;
	anglePitch=newAnglePitch;

	//set up bounding sphere
	boundingSphere.centre=newPosition+VECTOR3D(0.0f, 0.7f, 0.0f);
	boundingSphere.radius=newRadius;

	nearDistance=0.1f;
	fovy=75.0f;
	aspectRatio=(float)WINDOW::Instance()->width/(float)WINDOW::Instance()->height;

	//Init projection matrix - infinite far plane
	projectionMatrix.SetPerspective(fovy,
							aspectRatio,
							nearDistance, -1.0f);

	//Centre the mouse cursor
	SetCursorPos(WINDOW::Instance()->width/2, WINDOW::Instance()->height/2);
}

//Update the camera
//return true if we have finished updating, false if more collision calculations required
bool WALKING_CAMERA::Update(double timePassed, int call)
{
	//If this is the first call, calculate the distance
	static float distance=0.0f;
	if(call==0)
		distance=(speed*(float)timePassed)/1000;

	//If there is no distance left, we are done
	if(distance<=0.001f)
		return true;

	//If this is the first call, change angleYaw, anglePitch
	if(call==0)
	{
		//Get the mouse position
		POINT mousePos;
		GetCursorPos(&mousePos);

		//Get the mouse sensitivity from console
		float mouseSense=CONSOLE::Instance()->variables.mouseSensitivity;
	
		angleYaw+=(mousePos.x-WINDOW::Instance()->width/2)*mouseSense;
		anglePitch+=(mousePos.y-WINDOW::Instance()->height/2)*mouseSense;

		//Ensure anglePitch is not too steep
		if(anglePitch>80.0f)
			anglePitch=80.0f;

		if(anglePitch<-80.0f)
			anglePitch=-80.0f;

		//Reset cursor to centre of window
		SetCursorPos(WINDOW::Instance()->width/2, WINDOW::Instance()->height/2);
	}

	//Calculate how far to move on this iteration
	float iterDistance=0.25f*boundingSphere.radius;
	if(iterDistance>distance)
		iterDistance=distance;

	//Store a reference to the position
	VECTOR3D & position=boundingSphere.centre;
	
	//Move forward, backward or strafe by 0.8*radius
	if(	WINDOW::Instance()->IsKeyPressed(VK_UP)		||
		WINDOW::Instance()->IsKeyPressed('W'))
	{
		position.x += (float)sin(angleYaw*M_PI/180)*iterDistance;
		position.z -= (float)cos(angleYaw*M_PI/180)*iterDistance;
	}

	if(	WINDOW::Instance()->IsKeyPressed(VK_DOWN)	||
		WINDOW::Instance()->IsKeyPressed('S'))
	{
		position.x -= (float)sin(angleYaw*M_PI/180)*iterDistance;
		position.z += (float)cos(angleYaw*M_PI/180)*iterDistance;
	}

	if(	WINDOW::Instance()->IsKeyPressed(VK_RIGHT)	||
		WINDOW::Instance()->IsKeyPressed('D'))
	{
		position.x += (float)cos(angleYaw*M_PI/180)*iterDistance;
		position.z += (float)sin(angleYaw*M_PI/180)*iterDistance;
	}

	if(	WINDOW::Instance()->IsKeyPressed(VK_LEFT)	||
		WINDOW::Instance()->IsKeyPressed('A'))
	{
		position.x -= (float)cos(angleYaw*M_PI/180)*iterDistance;
		position.z -= (float)sin(angleYaw*M_PI/180)*iterDistance;
	}

	//Change height
	if(	WINDOW::Instance()->IsKeyPressed(VK_PRIOR))
		position.y+=iterDistance/2;

	if(	WINDOW::Instance()->IsKeyPressed(VK_NEXT))
		position.y-=iterDistance/2;

	//Subtract iterDistance from distance
	distance-=iterDistance;

	return false;
}

//Finish updates
void WALKING_CAMERA::FinishUpdate()
{
	//Update view matrix
	static MATRIX4X4 pitch, yaw, translation;
	pitch.SetRotationX(anglePitch);
	yaw.SetRotationY(angleYaw);
	translation.SetTranslation(-boundingSphere.centre);

	viewMatrix=pitch*yaw*translation;

	//Update view frustum
	viewFrustum.SetFromMatrices(viewMatrix, projectionMatrix);
}
