//////////////////////////////////////////////////////////////////////////////////////////
//	CONSOLE_ScrollUp.cpp
//	Toggle the quake like console
//	Downloaded from: www.paulsprojects.net
//	Created:	15th November 2002
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include "../GL files/glee.h"	//library for OGL 1.4
#include "../Maths/Maths.h"
#include "../Log/LOG.h"
#include "../Image/IMAGE.h"
#include "../Console/CONSOLE.h"

void CONSOLE::ScrollUp(int bottomLine)
{
	for(int i=numLines-1; i>=bottomLine+1; --i)
		lines[i]=lines[i-1];

	lines[bottomLine].Reset();
}