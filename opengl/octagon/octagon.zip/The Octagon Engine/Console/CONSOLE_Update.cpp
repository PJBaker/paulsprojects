//////////////////////////////////////////////////////////////////////////////////////////
//	CONSOLE_Update.cpp
//	Update the console
//	Downloaded from: www.paulsprojects.net
//	Created:	10th December 2002
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <vector>
#include "../GL files/glee.h"			//header for OpenGL 1.4
#include "../Maths/Maths.h"
#include "../Log/LOG.h"
#include "../Image/IMAGE.h"
#include "../Window/WINDOW.h"
#include "CONSOLE.h"

void CONSOLE::Update(double currentTime)
{
	//Toggle the console if the key has been pressed
	if(WINDOW::Instance()->IsKeyPressed(VK_F2))
		Toggle(currentTime);


	//If scrolling down, increase distance down
	if(isActive && distanceDown<1.0f)
	{
		distanceDown=float((currentTime-lastToggledTime)/timeToScroll);

		if(distanceDown>1.0f)
			distanceDown=1.0f;
	}

	//If scrolling up, decrease distance down
	if(!isActive && distanceDown>0.0f)
	{
		distanceDown=1.0f-float((currentTime-lastToggledTime)/timeToScroll);

		if(distanceDown<0.0f)
			distanceDown=0.0f;
	}

	
	//Fill in texture coordinates
	for(int line=0; line<numLines; ++line)
	{
		for(int i=0; i<lines[line].charsPerLine; ++i)
		{
			//Get character number
			int charNum=lines[line].text[i]-32;

			//Calculate base texture coords
			float cx=float(charNum%16)/16;
			float cy=1.0f-float(charNum/16)/16;

			int currentCoord=line*lines[line].charsPerLine+i;

			//Set coordinates
			texCoords[currentCoord*4+0].Set(cx			,	cy-0.0625f	);
			texCoords[currentCoord*4+1].Set(cx+0.0625f	,	cy-0.0625f	);
			texCoords[currentCoord*4+2].Set(cx+0.0625f	,	cy			);
			texCoords[currentCoord*4+3].Set(cx			,	cy			);
		}
	}

	//return if not active
	if(!isActive)
		return;

	//Test for typing

	//Characters to test for
	//Character code to test, followed by character code to display
	static unsigned char charsToTest[][2]={	'A', 'A', 'B', 'B', 'C', 'C', 'D', 'D', 'E', 'E',
											'F', 'F', 'G', 'G', 'H', 'H', 'I', 'I', 'J', 'J',
											'K', 'K', 'L', 'L',	'M', 'M', 'N', 'N', 'O', 'O',
											'P', 'P', 'Q', 'Q', 'R', 'R', 'S', 'S', 'T', 'T',
											'U', 'U', 'V', 'V', 'W', 'W', 'X', 'X', 'Y', 'Y',
											'Z', 'Z',
											'1', '1', '2', '2', '3', '3', '4', '4', '5', '5', 
											'6', '6', '7', '7', '8', '8', '9', '9', '0', '0',
											' ', ' ',
											(unsigned char)191, '/',
											VK_NUMPAD1, '1',
											VK_NUMPAD2, '2',
											VK_NUMPAD3, '3',
											VK_NUMPAD4, '4',
											VK_NUMPAD5, '5',
											VK_NUMPAD6, '6',
											VK_NUMPAD7, '7',
											VK_NUMPAD8, '8',
											VK_NUMPAD9, '9',
											VK_NUMPAD0, '0',
											VK_DECIMAL, '.',
											(unsigned char)190, '.'};//decimal on main keyboard

	//Test for these characters
	for(int i=0; i<sizeof(charsToTest)/(2*sizeof(char)); ++i)
	{
		if(WINDOW::Instance()->IsKeyPressed(charsToTest[i][0]))
		{
			lines[0].AddCharacter(charsToTest[i][1]);
			WINDOW::Instance()->SetKeyReleased(charsToTest[i][0]);
		}
	}

	//backspace
	if(WINDOW::Instance()->IsKeyPressed(VK_BACK))
	{
		lines[0].DeleteCharacter();
		WINDOW::Instance()->SetKeyReleased(VK_BACK);
	}


	//return if enter is not pressed
	if(!WINDOW::Instance()->IsKeyPressed(VK_RETURN))
		return;

	//release enter
	WINDOW::Instance()->SetKeyReleased(VK_RETURN);

	//Enter has been pressed

	//Scroll lines up
	ScrollUp(0);

	//Find out the command - the first word on the line
	//and the first argument
	char * command=new char[lines[1].charsPerLine+1];
	char * arg0=new char[lines[1].charsPerLine+1];

	if(!command || !arg0)
	{
		LOG::Instance()->OutputError("Unable to allocate space for console command");
		return;
	}

	int numFields=sscanf(lines[1].text, "%s %s", command, arg0);

	//Execute the command
	//If numFields=1, there was no argument
	if(numFields==2)
		ExecuteCommand(command, arg0);

	if(numFields==1)
		ExecuteCommand(command, "");

	if(command)
		delete [] command;
	command=NULL;

	if(arg0)
		delete [] arg0;
	arg0=NULL;
}
