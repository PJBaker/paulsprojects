//////////////////////////////////////////////////////////////////////////////////////////
//	CONSOLE_LINE.h
//	Class for a line in the console
//	Downloaded from: www.paulsprojects.net
//	Created:	10th December 2002
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	

#ifndef CONSOLE_LINE_H
#define CONSOLE_LINE_H

class CONSOLE_LINE
{
public:
	COLOR color;
	int charsPerLine;	//characters per line (same for all lines)
	char * text;		//initialised to point to exactly the number of characters on a line

	int cursorPosition;

	bool Init();
	void AddCharacter(char character);
	void DeleteCharacter();
	void Reset();

	//operator = for a deep copy, so we can do "lines[i]=lines[i-1]" to scroll up
	CONSOLE_LINE & operator=(const CONSOLE_LINE & rhs)
	{
		//return if the two objects are the same
		if(this == &rhs)
			return *this;

		//The two are different, so copy over
		color=rhs.color;
		charsPerLine=rhs.charsPerLine;
		memcpy(text, rhs.text, charsPerLine*sizeof(char));

		return *this;
	}


	CONSOLE_LINE()	:	text(NULL)
	{}
	~CONSOLE_LINE()
	{
		if(text)
			delete [] text;
		text=NULL;
	}
};

#endif	//CONSOLE_LINE_H