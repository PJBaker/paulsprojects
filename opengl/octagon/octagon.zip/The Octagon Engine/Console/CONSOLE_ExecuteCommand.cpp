//////////////////////////////////////////////////////////////////////////////////////////
//	CONSOLE_ExecuteCommand.cpp
//	Execute a console command
//	Downloaded from: www.paulsprojects.net
//	Created:	10th December 2002
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <string>
#include <vector>
#include "../GL files/glee.h"	//library for OGL 1.4
#include "../Maths/Maths.h"
#include "../Log/LOG.h"
#include "../Image/IMAGE.h"
#include "../Render Manager/RENDER_MANAGER.h"
#include "../Codepaths/CODEPATH_MANAGER.h"
#include "../Console/CONSOLE.h"

void CONSOLE::ExecuteCommand(char * command, char * arg0)
{
	bool hasArgument=false;

	//Is there an argument?
	if(strcmp(arg0, "")!=0)
		hasArgument=true;

	//Convert arg0 to integer, float and bool
	int intArg0=0;
	float floatArg0=0.0f;
	bool boolArg0=false;

	sscanf(arg0, "%d", &intArg0);
	sscanf(arg0, "%f", &floatArg0);
	if(intArg0>=1)
		boolArg0=true;

	if(boolArg0==false)
		if(strcmp(arg0, "TRUE")==0)
			boolArg0=true;

	
	//Execute the command

	//"EXEC" - Execute a config file
	if(strcmp(command, "EXEC")==0)
	{
		if(hasArgument)
			ExecCfg(arg0);
		else
			OutputLine(red, "No filename specified");

		return;
	}

	//"SAVE" - save a cfg file
	if(strcmp(command, "SAVE")==0)
	{
		if(hasArgument)
		{
			if(SaveCfg(arg0))
				OutputLine(green, "%s saved correctly", arg0);
			else
				OutputLine(red, "Could not save %s", arg0);
		}
		else
			OutputLine(red, "No filename specified");

		return;
	}


	//"SHOWSHADOWS"
	if(strcmp(command, "SHOWSHADOWS")==0)
	{
		if(hasArgument)
			variables.showShadows=boolArg0;
		
		OutputLine(green, "SHOWSHADOWS is %s", variables.showShadows ? "true" : "false");

		return;
	}

	//"SHOWPARTICLES"
	if(strcmp(command, "SHOWPARTICLES")==0)
	{
		if(hasArgument)
			variables.showParticles=boolArg0;
		
		OutputLine(green, "SHOWPARTICLES is %s", variables.showParticles ? "true" : "false");

		return;
	}


	//"USECOMPRESSEDTEXTURES"
	if(strcmp(command, "USECOMPRESSEDTEXTURES")==0)
	{
		if(hasArgument)
		{
			if(boolArg0)
				variables.useCompressedTextures=1;
			else
				variables.useCompressedTextures=0;
		}

		OutputLine(green, "USECOMPRESSEDTEXTURES is %s",
											variables.useCompressedTextures ? "true" : "false");
		OutputLine(green, "To update, RELOADTEXTURES is required");

		return;
	}

	//"DECALTEXTUREFILTER"
	if(strcmp(command, "DECALTEXTUREFILTER")==0)
	{
		if(hasArgument && intArg0>0 && intArg0<=4)
		{
			variables.decalTextureFilter=intArg0;
		}

		if(variables.decalTextureFilter==1)
			OutputLine(green, "DECALTEXTUREFILTER is NEAREST_MIPMAP_NEAREST");
		if(variables.decalTextureFilter==2)
			OutputLine(green, "DECALTEXTUREFILTER is LINEAR_MIPMAP_NEAREST");
		if(variables.decalTextureFilter==3)
			OutputLine(green, "DECALTEXTUREFILTER is NEAREST_MIPMAP_LINEAR");
		if(variables.decalTextureFilter==4)
			OutputLine(green, "DECALTEXTUREFILTER is LINEAR_MIPMAP_LINEAR");
		OutputLine(green, "To update, RELOADTEXTURES is required");

		return;
	}

	//DECALTEXTUREMAXANISOTROPY
	if(strcmp(command, "DECALTEXTUREMAXANISOTROPY")==0)
	{
		if(GLEE_EXT_texture_filter_anisotropic)
		{
			int maxAniso;
			glGetIntegerv(GL_MAX_TEXTURE_MAX_ANISOTROPY_EXT, &maxAniso);

			if(hasArgument && intArg0>0)
				if(intArg0<=maxAniso)
					variables.decalTextureMaxAnisotropy=intArg0;
				else
					variables.decalTextureMaxAnisotropy=maxAniso;

			OutputLine(green, "DECALTEXTUREMAXANISOTROPY is %d", variables.decalTextureMaxAnisotropy);
			OutputLine(green, "To update, RELOADTEXTURES is required");
		}
		else
		{
			variables.decalTextureMaxAnisotropy=1;

			OutputLine(red, "EXT_texture_filter_anisotropic unsupported");
		}
		
		return;
	}

	//"NORMALTEXTUREFILTER"
	if(strcmp(command, "NORMALTEXTUREFILTER")==0)
	{
		if(hasArgument && intArg0>0 && intArg0<=4)
		{
			variables.normalTextureFilter=intArg0;
		}

		if(variables.normalTextureFilter==1)
			OutputLine(green, "NORMALTEXTUREFILTER is NEAREST_MIPMAP_NEAREST");
		if(variables.normalTextureFilter==2)
			OutputLine(green, "NORMALTEXTUREFILTER is LINEAR_MIPMAP_NEAREST");
		if(variables.normalTextureFilter==3)
			OutputLine(green, "NORMALTEXTUREFILTER is NEAREST_MIPMAP_LINEAR");
		if(variables.normalTextureFilter==4)
			OutputLine(green, "NORMALTEXTUREFILTER is LINEAR_MIPMAP_LINEAR");
		OutputLine(green, "To update, RELOADTEXTURES is required");

		return;
	}

	//NORMALTEXTUREMAXANISOTROPY
	if(strcmp(command, "NORMALTEXTUREMAXANISOTROPY")==0)
	{
		if(GLEE_EXT_texture_filter_anisotropic)
		{
			int maxAniso;
			glGetIntegerv(GL_MAX_TEXTURE_MAX_ANISOTROPY_EXT, &maxAniso);

			if(hasArgument && intArg0>0)
				if(intArg0<=maxAniso)
					variables.normalTextureMaxAnisotropy=intArg0;
				else
					variables.normalTextureMaxAnisotropy=maxAniso;

			OutputLine(green, "NORMALTEXTUREMAXANISOTROPY is %d",
														variables.normalTextureMaxAnisotropy);
			OutputLine(green, "To update, RELOADTEXTURES is required");
		}
		else
		{
			variables.normalTextureMaxAnisotropy=1;

			OutputLine(red, "EXT_texture_filter_anisotropic unsupported");
		}

		return;
	}

	//RELOADTEXTURES
	if(strcmp(command, "RELOADTEXTURES")==0)
	{
		RENDER_MANAGER::Instance()->ReloadTextures();
		return;
	}

	//USEFASTGEOVERTS
	if(strcmp(command, "USEFASTGEOVERTS")==0)
	{
		if(hasArgument)
			variables.useFastGeoVerts=boolArg0;
		
		OutputLine(green, "USEFASTGEOVERTS is %s", variables.useFastGeoVerts ? "true" : "false");

		return;
	}

	//USEFASTSHADOWVERTS
	if(strcmp(command, "USEFASTSHADOWVERTS")==0)
	{
		if(hasArgument)
			variables.useFastShadowVerts=boolArg0;
		
		OutputLine(green, "USEFASTSHADOWVERTS is %s", variables.useFastShadowVerts ? "true" : "false");

		return;
	}

	//"MOUSESENSITIVITY"
	if(strcmp(command, "MOUSESENSITIVITY")==0)
	{
		if(hasArgument)
			variables.mouseSensitivity=floatArg0;

		OutputLine(green, "MOUSESENSITIVITY is %.2f", variables.mouseSensitivity);

		return;
	}


	//"PATCHTESSELATION"
	if(strcmp(command, "PATCHTESSELATION")==0)
	{
		if(hasArgument)
			variables.patchTesselation=intArg0;

		OutputLine(green, "PATCHTESSELATION is %d", variables.patchTesselation);
		OutputLine(green, "Restart required to update");

		return;
	}


	//Codepaths
	int newCodepath=-1;

	if(strcmp(command, "USESTANDARDPATH")==0)
		newCodepath=0;
	if(strcmp(command, "USENV20PATH")==0)
		newCodepath=1;
	if(strcmp(command, "USER200PATH")==0)
		newCodepath=2;
		
	if(newCodepath!=-1)
	{
		if(hasArgument && boolArg0)
		{
			if(CODEPATH_MANAGER::Instance()->ChangeCodepath(newCodepath))
			{
				variables.useStandardPath= (newCodepath==0) ? true : false;
				variables.useNV20Path= (newCodepath==1) ? true : false;
				variables.useR200Path= (newCodepath==2) ? true : false;
			}
		}
	
		OutputLine(green, "USESTANDARDPATH is %s", variables.useStandardPath ? "true" : "false");
		OutputLine(green, "USENV20PATH is %s", variables.useNV20Path ? "true" : "false");
		OutputLine(green, "USER200PATH is %s", variables.useR200Path ? "true" : "false");

		return;
	}




	//USELIGHTOCCLUSIONTEST
	if(strcmp(command, "USELIGHTOCCLUSIONTEST")==0)
	{
		if(GLEE_HP_occlusion_test)
		{
			if(hasArgument)
				variables.useLightOcclusionTest=boolArg0;
			
			OutputLine(green, "USELIGHTOCCLUSIONTEST is %s",
											variables.useLightOcclusionTest ? "true" : "false");
		}
		else
		{
			variables.useLightOcclusionTest=0;

			OutputLine(red, "HP_occlusion_test unsupported");
		}
		
		return;
	}


	//"USESCISSOR"
	if(strcmp(command, "USESCISSOR")==0)
	{
		if(hasArgument)
			variables.useScissor=boolArg0;
		
		OutputLine(green, "USESCISSOR is %s", variables.useScissor ? "true" : "false");

		return;
	}

	//"USEPOLYOFFSET"
	if(strcmp(command, "USEPOLYOFFSET")==0)
	{
		if(hasArgument)
			variables.usePolyOffset=boolArg0;
		
		OutputLine(green, "USEPOLYOFFSET is %s", variables.usePolyOffset ? "true" : "false");

		return;
	}


	//"NOCLIP"
	if(strcmp(command, "NOCLIP")==0)
	{
		if(hasArgument)
			variables.noclip=boolArg0;
		
		OutputLine(green, "NOCLIP is %s", variables.noclip ? "true" : "false");

		return;
	}


	//"SHOWBOUNDINGBOXES"
	if(strcmp(command, "SHOWBOUNDINGBOXES")==0)
	{
		if(hasArgument)
			variables.showBoundingBoxes=boolArg0;
		
		OutputLine(green, "SHOWBOUNDINGBOXES is %s",
											variables.showBoundingBoxes ? "true" : "false");

		return;
	}

	//"SHOWLIGHTPOSITIONS"
	if(strcmp(command, "SHOWLIGHTPOSITIONS")==0)
	{
		if(hasArgument)
			variables.showLightPositions=boolArg0;
		
		OutputLine(green, "SHOWLIGHTPOSITIONS is %s",
											variables.showLightPositions ? "true" : "false");

		return;
	}

	//"SHOWSCISSORRECTANGLES"
	if(strcmp(command, "SHOWSCISSORRECTANGLES")==0)
	{
		if(hasArgument)
			variables.showScissorRectangles=boolArg0;
		
		OutputLine(green, "SHOWSCISSORRECTANGLES is %s",
											variables.showScissorRectangles ? "true" : "false");

		return;
	}

	//"SHOWDEBUGINFO"
	if(strcmp(command, "SHOWDEBUGINFO")==0)
	{
		if(hasArgument)
			variables.showDebugInfo=boolArg0;
		
		OutputLine(green, "SHOWDEBUGINFO is %s",
											variables.showDebugInfo ? "true" : "false");

		return;
	}

	//Command not recognised
	OutputLine(red, "UNKNOWN COMMAND");
}

