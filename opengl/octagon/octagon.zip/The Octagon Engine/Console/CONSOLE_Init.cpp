//////////////////////////////////////////////////////////////////////////////////////////
//	CONSOLE_Init.cpp
//	Initiate the console
//	Downloaded from: www.paulsprojects.net
//	Created:	10th December 2002
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <vector>
#include "../GL files/glee.h"			//header for OpenGL 1.4
#include "../Maths/Maths.h"
#include "../Log/LOG.h"
#include "../Image/IMAGE.h"
#include "CONSOLE.h"

bool CONSOLE::Init(	int newNumLines, int newCharsPerLine,
					double newTimeToScroll, const COLOR & newBackgroundColor)
{
	//Fill in class variables
	numLines=newNumLines;
	timeToScroll=newTimeToScroll;
	backgroundColor=newBackgroundColor;

	isActive=false;
	lastToggledTime=0.0;
	distanceDown=0.0f;

	//Create space for the lines
	lines=new CONSOLE_LINE[numLines];
	if(!lines)
	{
		LOG::Instance()->OutputError("Unable to create space for console lines");
		return false;
	}

	//Init the lines
	for(int i=0; i<numLines; ++i)
	{
		lines[i].charsPerLine=newCharsPerLine;
		lines[i].Init();
	}
	
	//Load the font texture
	IMAGE fontImage;
	fontImage.Load("Console/font.bmp");

	//Create texture
	glGenTextures(1, &fontTexture);
	glBindTexture(GL_TEXTURE_2D, fontTexture);

	//Use the color index values from an 8 bit font texture as intensity
	if(fontImage.bpp==8)
	{
		glTexImage2D(	GL_TEXTURE_2D, 0, GL_INTENSITY8, fontImage.width, fontImage.height,
						0, GL_LUMINANCE, GL_UNSIGNED_BYTE, fontImage.data);
	}
	else	//otherwise, convert rgb to luminance
		glTexImage2D(	GL_TEXTURE_2D, 0, GL_INTENSITY8, fontImage.width, fontImage.height,
						0, fontImage.format, GL_UNSIGNED_BYTE, fontImage.data);

	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

	
	//Create space for vertex positions and texture coords
	vertexPositions=new VECTOR2D[numLines*lines[0].charsPerLine*4];
	texCoords=new VECTOR2D[numLines*lines[0].charsPerLine*4];
	if(!vertexPositions || !texCoords)
	{
		LOG::Instance()->OutputError("Unable to create space for console quads");
		return false;
	}

	//Fill in vertex positions
	for(int line=0; line<numLines; ++line)
	{
		for(int i=0; i<lines[0].charsPerLine; ++i)
		{
			int currentChar=line*lines[0].charsPerLine+i;
			vertexPositions[currentChar*4+0].Set(	float(i-(lines[0].charsPerLine/2))/(lines[0].charsPerLine/2),
													float(line)/numLines);
			vertexPositions[currentChar*4+1].Set(	float(i-((lines[0].charsPerLine-1)/2))/(lines[0].charsPerLine/2),
													float(line)/numLines);
			vertexPositions[currentChar*4+2].Set(	float(i-((lines[0].charsPerLine-1)/2))/(lines[0].charsPerLine/2),
													float(line+1)/numLines);
			vertexPositions[currentChar*4+3].Set(	float(i-(lines[0].charsPerLine/2))/(lines[0].charsPerLine/2),
													float(line+1)/numLines);
		}
	}

	//Run the previous cfg
	if(!ExecCfg("data/cfg/Previous.cfg"))
	{
		//If failed, run the default cfg
		if(!ExecCfg("data/cfg/default.cfg"))
			LOG::Instance()->OutputError("Unable to open \"data/cfg/default.cfg\"");
	}

	return true;
}