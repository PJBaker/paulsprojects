//////////////////////////////////////////////////////////////////////////////////////////
//	CONSOLE_SaveCfg.cpp
//	Save the commands into a .cfg file
//	Downloaded from: www.paulsprojects.net
//	Created:	15th February 2003
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <string>
#include "../GL files/glee.h"	//library for OGL 1.4
#include "../Maths/Maths.h"
#include "../Log/LOG.h"
#include "../Image/IMAGE.h"
#include "../Console/CONSOLE.h"

bool CONSOLE::SaveCfg(char * filename)
{
	FILE * file;

	//Open cfg file
	file=fopen(filename, "wt");
	if(!file)
	{
		OutputLine(red, "Unable to open %s", filename);
		return false;
	}

	//Write the variables to the file
	fprintf(file, "SHOWSHADOWS %d\n", variables.showShadows);
	fprintf(file, "SHOWPARTICLES %d\n\n", variables.showParticles);
	
	fprintf(file, "USECOMPRESSEDTEXTURES %d\n\n", variables.useCompressedTextures);
	
	fprintf(file, "DECALTEXTUREFILTER %d\n", variables.decalTextureFilter);
	fprintf(file, "DECALTEXTUREMAXANISOTROPY %d\n", variables.decalTextureMaxAnisotropy);
	fprintf(file, "NORMALTEXTUREFILTER %d\n", variables.normalTextureFilter);
	fprintf(file, "NORMALTEXTUREMAXANISOTROPY %d\n", variables.normalTextureMaxAnisotropy);
	
	fprintf(file, "USEFASTGEOVERTS %d\n", variables.useFastGeoVerts);
	fprintf(file, "USEFASTSHADOWVERTS %d\n\n", variables.useFastShadowVerts);

	fprintf(file, "MOUSESENSITIVITY %f\n\n", variables.mouseSensitivity);
	
	fprintf(file, "PATCHTESSELATION %d\n\n", variables.patchTesselation);

	fprintf(file, "USESTANDARDPATH %d\n", variables.useStandardPath);
	fprintf(file, "USENV20PATH %d\n", variables.useNV20Path);
	fprintf(file, "USER200PATH %d\n\n", variables.useR200Path);
	
	fprintf(file, "USELIGHTOCCLUSIONTEST %d\n\n", variables.useLightOcclusionTest);

	fprintf(file, "USESCISSOR %d\n\n", variables.useScissor);
	fprintf(file, "USEPOLYOFFSET %d\n\n", variables.usePolyOffset);

	fprintf(file, "NOCLIP %d\n\n", variables.noclip);

	fprintf(file, "SHOWBOUNDINGBOXES %d\n", variables.showBoundingBoxes);
	fprintf(file, "SHOWLIGHTPOSITIONS %d\n", variables.showLightPositions);
	fprintf(file, "SHOWSCISSORRECTANGLES %d\n", variables.showScissorRectangles);
	fprintf(file, "SHOWDEBUGINFO %d\n\n", variables.showDebugInfo);
	
	fprintf(file, "END \n");

	fclose(file);

	return true;
}