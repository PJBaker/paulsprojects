//////////////////////////////////////////////////////////////////////////////////////////
//	CONSOLE_OutputLine.cpp
//	Put a line onto the console
//	Downloaded from: www.paulsprojects.net
//	Created:	11th December 2002
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <string>
#include "../GL files/glee.h"	//library for OGL 1.4
#include "../Maths/Maths.h"
#include "../Log/LOG.h"
#include "../Image/IMAGE.h"
#include "../Console/CONSOLE.h"

void CONSOLE::OutputLine(const COLOR & color, char * newText, ...)
{
	//scroll up the previous lines
	ScrollUp(1);

	//write the text in line 1
	lines[1].color=color;

	//Compile string to output
	char string[256];

	va_list argList;
	va_start(argList, newText);

	//write the text to "string"
	vsprintf(string, newText, argList);

	va_end(argList);

	//Output the string
	int newLength=strlen(string);

	//don't write more characters than will fit on a line
	if(newLength>lines[1].charsPerLine-1)
		newLength=lines[1].charsPerLine-1;

	strncpy(lines[1].text, string, newLength);
}
