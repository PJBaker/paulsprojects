//////////////////////////////////////////////////////////////////////////////////////////
//	CONSOLE_VARIABLES.h
//	Variables stored in the console
//	Downloaded from: www.paulsprojects.net
//	Created:	10th December 2002
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	

#ifndef CONSOLE_VARIABLE_H
#define CONSOLE_VARIABLE_H

class CONSOLE_VARIABLES
{
public:
	//Global enables
	bool showShadows;
	bool showParticles;
	//Textures
	bool useCompressedTextures;		//use compressed textures. Requires texture reload
		
	//Texture filters & anisotropy. Require reload
	//1=NEAREST, 2=LINEAR, 3=LINEAR_MIPMAP_NEAREST, 4=LINEAR_MIPMAP_LINEAR
	int decalTextureFilter;
	int decalTextureMaxAnisotropy;
	int normalTextureFilter;
	int normalTextureMaxAnisotropy;
	
	//Vertices
	bool useFastGeoVerts;		//use VAR/VAO for geometry?
	bool useFastShadowVerts;
//	bool useFastParticleVerts;
	
	//Input
	float mouseSensitivity;

	//bsp
	int patchTesselation;

	//Codepaths
	bool useStandardPath;
	bool useNV20Path;
	bool useR200Path;

	//optimisations
	bool useLightOcclusionTest;		//do an occlusion test on the light's bounding sphere before
									//using it to light anything

	bool useScissor;
	bool usePolyOffset;

	bool noclip;

	//debug views
	bool showBoundingBoxes;
	bool showLightPositions;
	bool showScissorRectangles;
	bool showDebugInfo;
};

#endif	//CONSOLE_VARIABLE_H