//////////////////////////////////////////////////////////////////////////////////////////
//	CONSOLE.h
//	Main header for the Octagon console
//	Downloaded from: www.paulsprojects.net
//	Created:	10th December 2002
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	

#ifndef CONSOLE_H
#define CONSOLE_H

#include "CONSOLE_LINE.h"
#include "CONSOLE_VARIABLES.h"

class CONSOLE
{
protected:
	//Protected constructor & copy contructor tp prevent copies
	CONSOLE()
	{}
	CONSOLE(const CONSOLE &)
	{}
	CONSOLE & operator=(const CONSOLE &)
	{}

public:
	//Public function to access instance of console class
	static CONSOLE * Instance()
	{
		static CONSOLE instance;	//our sole instance
		return &instance;
	}

	//Save the default cfg on shutdown
	~CONSOLE()
	{
		SaveCfg("data/cfg/Previous.cfg");

		if(lines)
			delete [] lines;
		lines=NULL;
	}

	bool Init(	int newNumLines, int newCharsPerLine,
				double newTimeToScroll, const COLOR & newBackgroundColor);

	void Update(double currentTime);
	void Toggle(double currentTime);

	void Draw();

	bool isActive;

protected:
	//scroll lines up from bottomLine
	void ScrollUp(int bottomLine);

	//Add a line of response
	void OutputLine(const COLOR & color, char * newText, ...);

	//time of last toggle
	double lastToggledTime;
	double timeToScroll;

	float distanceDown;		//0=fully up, 1=fully down

	//Lines of text
	int numLines;
	CONSOLE_LINE * lines;

	COLOR backgroundColor;

	//vertex arrays
	VECTOR2D * vertexPositions;
	VECTOR2D * texCoords;

	//Font texture
	GLuint fontTexture;


	//Execute a command
	void ExecuteCommand(char * command, char * arg0);

	//Execute a .cfg file
	bool ExecCfg(char * filename);

	//Save a .cfg file
	bool SaveCfg(char * filename);

	//variables
public:
	CONSOLE_VARIABLES variables;
};

#endif	//CONSOLE_H