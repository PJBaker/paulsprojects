//////////////////////////////////////////////////////////////////////////////////////////
//	CONSOLE_ExecCfg.cpp
//	Execute the commands in a .cfg file
//	Downloaded from: www.paulsprojects.net
//	Created:	10th December 2002
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <string>
#include "../GL files/glee.h"	//library for OGL 1.4
#include "../Maths/Maths.h"
#include "../Log/LOG.h"
#include "../Image/IMAGE.h"
#include "../Console/CONSOLE.h"

bool CONSOLE::ExecCfg(char * filename)
{
	FILE * file;

	//Open cfg file
	file=fopen(filename, "rt");
	if(!file)
	{
		OutputLine(red, "Unable to open %s", filename);
		return false;
	}

	//create space to hold commands & arguments
	char * command=new char[lines[0].charsPerLine];
	char * arg0=new char[lines[0].charsPerLine];
	if(!command || !arg0)
	{
		OutputLine(red, "Unable to create memory to execute cfg");
		return false;
	}

	//loop through, read a command and argument
	for(int i=0; i<10000; ++i)
	{
		//read in a command and an argument if present on the same line
		int fields=fscanf(file, "%s%*[ ]%s", command, arg0);

		//Break if the command is "END"
		if(strcmp(command, "END")==0)
			break;

		//Output & execute the command
		
		//if fields==2, we have a command and argument
		if(fields==2)
		{
			OutputLine(white, "%s %s", command, arg0);
			ExecuteCommand(command, arg0);
		}

		//if fields==1, we have no argument
		if(fields==1)
		{
			OutputLine(white, "%s", command);
			ExecuteCommand(command, "");
		}
	}

	fclose(file);

	if(command)
		delete [] command;
	command=NULL;

	if(arg0)
		delete [] arg0;
	arg0=NULL;

	return true;
}