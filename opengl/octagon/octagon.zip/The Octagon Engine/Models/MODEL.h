//////////////////////////////////////////////////////////////////////////////////////////
//	MODEL.h
//	Abstract base class for the data from a model file 
//	Downloaded from: www.paulsprojects.net
//	Created:	17th December 2002
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	

#ifndef MODEL_H
#define MODEL_H

#include "../Point Light/POINT_LIGHT.h"

//Animation sequences for models
enum ANIM_SEQUENCE
{
	ANIMSEQ_FIRSTFRAME=0,	//stay in first frame of anim
	ANIMSEQ_IDLE,
	ANIMSEQ_RUN
};

class MODEL
{
public:
	virtual bool Load()=0;

	//Send vertices to vertex manager
	virtual int SendVertices(const VECTOR3D & instancePosition, float instanceAngleYaw)=0;

	//Update vertices
	virtual void UpdateVertices(ANIM_SEQUENCE animSequence,
								float distanceThroughAnimSequence,
								int firstVertexIndex,
								const VECTOR3D & instancePosition,
								float instanceAngleYaw)=0;

	//Fill in the plane equations from a given vertex start point
	void FillPlaneEquations(int firstVertexIndex,
							PLANE * planes);

	void SendIndices(int firstVertexIndex);

	void SendShadowVolumeIndices(	bool zFailRequired, 
									const VECTOR3D & lightPosition,
									int firstVertexIndex,
									PLANE * planeEquations);

	char filename[128];

	int numVertices;	//number of unique vertices per frame

	//Textures
	std::vector <int> surfaceTextureIndices;

	//Indices
	int numTriangles;			//total number of indices/3
	std::vector <LIST <unsigned int> > indexLists;	//one list of indices per texture

	//Used for shadows:
	int * neighbourIndices;		//neighbour faces for each face
	bool * isFacing;			//is each face facing the light?

	bool CalculateNeighbours(void);	//calculate neighbour indices

	MODEL()	:	numVertices(0), numTriangles(0), neighbourIndices(NULL), isFacing(NULL)
	{}
	virtual ~MODEL()
	{
		if(neighbourIndices)
			delete [] neighbourIndices;
		neighbourIndices=NULL;

		if(isFacing)
			delete [] isFacing;
		isFacing=NULL;
	}
};

#endif	//MODEL_H