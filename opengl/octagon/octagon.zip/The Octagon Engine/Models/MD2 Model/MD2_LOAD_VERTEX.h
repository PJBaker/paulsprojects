//////////////////////////////////////////////////////////////////////////////////////////
//	MD2_LOAD_VERTEX.h
//	Class for a vertex as found in md2 file
//	Downloaded from: www.paulsprojects.net
//	Created:	18th December 2002
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	

#ifndef MD2_LOAD_VERTEX_H
#define MD2_LOAD_VERTEX_H

class MD2_LOAD_VERTEX
{
public:
	GLubyte position[3];
	GLubyte normalIndex;
};

#endif	//MD2_LOAD_VERTEX_H