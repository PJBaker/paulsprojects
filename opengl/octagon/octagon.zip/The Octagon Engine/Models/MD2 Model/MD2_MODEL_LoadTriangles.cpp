//////////////////////////////////////////////////////////////////////////////////////////
//	MD2_MODEL_LoadTriangles.cpp
//	Load md2 model triangles and assemble vertices
//	Downloaded from: www.paulsprojects.net
//	Created:	16th December 2002
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <vector>
#include "../../GL files/glee.h"
#include "../../Maths/Maths.h"
#include "../../Log/LOG.h"
#include "../../Bounding Volumes/Bounding Volumes.h"
#include "../../Render Manager/RENDER_MANAGER.h"
#include "../../Console/CONSOLE.h"
#include "../MODEL_MANAGER.h"

bool MD2_MODEL::LoadTriangles(FILE * file)
{
	//Calculate number of triangles
	int numTriangles=header.numTriangles;

	//Create space for this many MD2_LOAD_TRIANGLEs
	MD2_LOAD_TRIANGLE * loadTriangles=new MD2_LOAD_TRIANGLE[numTriangles];
	if(!loadTriangles)
	{
		LOG::Instance()->OutputError("Unable to allocate memory for %d MD2_LOAD_TRIANGLEs",
										numTriangles);
		return false;
	}

	//Read in the LOAD_TRIANGLEs
	fseek(file, header.offsetTris, SEEK_SET);
	fread(loadTriangles, numTriangles, sizeof(MD2_LOAD_TRIANGLE), file);


	//Create a vector of all the unique (vertex, texcoord) index pairs
	std::vector <MD2_INDEX_PAIR> indexPairs;
	MD2_INDEX_PAIR currentIndexPair;

	for(int i=0; i<numTriangles; ++i)
	{
		for(int j=0; j<3; ++j)
		{
			currentIndexPair.vertexIndex=loadTriangles[i].vertexIndices[j];
			currentIndexPair.stIndex=loadTriangles[i].stIndices[j];

			bool alreadyAdded=false;

			//See if this index pair is already in the vector
			for(std::size_t k=0; k<indexPairs.size(); ++k)
			{
				if(currentIndexPair==indexPairs[k])
					alreadyAdded=true;
			}

			//if the pair is not already in the vector, add it
			if(!alreadyAdded)
				indexPairs.push_back(currentIndexPair);
		}
	}

	//There will be indexpairs.size() unique vertices per frame
	numVertices=indexPairs.size();

	//Create space for the vertices. We need indexPairs.size() * numFrames
	int numTotalVertices=numVertices * header.numFrames;
	vertices=new GEOMETRY_VERTEX[numTotalVertices];
	if(!vertices)
	{
		LOG::Instance()->OutputError("Unable to allocate space for %d vertices",
										numTotalVertices);
		return false;
	}

	//Fill in the vertex positions & texture coords
	GEOMETRY_VERTEX * currentVertex=&vertices[0];

	for(int i=0; i<header.numFrames; ++i)
	{
		for(int j=0; j<numVertices; ++j)
		{
			currentVertex->position=tempVertices[i*header.numVertices+indexPairs[j].vertexIndex];
			currentVertex->texCoords.x= (float)tempTexCoords[indexPairs[j].stIndex].s / 
																				header.skinWidth;
			currentVertex->texCoords.y=-(float)tempTexCoords[indexPairs[j].stIndex].t /
																				header.skinHeight;

			++currentVertex;
		}
	}


	
		
	//Fill in the index list
	//Loop through triangles
	for(int i=0; i<numTriangles; ++i)
	{
		//Loop through verts of the triangle, reversing the order
		for(int j=0; j<3; ++j)
		{
			//Get the index pair for this vertex
			currentIndexPair.vertexIndex=loadTriangles[i].vertexIndices[2-j];
			currentIndexPair.stIndex=loadTriangles[i].stIndices[2-j];

			//Find this pair in the list of pairs
			for(unsigned int k=0; k<indexPairs.size(); ++k)
			{
				if(currentIndexPair==indexPairs[k])
				{
					//Add this index to the list
					indexLists[0].AddElements(1, &k);
					break;
				}
			}
		}
	}


	//Calculate the TSB for each triangle and add to the vertices
	VECTOR3D normal, sTangent, tTangent;
	for(int i=0; i<numFrames; ++i)
	{
		for(int j=0; j<indexLists[0].GetSize(); j+=3)
		{
			RENDER_MANAGER::Instance()->CalculateTSB(	
										vertices[i*numVertices+indexLists[0].entries[j+0]],
										vertices[i*numVertices+indexLists[0].entries[j+1]],
										vertices[i*numVertices+indexLists[0].entries[j+2]],
										normal, sTangent, tTangent);

			//Add this to the vertices
			for(int k=0; k<3; ++k)
			{
				vertices[i*numVertices+indexLists[0].entries[j+k]].normal+=normal;
				vertices[i*numVertices+indexLists[0].entries[j+k]].sTangent+=sTangent;
				vertices[i*numVertices+indexLists[0].entries[j+k]].tTangent+=tTangent;
			}
		}
	}

	//Normalise TSBs
	for(int i=0; i<numFrames*numVertices; ++i)
	{
		vertices[i].normal.Normalize();
		vertices[i].sTangent.Normalize();
		vertices[i].tTangent.Normalize();
	}

	return true;
}
