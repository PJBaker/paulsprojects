//////////////////////////////////////////////////////////////////////////////////////////
//	MD2_MODEL_UpdateVertices.cpp
//	Update vertices in the render manager for md2 model data
//	Downloaded from: www.paulsprojects.net
//	Created:	16th December 2002
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <vector>
#include "../../GL files/glee.h"
#include "../../Maths/Maths.h"
#include "../../Log/LOG.h"
#include "../../Bounding Volumes/Bounding Volumes.h"
#include "../../Render Manager/RENDER_MANAGER.h"
#include "../../Console/CONSOLE.h"
#include "../MODEL_MANAGER.h"

void MD2_MODEL::UpdateVertices(	ANIM_SEQUENCE animSequence,
								float distanceThroughAnimSequence,
								int firstVertexIndex,
								const VECTOR3D & instancePosition,
								float instanceAngleYaw)
{
	//Calculate the current frame by lerping between 2 values
	int animStartFrame=0, animEndFrame=0;

	if(animSequence==ANIMSEQ_FIRSTFRAME)
	{
		animStartFrame=0, animEndFrame=0;
	}
	
	if(animSequence==ANIMSEQ_IDLE)
	{
		animStartFrame=MD2_ANIMSEQ_IDLE_STARTFRAME;
		animEndFrame=MD2_ANIMSEQ_IDLE_ENDFRAME;
	}
	if(animSequence==ANIMSEQ_RUN)
	{
		animStartFrame=MD2_ANIMSEQ_RUN_STARTFRAME;
		animEndFrame=MD2_ANIMSEQ_RUN_ENDFRAME;
	}

	float frameNumber=animStartFrame+distanceThroughAnimSequence*(animEndFrame+1-animStartFrame);

	//Calculate the frames to lerp between
	int frame1=int(floorf(frameNumber));
	int frame2=frame1+1;
	
	//correct for frameNumber > end ofsequence
	if(frameNumber>(float)animEndFrame)
		frame2=animStartFrame;

	float interpolationFactor=frameNumber-(float)frame1;
	
	//Check the frames are in bounds
	if(frame2>=numFrames)
		return;

	//Fill in the frameVertices
	//If the interpolation factor is 0, use frame1
	if(interpolationFactor==0.0f)
	{
		int frame1TimesNumVerts=frame1*numVertices;

		for(int i=0; i<numVertices; ++i)
		{
			frameVertices[i]=
				vertices[frame1TimesNumVerts+i].GetModelTransformed(instancePosition,
																	instanceAngleYaw);
		}
	}
	else if(interpolationFactor==1.0f)
	{
		int frame2TimesNumVerts=frame2*numVertices;
		
		for(int i=0; i<numVertices; ++i)
		{
			frameVertices[i]=
				vertices[frame2TimesNumVerts+i].GetModelTransformed(instancePosition,
																	instanceAngleYaw);
		}
	}
	else
	{
		int frame1TimesNumVerts=frame1*numVertices;
		int frame2TimesNumVerts=frame2*numVertices;

		for(int i=0; i<numVertices; ++i)
		{
			frameVertices[i]=
				vertices[frame1TimesNumVerts+i].Lerp(vertices[frame2TimesNumVerts+i],
													interpolationFactor)
														.GetModelTransformed(	instancePosition,
																				instanceAngleYaw);
		}
	}

	//Send the frame vertices
	RENDER_MANAGER::Instance()->UpdateGeometryVertices(	firstVertexIndex,
														numVertices,
														frameVertices);
}
