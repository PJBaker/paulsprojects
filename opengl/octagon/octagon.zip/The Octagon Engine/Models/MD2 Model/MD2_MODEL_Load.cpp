//////////////////////////////////////////////////////////////////////////////////////////
//	MD2_MODEL_Load.cpp
//	Load md2 model data
//	Downloaded from: www.paulsprojects.net
//	Created:	16th December 2002
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <vector>
#include "../../GL files/glee.h"
#include "../../Maths/Maths.h"
#include "../../Log/LOG.h"
#include "../../Bounding Volumes/Bounding Volumes.h"
#include "../../Render Manager/RENDER_MANAGER.h"
#include "../../Console/CONSOLE.h"
#include "../MODEL_MANAGER.h"

bool MD2_MODEL::Load()
{
	FILE * file;

	//open the file
	file=fopen(filename, "rb");
	if(!file)
	{
		LOG::Instance()->OutputError("Unable to open %s", filename);
		return false;
	}

	//read in the header
	fread(&header, sizeof(MD2_HEADER), 1, file);

	//Check header is correct
	if(strncmp(header.string, "IDP2", 4)!=0 || header.version!=8)
	{
		LOG::Instance()->OutputError("%s is not a valid version 8 md2 file", filename);
		return false;
	}

	//Calculate the texture filename
	char textureFilename[128];
	strncpy(textureFilename, filename, strlen(filename)-4);
	textureFilename[strlen(filename)-4]='\0';

	//Load the texture
	int tempTextureIndex=RENDER_MANAGER::Instance()->CreateGeometryTexture(textureFilename);

	//Ensure the texture was loaded correctly
	if(tempTextureIndex==-1)
		return false;

	//Add this to the list of textures
	surfaceTextureIndices.push_back(tempTextureIndex);

	//Create the index list
	LIST <unsigned int> tempList;
	indexLists.push_back(tempList);
		
	//Load the vertices
	if(!LoadVertices(file))
		return false;

	//Load the texCoords
	if(!LoadTexCoords(file))
		return false;

	//Load the triangles and assemble the model
	if(!LoadTriangles(file))
		return false;

	fclose(file);

	//Delete temporary data
	if(tempVertices)
		delete [] tempVertices;
	tempVertices=NULL;

	if(tempTexCoords)
		delete [] tempTexCoords;
	tempTexCoords=NULL;


	//Create space for the frameVertices
	frameVertices=new GEOMETRY_VERTEX[numVertices];
	if(!frameVertices)
	{
		LOG::Instance()->OutputError("Unable to allocate space for %d GEOMETRY_VERTEXes",
										numVertices);
		return false;
	}

	numTriangles=indexLists[0].GetSize()/3;

	//Calculate connectivity
	if(!CalculateNeighbours())
		return false;

	return true;
}