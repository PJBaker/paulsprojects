//////////////////////////////////////////////////////////////////////////////////////////
//	MD2_MODEL.h
//	Class for the data from a md2 file. Derives from MODEL
//	Downloaded from: www.paulsprojects.net
//	Created:	17th December 2002
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	

#ifndef MD2_MODEL_H
#define MD2_MODEL_H

#include "MD2_HEADER.h"

#include "MD2_LOAD_VERTEX.h"
#include "MD2_LOAD_FRAME.h"
#include "MD2_LOAD_TEXCOORDS.h"
#include "MD2_LOAD_TRIANGLE.h"

class MD2_MODEL : public MODEL
{
public:
	virtual bool Load();

	virtual int SendVertices(	const VECTOR3D & instancePosition,
								float instanceAngleYaw);

	virtual void UpdateVertices(	ANIM_SEQUENCE animSequence,
									float distanceThroughAnimSequence,
									int firstVertexIndex,
									const VECTOR3D & instancePosition,
									float instanceAngleYaw);

	MD2_HEADER header;

	int numFrames;
	GEOMETRY_VERTEX * vertices;	//vertices for all frames


	//Vertices for a single frame
	GEOMETRY_VERTEX * frameVertices;
	
	//Temporary arrays used in loading
	VECTOR3D * tempVertices;
	bool LoadVertices(FILE * file);

	MD2_LOAD_TEXCOORDS * tempTexCoords;
	bool LoadTexCoords(FILE * file);

	bool LoadTriangles(FILE * file);

	MD2_MODEL()	:	vertices(NULL), frameVertices(NULL), tempVertices(NULL), tempTexCoords(NULL)
	{}
	~MD2_MODEL()
	{
		if(vertices)
			delete [] vertices;
		vertices=NULL;

		if(frameVertices)
			delete [] frameVertices;
		frameVertices=NULL;

		if(tempVertices)
			delete [] tempVertices;
		tempVertices=NULL;

		if(tempTexCoords)
			delete [] tempTexCoords;
		tempTexCoords=NULL;
	}
};

//frame numbers for start/end of animation sequences
//idle
const int MD2_ANIMSEQ_IDLE_STARTFRAME	=	0;
const int MD2_ANIMSEQ_IDLE_ENDFRAME		=	39;
const int MD2_ANIMSEQ_RUN_STARTFRAME	=	40;
const int MD2_ANIMSEQ_RUN_ENDFRAME		=	45;

#endif	//MD2_MODEL_H