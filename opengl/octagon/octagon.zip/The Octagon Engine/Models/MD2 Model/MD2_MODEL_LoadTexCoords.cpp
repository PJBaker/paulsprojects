//////////////////////////////////////////////////////////////////////////////////////////
//	MD2_MODEL_LoadTexCoords.cpp
//	Load md2 model texture coords
//	Downloaded from: www.paulsprojects.net
//	Created:	16th December 2002
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <vector>
#include "../../GL files/glee.h"
#include "../../Maths/Maths.h"
#include "../../Log/LOG.h"
#include "../../Bounding Volumes/Bounding Volumes.h"
#include "../../Render Manager/RENDER_MANAGER.h"
#include "../../Console/CONSOLE.h"
#include "../MODEL_MANAGER.h"

bool MD2_MODEL::LoadTexCoords(FILE * file)
{
	int numST=header.numST;

	//Create space for tempTexCoords
	tempTexCoords=new MD2_LOAD_TEXCOORDS[numST];
	if(!tempTexCoords)
	{
		LOG::Instance()->OutputError("Unable to allocate space for %d MD2_LOAD_TEXCOORDSs",
										numST);
		return false;
	}

	//Load the texture coords
	fseek(file, header.offsetST, SEEK_SET);
	fread(tempTexCoords, numST, sizeof(MD2_LOAD_TEXCOORDS), file);
	
	return true;
}