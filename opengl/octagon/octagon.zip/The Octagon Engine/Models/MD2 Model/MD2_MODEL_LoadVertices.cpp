//////////////////////////////////////////////////////////////////////////////////////////
//	MD2_MODEL_LoadVertices.cpp
//	Load md2 model vertices
//	Downloaded from: www.paulsprojects.net
//	Created:	16th December 2002
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <vector>
#include "../../GL files/glee.h"
#include "../../Maths/Maths.h"
#include "../../Log/LOG.h"
#include "../../Bounding Volumes/Bounding Volumes.h"
#include "../../Render Manager/RENDER_MANAGER.h"
#include "../../Console/CONSOLE.h"
#include "../MODEL_MANAGER.h"

bool MD2_MODEL::LoadVertices(FILE * file)
{
	numFrames=header.numFrames;
	int numVertices=header.numVertices;

	//Create space for MD2_LOAD_VERTEXes for all frames
	tempVertices=new VECTOR3D[numVertices*numFrames];
	if(!tempVertices)
	{
		LOG::Instance()->OutputError("Unable to allocate space for %d vertex positions",
										numVertices*numFrames);
		return false;
	}

	//Create a buffer to hold the data for one frame
	unsigned char * frameBuffer=new unsigned char[header.frameSize];
	if(!frameBuffer)
	{
		LOG::Instance()->OutputError("Unable to allocate space to hold one frameof %d bytes",
										header.frameSize);
		return false;
	}

	//Loop through frames
	for(int i=0; i<numFrames; ++i)
	{
		//Load this frame into the buffer
		fseek(file, header.offsetFrames+i*header.frameSize, SEEK_SET);
		fread(frameBuffer, header.frameSize, 1, file);

		//Create a pointer to the frame
		MD2_LOAD_FRAME * framePtr=(MD2_LOAD_FRAME *) frameBuffer;

		//Loop through and fill in the vertices, converting coordinate systems
		for(int j=0; j<numVertices; ++j)
		{
			tempVertices[i*numVertices+j].x= float(	framePtr->scale[0] * 
													framePtr->vertices[j].position[0] +
													framePtr->translation[0]);
			tempVertices[i*numVertices+j].y= float(	framePtr->scale[2] * 
													framePtr->vertices[j].position[2] +
													framePtr->translation[2]);
			tempVertices[i*numVertices+j].z=-float(	framePtr->scale[1] * 
													framePtr->vertices[j].position[1] +
													framePtr->translation[1]);
			tempVertices[i*numVertices+j]/=64;
		}
	}

	//Find the minimum Y coordinate of the first frame
	float minY=999999.0f;
	for(int i=0; i<numVertices; ++i)
	{
		if(tempVertices[i].y<minY)
			minY=tempVertices[i].y;
	}

	//Subtract this from the y coord of every vertex
	//This moves the origin to floor level
	for(int i=0; i<numFrames*numVertices; ++i)
		tempVertices[i].y-=minY;

	//Free temporary memory
	if(frameBuffer)
		delete [] frameBuffer;
	frameBuffer=NULL;

	return true;
}