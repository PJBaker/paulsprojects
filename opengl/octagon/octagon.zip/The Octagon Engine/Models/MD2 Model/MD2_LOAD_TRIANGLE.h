//////////////////////////////////////////////////////////////////////////////////////////
//	MD2_LOAD_TRIANGLE.h
//	Class for a triangle as found in an md2 file
//	Downloaded from: www.paulsprojects.net
//	Created:	18th December 2002
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	

#ifndef MD2_LOAD_TRIANGLE_H
#define MD2_LOAD_TRIANGLE_H

class MD2_LOAD_TRIANGLE
{
public:
	unsigned short vertexIndices[3];
	unsigned short stIndices[3];
};

//Helper class used during loading
class MD2_INDEX_PAIR
{
public:
	unsigned short vertexIndex;
	unsigned short stIndex;

	bool operator==(MD2_INDEX_PAIR rhs)
	{	return (vertexIndex==rhs.vertexIndex && stIndex==rhs.stIndex);	}
};

#endif	//MD2_LOAD_TRIANGLE_H