//////////////////////////////////////////////////////////////////////////////////////////
//	MD2_HEADER.h
//	Class for the header of an md2 file
//	Downloaded from: www.paulsprojects.net
//	Created:	18th December 2002
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	

#ifndef MD2_HEADER_H
#define MD2_HEADER_H

class MD2_HEADER
{
public:
	char string[4];		//"IDP2"
	int version;		//8
	int skinWidth, skinHeight;
	int frameSize;		//bytes per frame
	int numSkins;		//num textures
	int numVertices;
	int numST;			//number of texture coord sets
	int numTriangles;
	int numGLCommands;	//number of GL commands
	int numFrames;		//number of frames

	//offsets in file
	int offsetSkins;
	int offsetST;
	int offsetTris;
	int offsetFrames;
	int offsetGLCommands;
	int offsetEnd;
};

#endif	//MD2_HEADER_H