//////////////////////////////////////////////////////////////////////////////////////////
//	Models/CreateModel.cpp
//	return the ID of an instance of MODEL, creating it if necessary. -1 if error
//	Downloaded from: www.paulsprojects.net
//	Created:	16th December 2002
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <vector>
#include "../GL files/glee.h"
#include "../Maths/Maths.h"
#include "../Log/LOG.h"
#include "../Bounding Volumes/Bounding Volumes.h"
#include "../Render Manager/RENDER_MANAGER.h"
#include "../Console/CONSOLE.h"
#include "MODEL_MANAGER.h"

int MODEL_MANAGER::CreateModel(char * filename)
{
	//See if this MODEL has already been loaded.
	//If so, return its ID
	for(std::size_t i=0; i<models.size(); ++i)
	{
		if(strcmp(filename, models[i]->filename)==0)
			return i;
	}

	MODEL * newModel;

	//See which type of model data we need to create, and create it
	int filenameLength=strlen(filename);

	if(	strncmp(filename+filenameLength-3, "MD2", 3)==0 ||
		strncmp(filename+filenameLength-3, "md2", 3)==0)
	{
		newModel=new MD2_MODEL;
	}
	else if(strncmp(filename+filenameLength-3, "MD3", 3)==0 ||
			strncmp(filename+filenameLength-3, "md3", 3)==0)
	{
		newModel=new MD3_MODEL;
	}
	else
	{
		LOG::Instance()->OutputError("%s is of an unsupported model file format", filename);
		return -1;
	}

	//Check the new data was created correctly
	if(!newModel)
	{
		LOG::Instance()->OutputError("Unable to create space for data from %s", filename);
		return -1;
	}
	
	//Save the filename into the new model data
	strcpy(newModel->filename, filename);
	
	//Load the new model data
	if(!newModel->Load())
		return -1;

	//Save the new data into the vector
	models.push_back(newModel);

	//return the ID
	return models.size()-1;
}