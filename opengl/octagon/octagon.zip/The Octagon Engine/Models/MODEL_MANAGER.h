//////////////////////////////////////////////////////////////////////////////////////////
//	MODEL_MANAGER.h
//	Manage the MODEL objects
//	Downloaded from: www.paulsprojects.net
//	Created:	17th December 2002
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	

#ifndef MODEL_MANAGER_H
#define MODEL_MANAGER_H

#include <vector>
#include "MODEL.h"
#include "MD2 Model/MD2_MODEL.h"
#include "MD3 Model/MD3_MODEL.h"

class MODEL_MANAGER
{
protected:
	//protected constructor & copy constructor to prevent >1 instances
	MODEL_MANAGER()
	{}
	MODEL_MANAGER(const MODEL_MANAGER &)
	{}
	MODEL_MANAGER & operator=(const MODEL_MANAGER &)
	{}

public:
	//public function to access the instance
	static MODEL_MANAGER * Instance()
	{
		static MODEL_MANAGER instance;	//our sole instance
		return &instance;
	}

	//Send vertices for a given model
	int SendVertices(	unsigned int modelIndex,
						const VECTOR3D & instancePosition,
						float instanceAngleYaw)
	{	
		if(modelIndex<models.size())
			return models[modelIndex]->SendVertices(instancePosition, instanceAngleYaw);
		return 0;
	}

	int GetNumVertices(unsigned int modelIndex)
	{
		if(modelIndex<models.size())
			return models[modelIndex]->numVertices;
		return 0;
	}

	int GetNumTriangles(unsigned int modelIndex)
	{
		if(modelIndex<models.size())
			return models[modelIndex]->numTriangles;
		return 0;
	}

	//Send indices for a given model starting at a given place
	void SendIndices(unsigned int modelIndex, int firstVertexIndex)
	{	
		if(modelIndex<models.size())
			models[modelIndex]->SendIndices(firstVertexIndex);
	}

	void SendShadowVolumeIndices(	bool zFailRequired,
									const VECTOR3D & lightPosition,
									unsigned int modelIndex,
									int firstVertexIndex,
									PLANE * planeEquations)
	{	
		if(modelIndex<models.size())
			models[modelIndex]->SendShadowVolumeIndices(zFailRequired,
														lightPosition,
														firstVertexIndex,
														planeEquations);
	}

	//Update vertices for a given model
	void UpdateVertices(unsigned int modelIndex, ANIM_SEQUENCE animSequence,
						float distanceThroughAnimSequence, int firstVertexIndex,
						const VECTOR3D position, float angleYaw)
	{	
		if(modelIndex<models.size())
			models[modelIndex]->UpdateVertices(	animSequence, distanceThroughAnimSequence,
												firstVertexIndex, position, angleYaw);
	}

	//Get the plane equations for each triangle in a given model
	void GetPlaneEquations( unsigned int modelIndex, int firstVertexIndex,
							PLANE * planes)
	{
		if(modelIndex<models.size())
			models[modelIndex]->FillPlaneEquations(firstVertexIndex, planes);
	}


//Model data
public:
	//return the ID of an instance of MODEL, creating it if necessary. -1 if error
	int CreateModel(char * filename);

protected:
	//vector of MODELs
	std::vector <MODEL *> models;
};

#endif	//MODEL_MANAGER_H