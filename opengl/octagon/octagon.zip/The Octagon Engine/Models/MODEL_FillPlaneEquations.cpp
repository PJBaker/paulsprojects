//////////////////////////////////////////////////////////////////////////////////////////
//	MODEL_FillPlaneEquations.cpp
//	Fill a given array with the plane equations for a given frame
//	Downloaded from: www.paulsprojects.net
//	Created:	16th December 2002
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <vector>
#include "../GL files/glee.h"
#include "../Maths/Maths.h"
#include "../Log/LOG.h"
#include "../Bounding Volumes/Bounding Volumes.h"
#include "../Render Manager/RENDER_MANAGER.h"
#include "../Console/CONSOLE.h"
#include "MODEL_MANAGER.h"

void MODEL::FillPlaneEquations(int firstVertexIndex, PLANE * planes)
{
	int faceIndex=0;

	for(std::size_t i=0; i<surfaceTextureIndices.size(); ++i)
	{
		for(int j=0; j<indexLists[i].GetSize(); j+=3)
		{
			//Get the vertex indices for this triangle
			unsigned int indices[3];
			indices[0]=firstVertexIndex+indexLists[i].entries[j+0];
			indices[1]=firstVertexIndex+indexLists[i].entries[j+1];
			indices[2]=firstVertexIndex+indexLists[i].entries[j+2];

			//Get the vertices making up this triangle
			GEOMETRY_VERTEX & vertex0=RENDER_MANAGER::Instance()->GetGeometryVertex(indices[0]);
			GEOMETRY_VERTEX & vertex1=RENDER_MANAGER::Instance()->GetGeometryVertex(indices[1]);
			GEOMETRY_VERTEX & vertex2=RENDER_MANAGER::Instance()->GetGeometryVertex(indices[2]);

			//Save the plane equation for this triangle
			planes[faceIndex].
							SetFromPoints(vertex0.position, vertex1.position, vertex2.position);

			++faceIndex;
		}
	}
}