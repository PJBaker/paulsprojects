//////////////////////////////////////////////////////////////////////////////////////////
//	MD3_MODEL_UpdateVertices.cpp
//	Update vertices in the render manager for md3 model data
//	Downloaded from: www.paulsprojects.net
//	Created:	28th December 2002
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <vector>
#include "../../GL files/glee.h"
#include "../../Maths/Maths.h"
#include "../../Log/LOG.h"
#include "../../Bounding Volumes/Bounding Volumes.h"
#include "../../Render Manager/RENDER_MANAGER.h"
#include "../../Console/CONSOLE.h"
#include "../MODEL_MANAGER.h"

void MD3_MODEL::UpdateVertices(	ANIM_SEQUENCE animSequence,
								float distanceThroughAnimSequence,
								int firstVertexIndex,
								const VECTOR3D & instancePosition,
								float instanceAngleYaw)
{
	//Empty, since MD3 animation is not (yet) supported
}
