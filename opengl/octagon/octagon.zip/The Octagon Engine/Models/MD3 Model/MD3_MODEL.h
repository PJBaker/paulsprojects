//////////////////////////////////////////////////////////////////////////////////////////
//	MD3_MODEL.h
//	Class for the data from a md3 file. Derives from MODEL
//	Downloaded from: www.paulsprojects.net
//	Created:	29th December 2002
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	

#ifndef MD3_MODEL_H
#define MD3_MODEL_H

#include "MD3_HEADER.h"

#include "MD3_SURFACE_HEADER.h"

class MD3_MODEL : public MODEL
{
public:
	virtual bool Load();

	virtual int SendVertices(	const VECTOR3D & instancePosition,
								float instanceAngleYaw);

	virtual void UpdateVertices(ANIM_SEQUENCE animSequence,
								float distanceThroughAnimSequence,
								int firstVertexIndex,
								const VECTOR3D & instancePosition,
								float instanceAngleYaw);

protected:
	MD3_HEADER header;

	bool LoadSurfaces(FILE * file);

	std::vector <GEOMETRY_VERTEX> vertices;
};

#endif	//MD3_MODEL_H