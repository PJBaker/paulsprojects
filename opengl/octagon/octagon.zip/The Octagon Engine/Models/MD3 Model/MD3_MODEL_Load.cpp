//////////////////////////////////////////////////////////////////////////////////////////
//	MD3_MODEL_Load.cpp
//	Load md3 model data
//	Downloaded from: www.paulsprojects.net
//	Created:	30th December 2002
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <vector>
#include "../../GL files/glee.h"
#include "../../Maths/Maths.h"
#include "../../Log/LOG.h"
#include "../../Bounding Volumes/Bounding Volumes.h"
#include "../../Render Manager/RENDER_MANAGER.h"
#include "../../Console/CONSOLE.h"
#include "../MODEL_MANAGER.h"

bool MD3_MODEL::Load()
{
	FILE * file;

	//open the file
	file=fopen(filename, "rb");
	if(!file)
	{
		LOG::Instance()->OutputError("Unable to open %s", filename);
		return false;
	}

	//read in the header
	fread(&header, sizeof(MD3_HEADER), 1, file);

	//Check header is correct
	if(strncmp(header.string, "IDP3", 4)!=0 || header.version!=15)
	{
		LOG::Instance()->OutputError("%s is not a valid version 15 md3 file", filename);
		return false;
	}

	//Load surfaces
	if(!LoadSurfaces(file))
		return false;

	//Calculate total number of triangles
	numTriangles=0;
	for(std::size_t i=0; i<indexLists.size(); ++i)
		numTriangles+=indexLists[i].GetSize();

	//Calculate the TSB for each triangle and add to the vertices
	VECTOR3D normal, sTangent, tTangent;
	for(std::size_t i=0; i<indexLists.size(); ++i)
	{
		for(int j=0; j<indexLists[i].GetSize(); j+=3)
		{
			RENDER_MANAGER::Instance()->CalculateTSB(	
										vertices[indexLists[i].entries[j+0]],
										vertices[indexLists[i].entries[j+1]],
										vertices[indexLists[i].entries[j+2]],
										normal, sTangent, tTangent);

			//Add this to the vertices
			for(int k=0; k<3; ++k)
			{
				vertices[indexLists[i].entries[j+k]].normal+=normal;
				vertices[indexLists[i].entries[j+k]].sTangent+=sTangent;
				vertices[indexLists[i].entries[j+k]].tTangent+=tTangent;
			}
		}
	}

	//Normalise TSBs
	for(int i=0; i<numVertices; ++i)
	{
		vertices[i].normal.Normalize();
		vertices[i].sTangent.Normalize();
		vertices[i].tTangent.Normalize();
	}


	//Find the minimum Y coordinate
	float minY=999999.0f;
	for(int i=0; i<numVertices; ++i)
	{
		if(vertices[i].position.y<minY)
			minY=vertices[i].position.y;
	}

	//Subtract this from the y coord of every vertex
	//This moves the origin to floor level
	for(int i=0; i<numVertices; ++i)
		vertices[i].position.y-=minY;

	//Calculate connectivity
	CalculateNeighbours();


	fclose(file);

	return true;
}
