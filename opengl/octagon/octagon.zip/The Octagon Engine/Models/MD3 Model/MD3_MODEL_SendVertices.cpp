//////////////////////////////////////////////////////////////////////////////////////////
//	MD3_MODEL_SendVertices.cpp
//	Send vertices to the render manager for md3 model data
//	Downloaded from: www.paulsprojects.net
//	Created:	30th December 2002
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <vector>
#include "../../GL files/glee.h"
#include "../../Maths/Maths.h"
#include "../../Log/LOG.h"
#include "../../Bounding Volumes/Bounding Volumes.h"
#include "../../Render Manager/RENDER_MANAGER.h"
#include "../../Console/CONSOLE.h"
#include "../MODEL_MANAGER.h"

int MD3_MODEL::SendVertices(const VECTOR3D & instancePosition, float instanceAngleYaw)
{
	int firstVertexIndex=RENDER_MANAGER::Instance()->AddTempGeometryVertex(
							vertices[0].GetModelTransformed(instancePosition, instanceAngleYaw));

	for(int j=1; j<numVertices; ++j)
		RENDER_MANAGER::Instance()->AddTempGeometryVertex(
							vertices[j].GetModelTransformed(instancePosition, instanceAngleYaw));

	return firstVertexIndex;
}