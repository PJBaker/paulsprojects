//////////////////////////////////////////////////////////////////////////////////////////
//	MD3_SURFACE_HEADER.h
//	Class for the header of each surface in an md3 file
//	Downloaded from: www.paulsprojects.net
//	Created:	30th December 2002
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	

#ifndef MD3_SURFACE_HEADER_H
#define MD3_SURFACE_HEADER_H

class MD3_SURFACE_HEADER
{
public:
	char string[4];		//"IDP3"
	char name[64];

	int flags;

	int numFrames;
	int numShaders;
	int numVertices;
	int numTriangles;

	int offsetTriangles;
	int offsetShaders;
	int offsetST;
	int offsetVertices;
	int offsetEnd;
};

#endif	//MD3_HEADER_H