//////////////////////////////////////////////////////////////////////////////////////////
//	MD3_MODEL_LoadSurfaces.cpp
//	Load the surfaces from an md3 model file
//	Downloaded from: www.paulsprojects.net
//	Created:	30th December 2002
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <vector>
#include "../../GL files/glee.h"
#include "../../Maths/Maths.h"
#include "../../Log/LOG.h"
#include "../../Bounding Volumes/Bounding Volumes.h"
#include "../../Render Manager/RENDER_MANAGER.h"
#include "../../Console/CONSOLE.h"
#include "../MODEL_MANAGER.h"

bool MD3_MODEL::LoadSurfaces(FILE * file)
{
	//Loop through surfaces
	for(int currentSurface=0; currentSurface<header.numSurfaces; ++currentSurface)
	{
		MD3_SURFACE_HEADER surfaceHeader;

		//Get the offset of the start of the surface
		int surfaceStartOffset=header.offsetSurfaces;

		for(int i=0; i<currentSurface; ++i)
		{
			//Point "file" at the start of this surface
			fseek(file, surfaceStartOffset, SEEK_SET);

			//read in the surface header
			fread(&surfaceHeader, sizeof(MD3_SURFACE_HEADER), 1, file);

			//Add the length of this surface to the surfaceStartOffset
			surfaceStartOffset+=surfaceHeader.offsetEnd;
		}

		//Point "file" at the start of the surface to read
		fseek(file, surfaceStartOffset, SEEK_SET);

		//Read in the surface header
		fread(&surfaceHeader, sizeof(MD3_SURFACE_HEADER), 1, file);

		//Check surface header is correct
		if(strncmp(surfaceHeader.string, "IDP3", 4)!=0)
		{
			LOG::Instance()->OutputError("This file contains an invalid surface");
			return false;
		}

		//Go to the shader section of this surface and read in the texture filename
		char textureFilename[64];
		fseek(file, surfaceStartOffset+surfaceHeader.offsetShaders, SEEK_SET);
		fread(textureFilename, 64, 1, file);

		//Remove the extension from the texture filename and add "data/" to the front
		char textureFilenameWithoutExtension[64];
		strncpy(textureFilenameWithoutExtension, textureFilename, strlen(textureFilename)-4);
		textureFilenameWithoutExtension[strlen(textureFilename)-4]='\0';

		char alteredTextureFilename[128];
		strcpy(alteredTextureFilename, "data/");
		strcat(alteredTextureFilename, textureFilenameWithoutExtension);

		//Load the texture
		int surfaceTextureIndex=RENDER_MANAGER::Instance()->
													CreateGeometryTexture(alteredTextureFilename);

		//Skip this surface if the texture was not loaded
		if(surfaceTextureIndex==-1)
			continue;

		//Save the surfaceTextureIndex into the vector
		surfaceTextureIndices.push_back(surfaceTextureIndex);

		
		//Load the vertex positions
		short * tempVertexPositions=new short[surfaceHeader.numVertices*4];
		if(!tempVertexPositions)
		{
			LOG::Instance()->OutputError("Unable to allocate space for %d shorts",
											surfaceHeader.numVertices*4);
			return false;
		}

		fseek(file, surfaceStartOffset+surfaceHeader.offsetVertices, SEEK_SET);
		fread(tempVertexPositions, surfaceHeader.numVertices*4, sizeof(short), file);

		//Load the texture coordinates
		VECTOR2D * tempTextureCoords=new VECTOR2D[surfaceHeader.numVertices];
		if(!tempTextureCoords)
		{
			LOG::Instance()->OutputError("Unable to allocate space for %d VECTOR2Ds",
											surfaceHeader.numVertices);
			return false;
		}

		fseek(file, surfaceStartOffset+surfaceHeader.offsetST, SEEK_SET);
		fread(tempTextureCoords, surfaceHeader.numVertices, sizeof(VECTOR2D), file);

		//Assemble geometry vertices from the above
		GEOMETRY_VERTEX * tempGeometryVertices=new GEOMETRY_VERTEX[surfaceHeader.numVertices];
		if(!tempGeometryVertices)
		{
			LOG::Instance()->OutputError("Unable to allocate space for %d GEOMETRY_VERTEXes",
											surfaceHeader.numVertices);
			return false;
		}

		for(int i=0; i<surfaceHeader.numVertices; ++i)
		{
			//Convert coordinate system
			tempGeometryVertices[i].position.x	= (float)tempVertexPositions[i*4+0]/4096;
			tempGeometryVertices[i].position.y	= (float)tempVertexPositions[i*4+2]/4096;
			tempGeometryVertices[i].position.z	=-(float)tempVertexPositions[i*4+1]/4096;
			tempGeometryVertices[i].texCoords.x	= tempTextureCoords[i].x;
			tempGeometryVertices[i].texCoords.y	=-tempTextureCoords[i].y;
		}


		//Load the indices
		unsigned int * tempIndices=new unsigned int[surfaceHeader.numTriangles*3];
		if(!tempIndices)
		{
			LOG::Instance()->OutputError("Unable to create space for %d indices",
											surfaceHeader.numTriangles*3);
			return false;
		}
	
		fseek(file, surfaceStartOffset+surfaceHeader.offsetTriangles, SEEK_SET);
		fread(tempIndices, surfaceHeader.numTriangles*3, sizeof(unsigned int), file);

		//Swap the order of the indices
		for(int i=0; i<surfaceHeader.numTriangles; ++i)
		{
			unsigned int temp=tempIndices[i*3+1];
			tempIndices[i*3+1]=tempIndices[i*3+2];
			tempIndices[i*3+2]=temp;
		}


		//Add the vertices to the model's vector. Save the position of the first vetex of this surface
		numVertices+=surfaceHeader.numVertices;
	
		int firstVertexIndex=vertices.size();

		for(int i=0; i<surfaceHeader.numVertices; ++i)
			vertices.push_back(tempGeometryVertices[i]);


		//Add a vector of indices for this texture, and fill it
		LIST <unsigned int> indices;
		indices.AddElementsEx(surfaceHeader.numTriangles*3, tempIndices, false, firstVertexIndex);

		indexLists.push_back(indices);

		//Free temporary memory
		if(tempVertexPositions)
			delete [] tempVertexPositions;
		tempVertexPositions=NULL;

		if(tempTextureCoords)
			delete [] tempTextureCoords;
		tempTextureCoords=NULL;

		if(tempGeometryVertices)
			delete [] tempGeometryVertices;
		tempGeometryVertices=NULL;

		if(tempIndices)
			delete [] tempIndices;
		tempIndices=NULL;
	}
	
	return true;
}