//////////////////////////////////////////////////////////////////////////////////////////
//	MODEL_CalculateNeighbours.cpp
//	Calculate the connectivity information for a model
//	Downloaded from: www.paulsprojects.net
//	Created:	31st December 2002
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <vector>
#include "../GL files/glee.h"
#include "../Maths/Maths.h"
#include "../Log/LOG.h"
#include "../Bounding Volumes/Bounding Volumes.h"
#include "../Render Manager/RENDER_MANAGER.h"
#include "../Console/CONSOLE.h"
#include "MODEL_MANAGER.h"

bool MODEL::CalculateNeighbours()
{
	//Create space for shadow data
	neighbourIndices=new int[numTriangles*3];
	isFacing=new bool[numTriangles];
	if(!neighbourIndices || !isFacing)
	{
		LOG::Instance()->OutputError("Unable to allocate space for shadow information for %s",
										filename);
		return false;
	}

	//Set all neighbour indices to be -1
	for(int i=0; i<numTriangles*3; ++i)
		neighbourIndices[i]=-1;

	int faceIndexJ=0;
	for(std::size_t i=0; i<surfaceTextureIndices.size(); ++i)
	{
		for(int j=0; j<indexLists[i].GetSize(); j+=3, ++faceIndexJ)
		{
			//Loop through edges on this triangle
			for(int edgeJ=0; edgeJ<3; ++edgeJ)
			{
				//Continue if this edge already has a neighbour set
				if(neighbourIndices[faceIndexJ*3+edgeJ]!=-1)
					continue;
				
				//Loop through triangles with a greater index than this one, with the same texture
				for(int k=j+3, faceIndexK=faceIndexJ+1;
					k<indexLists[i].GetSize();
					k+=3, ++faceIndexK)
				{
					//Loop through edges on this triangle
					for(int edgeK=0; edgeK<3; ++edgeK)
					{
						//Get the vertex indices on each edge
						int edgeJ1=indexLists[i].entries[j+edgeJ];
						int edgeJ2=indexLists[i].entries[j+(edgeJ+1)%3];
						
						int edgeK1=indexLists[i].entries[k+edgeK];
						int edgeK2=indexLists[i].entries[k+(edgeK+1)%3];
						

						//If these are the same (possibly reversed order), faces are neighbours
						if(	(edgeJ1==edgeK1 && edgeJ2==edgeK2) ||
							(edgeJ1==edgeK2 && edgeJ2==edgeK1))
						{
							neighbourIndices[faceIndexJ*3+edgeJ]=faceIndexK;
							neighbourIndices[faceIndexK*3+edgeK]=faceIndexJ;
						}
					}
				}
			}
		}
	}

	return true;
}
			