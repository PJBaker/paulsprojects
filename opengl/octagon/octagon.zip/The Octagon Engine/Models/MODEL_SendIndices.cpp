//////////////////////////////////////////////////////////////////////////////////////////
//	MODEL_SendIndices.cpp
//	Send indices to the model manager for a model
//	Downloaded from: www.paulsprojects.net
//	Created:	16th December 2002
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <vector>
#include "../GL files/glee.h"
#include "../Maths/Maths.h"
#include "../Log/LOG.h"
#include "../Bounding Volumes/Bounding Volumes.h"
#include "../Render Manager/RENDER_MANAGER.h"
#include "../Console/CONSOLE.h"
#include "MODEL_MANAGER.h"

void MODEL::SendIndices(int firstVertexIndex)
{
	for(std::size_t i=0; i<surfaceTextureIndices.size(); ++i)
	{
		RENDER_MANAGER::Instance()->AddGeometryElementsEx(	surfaceTextureIndices[i],
															false,
															firstVertexIndex,
															indexLists[i].GetSize(),
															indexLists[i].entries);
	}
}
