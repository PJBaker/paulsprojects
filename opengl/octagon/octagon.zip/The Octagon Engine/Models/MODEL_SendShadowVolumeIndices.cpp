//////////////////////////////////////////////////////////////////////////////////////////
//	MODEL_SendShadowVolumeIndices.cpp
//	Send indices to the model manager for a model
//	Downloaded from: www.paulsprojects.net
//	Created:	16th December 2002
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <vector>
#include "../GL files/glee.h"
#include "../Maths/Maths.h"
#include "../Log/LOG.h"
#include "../Bounding Volumes/Bounding Volumes.h"
#include "../Render Manager/RENDER_MANAGER.h"
#include "../Console/CONSOLE.h"
#include "MODEL_MANAGER.h"

void MODEL::SendShadowVolumeIndices(bool zFailRequired, 
									const VECTOR3D & lightPosition,
									int firstVertexIndex,
									PLANE * planeEquations)
{
	//Calculate which faces are facing the light
	int faceIndex=0;
	for(std::size_t i=0; i<surfaceTextureIndices.size(); ++i)
	{
		for(int j=0; j<indexLists[i].GetSize(); j+=3)
		{
			isFacing[faceIndex]=(planeEquations[faceIndex].ClassifyPoint(lightPosition)==
																		POINT_IN_FRONT_OF_PLANE);
			++faceIndex;
		}
	}

	//send indices
	faceIndex=0;
	for(std::size_t i=0; i<surfaceTextureIndices.size(); ++i)
	{
		for(int j=0; j<indexLists[i].GetSize(); j+=3, ++faceIndex)
		{
			if(!isFacing[faceIndex])
				continue;
		
			//Get the vertex indices for this triangle
			unsigned int indices[3];
			indices[0]=firstVertexIndex+indexLists[i].entries[j+0];
			indices[1]=firstVertexIndex+indexLists[i].entries[j+1];
			indices[2]=firstVertexIndex+indexLists[i].entries[j+2];

		//Send the vertices as caps if using zFail
			if(zFailRequired)
				RENDER_MANAGER::Instance()->AddShadowVolumeCaps(3, indices);

			//Send the edges if they are silhouette edges
			int neighbourIndex=neighbourIndices[faceIndex*3+0];
			if(neighbourIndex==-1 || !isFacing[neighbourIndex])
				RENDER_MANAGER::Instance()->AddShadowVolumeEdge(zFailRequired, indices[0], indices[1]);

			neighbourIndex=neighbourIndices[faceIndex*3+1];
			if(neighbourIndex==-1 || !isFacing[neighbourIndex])
				RENDER_MANAGER::Instance()->AddShadowVolumeEdge(zFailRequired, indices[1], indices[2]);
			
			neighbourIndex=neighbourIndices[faceIndex*3+2];
			if(neighbourIndex==-1 || !isFacing[neighbourIndex])
				RENDER_MANAGER::Instance()->AddShadowVolumeEdge(zFailRequired, indices[2], indices[0]);
		}
	}
}