//////////////////////////////////////////////////////////////////////////////////////////
//	DrawLoadingScreen.cpp
//	Draw a simple screen to be displayed while loading
//	Downloaded from: www.paulsprojects.net
//	Created:	18th December 2002
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include "GL files/glee.h"			//header for OpenGL 1.4
#include "Maths/Maths.h"
#include "Window/WINDOW.h"
#include "Bitmap Font/BITMAP_FONT.h"
#include "DrawLoadingScreen.h"

extern BITMAP_FONT font;

void DrawLoadingScreen()
{
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	font.StartTextMode();
	
	glColor4fv(red);
	font.Print(WINDOW::Instance()->width/2-50, WINDOW::Instance()->height/2, "Loading");
	
	font.EndTextMode();

	glColor4fv(white);

	WINDOW::Instance()->SwapBuffers();
}