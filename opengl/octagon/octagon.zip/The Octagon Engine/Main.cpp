//////////////////////////////////////////////////////////////////////////////////////////
//	Main.cpp
//	The Octagon Engine
//	Downloaded from: www.paulsprojects.net
//	Created:	8th December 2002
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <vector>
#include "GL files/glee.h"			//header for OpenGL 1.4
#include <GL/glu.h>
#include "Maths/Maths.h"
#include "Log/LOG.h"
#include "Timer/TIMER.h"
#include "Fps Counter/FPS_COUNTER.h"
#include "Window/WINDOW.h"
#include "Bitmap Font/BITMAP_FONT.h"
#include "Image/IMAGE.h"
#include "Bitset/BITSET.h"
#include "Bounding Volumes/Bounding Volumes.h"
#include "List/LIST.h"
#include "Render Manager/RENDER_MANAGER.h"
#include "States/States.h"
#include "Console/CONSOLE.h"
#include "Camera/WALKING_CAMERA.h"
#include "Bsp/BSP.h"
#include "Point Light/POINT_LIGHT.h"
#include "Codepaths/CODEPATH_MANAGER.h"
#include "Models/MODEL_MANAGER.h"
#include "Entities/ENTITY_MANAGER.h"
#include "Particle System/PARTICLE_SYSTEM.h"
#include "DrawLoadingScreen.h"
#include "Main.h"

//link to libraries
#pragma comment(lib, "opengl32.lib")
#pragma comment(lib, "glu32.lib")
#pragma comment(lib, "winmm.lib")

TIMER timer;
FPS_COUNTER fpsCounter;
BITMAP_FONT font;

COLOR backgroundColor(0.0f, 0.0f, 0.0f, 0.0f);

WALKING_CAMERA camera;

BSP bsp;

//Visible lights
std::vector <POINT_LIGHT *> visibleLights;

//Set up GL
bool GLInit()
{
	//Init window
	if(!WINDOW::Instance()->Init("The Octagon Engine", 640, 480, 8, 8, 8, 8, 24, 8, false, false))
		return false;

	//Check for GL 1.3
	if(!GLEE_VERSION_1_3)
	{
		LOG::Instance()->OutputError("OpenGL 1.3 required");
		return false;
	}
	else
		LOG::Instance()->OutputSuccess("OpenGL 1.3 Supported!");

	//Hide the cursor
	ShowCursor(0);

	//set viewport
	int height=WINDOW::Instance()->height;
	if(height==0)
		height=1;

	glViewport(0, 0, WINDOW::Instance()->width, height);

	//Set up projection matrix
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(	45.0f, (GLfloat)WINDOW::Instance()->width/(GLfloat)WINDOW::Instance()->height,
					1.0f, 100.0f);

	//Load identity modelview
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();

	//Shading states
	glShadeModel(GL_SMOOTH);
	glClearColor(backgroundColor.r, backgroundColor.g, backgroundColor.b, backgroundColor.a);
	glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
	glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);

	//Depth states
	glClearDepth(1.0f);
	glDepthFunc(GL_LEQUAL);
	glEnable(GL_DEPTH_TEST);

	glEnable(GL_CULL_FACE);

	return true;
}

//Set up variables
bool DemoInit()
{
	//Init font
	if(!font.Init())
		return false;

	DrawLoadingScreen();

	//Load the attenuation & norm. cube map textures
	if(!RENDER_MANAGER::Instance()->InitTextures())
		return false;

	//Init the codepaths
	if(!CODEPATH_MANAGER::Instance()->Init())
		return false;

	//Init console
	if(!CONSOLE::Instance()->Init(24, 64, 250.0, COLOR(0.2f, 0.04f, 0.4f)))
		return false;

	//Init camera
	camera.Init(VECTOR3D(0.0f, 0.0f, 9.5f), 90.0f, 0.0f, 5.0f, 0.25f);
	//Set camera's projection matrix
	glMatrixMode(GL_PROJECTION);
	glLoadMatrixf(camera.projectionMatrix);
	glMatrixMode(GL_MODELVIEW);

	//Load BSP and send vertices
	if(!bsp.Load("data/maps/final/final.bsp"))
		return false;

	//Init entities
	if(!ENTITY_MANAGER::Instance()->Init("data/maps/final/final.ent"))
		return false;

	//Lock number of vertices
	RENDER_MANAGER::Instance()->LockNumVertices();

	//Run the particle systems (4 secs) so that there is not an initial burst
	for(int i=0; i<80; ++i)
		ENTITY_MANAGER::Instance()->Update(50);

	//Clear the error string of any loading errors
	LOG::Instance()->ClearErrorString();

	//reset timer
	timer.Reset();

	return true;
}

//Perform per-frame updates
void UpdateFrame()
{
	//set currentTime and timePassed
	static double lastTime=timer.GetTime();
	double currentTime=timer.GetTime();
	double timePassed=currentTime-lastTime;
	lastTime=currentTime;
	
	//Update window
	WINDOW::Instance()->Update();

	//Update console
	CONSOLE::Instance()->Update(currentTime);
	
	//If the console is not active, update camera
	if(!CONSOLE::Instance()->isActive)
	{
		//Update the camera and check for collisions
		//This needs to be done in steps, checking for collisions each time
		for(int i=0;;++i)
		{
			if(camera.Update(timePassed, i))
				break;
							
			//Collide the camera with the bsp
			if(!CONSOLE::Instance()->variables.noclip)
				bsp.CalculateCollision(camera);
		}
		camera.FinishUpdate();

		//Calculate the visible bsp faces
		bsp.CalculateVisibleFaces(camera.GetPosition(), camera.viewFrustum, camera.visibleFaces);

		//Set the orientation in the render manager
		RENDER_MANAGER::Instance()->SetOrientation(camera.viewMatrix);
	}


	RENDER_MANAGER::Instance()->BeginDataUpdate();

	//Update entities
	ENTITY_MANAGER::Instance()->Update(timePassed);

	//Calculate the particle vertex positions from the particle positions
	if(CONSOLE::Instance()->variables.showParticles)
		RENDER_MANAGER::Instance()->CalculateParticleVertices();

	RENDER_MANAGER::Instance()->EndDataUpdate(true, false, false);


	//Calculate the visible lights
	ENTITY_MANAGER::Instance()->CalculateVisibleLights(visibleLights, camera.viewFrustum);

	//Loop through the visible lights
	for(std::size_t i=0; i<visibleLights.size(); ++i)
	{
		//Calculate the scissor rectangles
		visibleLights[i]->CalculateScissorRectangle(camera);

		//Calculate the near clip volume
		visibleLights[i]->CalculateNearClipVolume(camera);

		//Calculate the visible faces
		bsp.CalculateVisibleFaces(	visibleLights[i]->boundingSphere.centre,
									visibleLights[i]->boundingSphere,
									visibleLights[i]->visibleFaces);
	}

	//Render frame
	RenderFrame(currentTime);
}

//Render a frame
void RenderFrame(double currentTime)
{
	//Store the faces visible to the camera and a light
	static BITSET lightAndCameraVisibleFaces;

	//Store the codepath to use
	CODEPATH * codepath=CODEPATH_MANAGER::Instance()->codepath;

	//Clear buffers
	glClear(/*GL_COLOR_BUFFER_BIT | */GL_DEPTH_BUFFER_BIT | GL_STENCIL_BUFFER_BIT);
	
	//Set camera's view matrix
	glLoadMatrixf(camera.viewMatrix);
	glColor4fv(white);

	
	//DRAW LIT GEOMETRY
	DRAWING_STATES drawingStates;

	//Set States
	if(CONSOLE::Instance()->variables.useScissor)
		glEnable(GL_SCISSOR_TEST);

	if(CONSOLE::Instance()->variables.usePolyOffset)
		glEnable(GL_POLYGON_OFFSET_FILL);

	
	//DRAW AMBIENT PASS
	RENDER_MANAGER::Instance()->BeginGeometryDrawing();
	SetAmbientStates();
	glScissor(0, 0, WINDOW::Instance()->width, WINDOW::Instance()->height);
	glPolygonOffset(0.0f,-1.0f);

	RENDER_MANAGER::Instance()->EnableGeometryVertexArrays( false, GL_TEXTURE0,
															GL_TEXTURE1, 0, 0, 0);
	
	//Send indices
	bsp.SendPolygonFaceIndices(camera.visibleFaces, true);
	bsp.SendPatchIndices(camera.visibleFaces, &camera.viewFrustum, NULL);
	ENTITY_MANAGER::Instance()->SendGeometryIndices(&camera.viewFrustum, NULL);

	//Draw
	RENDER_MANAGER::Instance()->DrawGeometry(true, GL_TEXTURE0, 0, GL_TEXTURE1);
		
	RENDER_MANAGER::Instance()->EndGeometryDrawing();
	EndAmbientStates();
	RENDER_MANAGER::Instance()->DisableGeometryVertexArrays();
	RENDER_MANAGER::Instance()->ClearGeometryLists();
	

	//LOOP THROUGH LIGHTS
	for(std::size_t i=0; i<visibleLights.size(); ++i)
	{
		//Keep track of whether the non-projected shadow vertices have been calculated this frame
		bool nonProjectedCalculated=false;

		POINT_LIGHT * light=visibleLights[i];
		VECTOR3D & lightPosition=light->boundingSphere.centre;

		//Do a light occlusion test if requested
		if(	GLEE_HP_occlusion_test && 
			CONSOLE::Instance()->variables.useLightOcclusionTest)
		{
			if(!light->boundingSphere.IsPointInside(camera.GetPosition()))
			{
				SetOcclusionTestStates();
				light->DrawBoundingSphere();
				if(!EndOcclusionTestStates())
					continue;
			}
		}

		//Set scissor for this light if in front of near plane
		if(	CONSOLE::Instance()->variables.useScissor &&
			camera.viewFrustum.planes[FRUSTUM_NEAR_PLANE].ClassifyPoint(lightPosition)==
																	POINT_IN_FRONT_OF_PLANE)
		{
			light->SetScissor();
		}
		else
			glScissor(0, 0, WINDOW::Instance()->width, WINDOW::Instance()->height);

		//Calculate which bsp faces face the light
		bsp.CalculateFacing(lightPosition);

		//Calculate the bsp faces to draw (those visible to both the camera and the light
		camera.visibleFaces.And(light->visibleFaces, lightAndCameraVisibleFaces);

		//Fill in the index lists for this light
		//skip the drawing if none are sent
		bool indicesSent=bsp.SendPolygonFaceIndices(lightAndCameraVisibleFaces, false);
		indicesSent|=bsp.SendPatchIndices(	lightAndCameraVisibleFaces,
												&camera.viewFrustum,
												&light->boundingSphere);
		indicesSent|=ENTITY_MANAGER::Instance()->SendGeometryIndices(&camera.viewFrustum,
																	&light->boundingSphere);

		if(indicesSent)
		{
			//Send shadow volume indices
			if(CONSOLE::Instance()->variables.showShadows)
			{
				bsp.SendShadowVolumeIndices(*light,
											&light->boundingSphere,
											NULL);
				ENTITY_MANAGER::Instance()->SendShadowVolumeIndices(*light,
																	&light->boundingSphere,
																	NULL);
			}

			//Update data
			RENDER_MANAGER::Instance()->BeginDataUpdate();

			//Calculate and store (in spare) the tangent space light vectors if necessary
			if(codepath->AreTangentSpaceLightVectorsRequired())
				RENDER_MANAGER::Instance()->StoreTangentSpaceLightVectors(
																light->boundingSphere.centre);

			//Calculate shadow volume vertices
			//Calculate the non-projected verts if not yet done this frame
			if(CONSOLE::Instance()->variables.showShadows)
				RENDER_MANAGER::Instance()->CalculateShadowVolumeVertices(*light,
																		!nonProjectedCalculated,
																		true);
			nonProjectedCalculated=true;	//set the boolean for the non projected verts
					
			RENDER_MANAGER::Instance()->EndDataUpdate(false,
												codepath->AreTangentSpaceLightVectorsRequired(),
												true);

			//DRAW SHADOW VOLUMES
			
			//Set polygon offset for the shadows of this light
			glPolygonOffset(0.0f, 0.0f);
	
			if(CONSOLE::Instance()->variables.showShadows)
			{
				//Clear stencil
				if(i!=0)
					glClear(GL_STENCIL_BUFFER_BIT);

				RENDER_MANAGER::Instance()->BeginShadowDrawing();
				SetShadowStates();
				RENDER_MANAGER::Instance()->EnableShadowVolumeVertexArrays();

				//Draw zFail shadows
				SetShadowPass1States(true);
				RENDER_MANAGER::Instance()->DrawShadowVolumes(true, false);
							
				//Draw 2nd pass if necessary
				if(SetShadowPass2States(true))
					RENDER_MANAGER::Instance()->DrawShadowVolumes(true, false);
					
				//Draw zPass shadows
				SetShadowPass1States(false);
				RENDER_MANAGER::Instance()->DrawShadowVolumes(false, true);

				//Draw 2nd pass if necessary
				if(SetShadowPass2States(false))
					RENDER_MANAGER::Instance()->DrawShadowVolumes(false, true);

				RENDER_MANAGER::Instance()->EndShadowDrawing();
				EndShadowStates();
				RENDER_MANAGER::Instance()->DisableShadowVolumeVertexArrays();
			}
		
			//DRAW LIGHTING PASSES

			//Set polygon offset for the geometry of this light
			glPolygonOffset(0.0f, -float(i)-2.0f);

			RENDER_MANAGER::Instance()->BeginGeometryDrawing();

			//Disable z writes and use EQUAL depth testing for geometry, 
			//if not using polygon offset
			//glDepthMask(0);
			//glDepthFunc(GL_EQUAL);

			for(int pass=0; pass<4; ++pass)
			{
				if(!codepath->SetLightingStates(pass, light,
												camera.GetPosition(), drawingStates))
					continue;

				RENDER_MANAGER::Instance()->EnableGeometryVertexArrays(
																drawingStates.useNormalArray,
																drawingStates.textureCoordUnit1,
																drawingStates.textureCoordUnit2,
																drawingStates.sTangentUnit,
																drawingStates.tTangentUnit,
																drawingStates.spareUnit);
						
				//Draw
				RENDER_MANAGER::Instance()->DrawGeometry(	drawingStates.drawNonGloss,
															drawingStates.decalTextureUnit,
															drawingStates.normalMapTextureUnit,
															drawingStates.emissiveTextureUnit);

				codepath->EndLighting(pass, light);
				
				RENDER_MANAGER::Instance()->DisableGeometryVertexArrays();
			}
			
			RENDER_MANAGER::Instance()->EndGeometryDrawing();

			glDepthMask(1);
			glDepthFunc(GL_LEQUAL);
		}
		
		//Clear index lists
		RENDER_MANAGER::Instance()->ClearGeometryLists();
		RENDER_MANAGER::Instance()->ClearShadowVolumeLists();
	}

	//reset states
	glColor4fv(white);
	glDisable(GL_SCISSOR_TEST);
	glDisable(GL_POLYGON_OFFSET_FILL);

	
	//DRAW PARTICLES
	if(CONSOLE::Instance()->variables.showParticles)
	{
		//SELF LIT PARTICLES
		RENDER_MANAGER::Instance()->BeginParticleDrawing();
		SetSelfLitParticleStates();
		RENDER_MANAGER::Instance()->EnableParticleVertexArrays(true, false, GL_TEXTURE0);

		//Send indices
		ENTITY_MANAGER::Instance()->SendParticleIndices(true, false, &camera.viewFrustum, NULL);

		//Draw
		RENDER_MANAGER::Instance()->DrawParticles(GL_TEXTURE0);

		RENDER_MANAGER::Instance()->EndParticleDrawing();
		EndSelfLitParticleStates();
		RENDER_MANAGER::Instance()->DisableParticleVertexArrays();
		RENDER_MANAGER::Instance()->ClearParticleLists();
	
		
		//NON SELF LIT PARTICLES
		glEnable(GL_SCISSOR_TEST);

		for(std::size_t i=0; i<visibleLights.size(); ++i)
		{
			//Send indices
			//Skip the drawing if no particle indices were sent
			if(ENTITY_MANAGER::Instance()->SendParticleIndices(false, true, &camera.viewFrustum,
															&visibleLights[i]->boundingSphere))
			{
				//Set scissor for this light if in front of near plane
				VECTOR3D & lightPosition=visibleLights[i]->boundingSphere.centre;
				if(camera.viewFrustum.planes[FRUSTUM_NEAR_PLANE].ClassifyPoint(lightPosition)==
																		POINT_IN_FRONT_OF_PLANE)
				{
					visibleLights[i]->SetScissor();
				}
				else
					glScissor(0, 0, WINDOW::Instance()->width, WINDOW::Instance()->height);

				//Calculate attenuated colors for particles
				RENDER_MANAGER::Instance()->CalculateParticleVertexAttenuatedColors(*visibleLights[i]);


				//DRAW PARTICLES
				SetNonSelfLitParticleStates(*visibleLights[i]);

				RENDER_MANAGER::Instance()->EnableParticleVertexArrays(false, true, GL_TEXTURE0);

				//Draw
				RENDER_MANAGER::Instance()->DrawParticles(GL_TEXTURE0);

				EndNonSelfLitParticleStates(*visibleLights[i]);

				RENDER_MANAGER::Instance()->DisableParticleVertexArrays();
	
				//Clear lists
				RENDER_MANAGER::Instance()->ClearParticleLists();
			}
		}

		//reset states
		glColor4fv(white);
		glDisable(GL_SCISSOR_TEST);
	}
	




	//Draw bounding boxes
	if(CONSOLE::Instance()->variables.showBoundingBoxes)
	{
		ENTITY_MANAGER::Instance()->DrawBoundingBoxes();
		bsp.DrawPatchBoundingBoxes();
	}

	//Draw lights
	if(CONSOLE::Instance()->variables.showLightPositions)
	{
		static GLUquadricObj * sphere=gluNewQuadric();
		for(std::size_t i=0; i<visibleLights.size(); ++i)
		{
			glPushMatrix();
			glTranslatef(	visibleLights[i]->boundingSphere.centre.x,
							visibleLights[i]->boundingSphere.centre.y,
							visibleLights[i]->boundingSphere.centre.z);
			glColor4fv(visibleLights[i]->color);
			gluSphere(sphere, 0.1f, 12, 12);
			glPopMatrix();
		}
		glColor4fv(white);
	}

	
	SetOrthoStates();

	//Draw light scissor rectangles
	if(CONSOLE::Instance()->variables.showScissorRectangles)
	{
		for(std::size_t i=0; i<visibleLights.size(); ++i)
			visibleLights[i]->DrawScissorRectangle();
	}

	//Draw console
	CONSOLE::Instance()->Draw();

	EndOrthoStates();

	fpsCounter.Update();

	//Print debug info
	if(CONSOLE::Instance()->variables.showDebugInfo)
	{
		font.StartTextMode();
		glColor4f(0.0f, 1.0f, 0.0f, 1.0f);
		font.Print(0, 28, "FPS: %.2f", fpsCounter.GetFps());
		glColor4f(1.0f, 1.0f, 0.0f, 1.0f);
		font.Print(0, 48, "Lights Visible: %d", visibleLights.size());
		glColor4f(1.0f, 0.0f, 0.7f, 1.0f);
		font.Print(0, 68, "%s", CODEPATH_MANAGER::Instance()->GetCodepathString());
		glColor4f(0.5f, 0.8f, 1.0f, 1.0f);
		font.Print(0, 88, "%s", LOG::Instance()->GetErrorString());
		font.EndTextMode();
	}

	WINDOW::Instance()->SwapBuffers();

	//Save a screenshot
	if(WINDOW::Instance()->IsKeyPressed(VK_F1))
	{
		WINDOW::Instance()->SaveScreenshot();
		WINDOW::Instance()->SetKeyReleased(VK_F1);
	}

	//Check for an openGL error
	WINDOW::Instance()->CheckGLError();

	//quit if necessary
	if(WINDOW::Instance()->IsKeyPressed(VK_ESCAPE))
		PostQuitMessage(0);
}

//Shut down demo
void DemoShutdown()
{
	ShowCursor(1);
	font.Shutdown();
	WINDOW::Instance()->Shutdown();
}

//WinMain
int WINAPI WinMain(	HINSTANCE	hInstance,			//Instance
					HINSTANCE	hPrevInstance,		//Previous Instance
					LPSTR		lpCmdLine,			//Command line params
					int			nShowCmd)			//Window show state
{
	//Save hInstance
	WINDOW::Instance()->hInstance=hInstance;

	//Init GL and variables
	if(!GLInit())
	{
		LOG::Instance()->OutputError("OpenGL Initiation Failed");
		return false;
	}
	else
		LOG::Instance()->OutputSuccess("OpenGL Initiation Successful");

	if(!DemoInit())
	{
		LOG::Instance()->OutputError("Demo Initiation Failed");
		return false;
	}
	else
		LOG::Instance()->OutputSuccess("Demo Initiation Successful");

	//Main Loop
	for(;;)
	{
		if(!(WINDOW::Instance()->HandleMessages()))	//quit if HandleMessages returns false
			break;

		UpdateFrame();
	}

	//Shutdown
	DemoShutdown();

	//Exit program
	LOG::Instance()->OutputSuccess("Exiting...");
	return 0;
}
