//////////////////////////////////////////////////////////////////////////////////////////
//	ENTITY_Init.cpp
//	Initiate an entity
//	Downloaded from: www.paulsprojects.net
//	Created:	16th February 2003
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <vector>
#include "../GL files/glee.h"
#include "../Maths/Maths.h"
#include "../Log/LOG.h"
#include "../Bounding Volumes/Bounding Volumes.h"
#include "../Render Manager/RENDER_MANAGER.h"
#include "../Console/CONSOLE.h"
#include "../Point Light/POINT_LIGHT.h"
#include "../Models/MODEL_MANAGER.h"
#include "ENTITY_MANAGER.h"

bool ENTITY::Init(	char * modelFilename,
					ANIM_SEQUENCE newAnimSequence,
					float newAnimSpeed,
					const VECTOR3D & newPosition,
					float newAngleYaw,
					char * particleFilename,
					char * lightFilename,
					char * pathFilename,
					float newPathSpeed)
{
	//Fill in the position
	position=newPosition;
	angleYaw=newAngleYaw;

	//Create the model
	if(strcmp(modelFilename, "None")!=0)
	{
		modelInstance=new MODEL_INSTANCE;
		if(!modelInstance)
		{
			LOG::Instance()->OutputError("Unable to allocate space for model instance");
			return false;
		}
		
		//Load the model
		if(!modelInstance->Init(modelFilename, position, angleYaw))
			return false;
	}
	
	animSequence=newAnimSequence;
	animSpeed=newAnimSpeed;

	//Create particle system
	if(strcmp(particleFilename, "None")!=0)
	{
		particleSystem=new PARTICLE_SYSTEM;
		if(!particleSystem)
		{
			LOG::Instance()->OutputError("Unable to allocate space for particle system");
			return false;
		}
			
		if(!particleSystem->Init(particleFilename))
			return false;
	}

	//Create the light
	if(strcmp(lightFilename, "None")!=0)
	{
		light=new POINT_LIGHT;
		if(!light)
		{
			LOG::Instance()->OutputError("Unable to allocate space for light");
			return false;
		}

		if(!light->Init(lightFilename))
			return false;

		//Copy the entity-space light position into the entity
		lightPosition=light->boundingSphere.centre;
	}

	//Fill the path
	if(!path.Init(pathFilename, position, angleYaw))
		return false;

	//Save the path speed
	pathSpeed=newPathSpeed;

	return true;
}