//////////////////////////////////////////////////////////////////////////////////////////
//	ENTITY_MANAGER.h
//	Class to manage entities
//	Downloaded from: www.paulsprojects.net
//	Created:	18th December 2002
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	

#ifndef ENTITY_MANAGER_H
#define ENTITY_MANAGER_H

#include <vector>
#include "../Bounding Volumes/Bounding Volumes.h"
#include "ENTITY.h"

class ENTITY_MANAGER
{
protected:
	//Protected constructor & copy contructor to prevent making copies
	ENTITY_MANAGER()
	{}
	ENTITY_MANAGER(const MODEL_MANAGER &)
	{}
	ENTITY_MANAGER & operator=(const ENTITY_MANAGER &)
	{}

public:
	static ENTITY_MANAGER * Instance()
	{
		static ENTITY_MANAGER instance;
		return &instance;
	}

	bool Init(char * filename);

	//Create entity
	bool CreateEntity(	char * modelFilename,
						ANIM_SEQUENCE animSequence,
						float newAnimSpeed,
						const VECTOR3D & position,
						float angleYaw,
						char * particleFilename,
						char * lightFilename,
						char * pathFilename,
						float newPathSpeed);

	//Update
	void Update(double timePassed)
	{
		for(std::size_t i=0; i<entities.size(); ++i)
			entities[i]->Update(timePassed);
	}

	//Send the indices for all entities lying in given volumes
	bool SendGeometryIndices(const BOUNDING_VOLUME * volume1, const BOUNDING_VOLUME * volume2)
	{
		bool anySent=false;

		for(std::size_t i=0; i<entities.size(); ++i)
		{
			if(volume1)
				if(!entities[i]->IsInVolume(volume1))
					continue;

			if(volume2)
				if(!entities[i]->IsInVolume(volume2))
					continue;

			if(entities[i]->SendGeometryIndices())
				anySent=true;
		}

		return anySent;
	}

	bool SendParticleIndices(	bool sendSelfLit, bool sendNonSelfLit,
								const BOUNDING_VOLUME * volume1, const BOUNDING_VOLUME * volume2)
	{
		bool anySent=false;

		for(std::size_t i=0; i<entities.size(); ++i)
		{
			if(volume1)
				if(!entities[i]->IsInVolume(volume1))
					continue;

			if(volume2)
				if(!entities[i]->IsInVolume(volume2))
					continue;

			if(entities[i]->SendParticleIndices(sendSelfLit, sendNonSelfLit))
				anySent=true;
		}

		return anySent;
	}

	void SendShadowVolumeIndices(	const POINT_LIGHT & currentLight,
									const BOUNDING_VOLUME * volume1,
									const BOUNDING_VOLUME * volume2)
	{
		for(std::size_t i=0; i<entities.size(); ++i)
		{
			if(volume1)
				if(!entities[i]->IsInVolume(volume1))
					continue;

			if(volume2)
				if(!entities[i]->IsInVolume(volume2))
					continue;

			entities[i]->SendShadowVolumeIndices(currentLight);
		}
	}

	//Fill a vector with the visible lights
	void CalculateVisibleLights(std::vector <POINT_LIGHT *> & visibleLights,
								const BOUNDING_VOLUME & volume);

	//Draw bounding boxes
	void DrawBoundingBoxes()
	{
		for(std::size_t i=0; i<entities.size(); ++i)
			entities[i]->DrawBoundingBox();
	}

protected:
	std::vector <ENTITY *> entities;
};

#endif	//ENTITY_MANAGER_H