//////////////////////////////////////////////////////////////////////////////////////////
//	ENTITY.h
//	Base class for an entity
//	Downloaded from: www.paulsprojects.net
//	Created:	18th December 2002
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	

#ifndef ENTITY_H
#define ENTITY_H

#include "../Particle System/PARTICLE_SYSTEM.h"
#include "../Model Instance/MODEL_INSTANCE.h"
#include "../Point Light/POINT_LIGHT.h"
#include "../Paths/PATH.h"

class ENTITY
{
public:
	//current position
	VECTOR3D position;
	float angleYaw;

	bool Init(	char * modelFilename,
				ANIM_SEQUENCE newAnimSequence,
				float newAnimSpeed,
				const VECTOR3D & newPosition,
				float newAngleYaw,
				char * particleFilename,
				char * lightFilename,
				char * pathFilename,
				float newPathSpeed);

	//Send the vertices to the render manager
	bool SendVertices()
	{	
		if(modelInstance)
			return modelInstance->SendVertices(position, angleYaw);
		return true;
	}			

	//Update (inc. vertices)
	void Update(double timePassed);

	//Send Indices. return false if none were sent
	bool SendGeometryIndices()
	{
		if(modelInstance)
		{
			modelInstance->SendGeometryIndices();
			return true;
		}

		return false;
	}

	bool SendParticleIndices(bool sendSelfLit, bool sendNonSelfLit)
	{	
		if(particleSystem)
			return particleSystem->SendIndices(sendSelfLit, sendNonSelfLit);

		return false;
	}

	void SendShadowVolumeIndices(const POINT_LIGHT & currentLight)
	{
		if(!modelInstance)
			return;

		bool zFailRequired=currentLight.IsBoundingBoxInsideNearClipVolume(boundingBox);

		modelInstance->SendShadowVolumeIndices(	zFailRequired, currentLight);
	}

	void DrawBoundingBox()
	{
		boundingBox.Draw();
	}

	//Is this entity in a given bounding volume?
	bool IsInVolume(const BOUNDING_VOLUME * volume)
	{	return volume->IsAABoundingBoxInside(boundingBox);	}

	//Model instance
	MODEL_INSTANCE * modelInstance;
	ANIM_SEQUENCE animSequence;
	float distanceThroughAnimSequence;
	float animSpeed;

	//Particle system
	PARTICLE_SYSTEM * particleSystem;

	//Light
	POINT_LIGHT * light;	//light position is in world space
	VECTOR3D lightPosition;	//in entity space

	//path followed
	PATH path;
	float distanceAlongPath;
	float pathSpeed;	//speed of travel along path

	//Bounding box
protected:
	void UpdateBoundingBox();
	AA_BOUNDING_BOX boundingBox;

public:
	ENTITY()	:	modelInstance(NULL), particleSystem(NULL), distanceThroughAnimSequence(0),
					light(NULL), distanceAlongPath(0)
	{}
	~ENTITY()
	{
		if(modelInstance)
			delete modelInstance;
		modelInstance=NULL;

		if(particleSystem)
			delete particleSystem;
		particleSystem=NULL;

		if(light)
			delete light;
		light=NULL;
	}
};

#endif	//ENTITY_H
