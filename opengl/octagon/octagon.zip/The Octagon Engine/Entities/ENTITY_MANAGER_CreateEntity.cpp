//////////////////////////////////////////////////////////////////////////////////////////
//	ENTITY_MANAGER_CreateEntity.cpp
//	Create an entity
//	Downloaded from: www.paulsprojects.net
//	Created:	16th December 2002
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <vector>
#include "../GL files/glee.h"
#include "../Maths/Maths.h"
#include "../Log/LOG.h"
#include "../Bounding Volumes/Bounding Volumes.h"
#include "../Render Manager/RENDER_MANAGER.h"
#include "../Console/CONSOLE.h"
#include "../Point Light/POINT_LIGHT.h"
#include "../Models/MODEL_MANAGER.h"
#include "ENTITY_MANAGER.h"

bool ENTITY_MANAGER::CreateEntity(	char * modelFilename,
									ANIM_SEQUENCE animSequence,
									float newAnimSpeed,
									const VECTOR3D & position,
									float angleYaw,
									char * particleFilename,
									char * lightFilename,
									char * pathFilename,
									float newPathSpeed)
{
	//Create the new entity
	ENTITY * newEntity=new ENTITY;
	if(!newEntity)
	{
		LOG::Instance()->OutputError("Unable to create space for new ENTITY");
		return false;
	}

	if(!newEntity->Init(modelFilename,
						animSequence,
						newAnimSpeed,
						position,
						angleYaw,
						particleFilename,
						lightFilename,
						pathFilename,
						newPathSpeed))
		return false;

	//Add the new entity to the vector
	entities.push_back(newEntity);

	return true;
}