//////////////////////////////////////////////////////////////////////////////////////////
//	ENTITY_UpdateBoundingBox.cpp
//	Update the AA bounding box
//	Downloaded from: www.paulsprojects.net
//	Created:	16th December 2002
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <vector>
#include "../GL files/glee.h"
#include "../Maths/Maths.h"
#include "../Log/LOG.h"
#include "../Bounding Volumes/Bounding Volumes.h"
#include "../Render Manager/RENDER_MANAGER.h"
#include "../Console/CONSOLE.h"
#include "../Point Light/POINT_LIGHT.h"
#include "../Models/MODEL_MANAGER.h"
#include "ENTITY_MANAGER.h"

void ENTITY::UpdateBoundingBox()
{
	VECTOR3D newMins ( 999999.0f, 999999.0f, 999999.0f);
	VECTOR3D newMaxes(-999999.0f,-999999.0f,-999999.0f);

	//Loop through vertices & update values
	if(modelInstance)
	{
		for(int i=0; i<modelInstance->numGeometryVertices; ++i)
		{
			VECTOR3D & vertexPosition=RENDER_MANAGER::Instance()->
							GetGeometryVertex(modelInstance->firstGeometryVertexIndex+i).position;

			if(vertexPosition.x<newMins.x)
				newMins.x=vertexPosition.x;
		
			if(vertexPosition.y<newMins.y)
				newMins.y=vertexPosition.y;
		
			if(vertexPosition.z<newMins.z)
				newMins.z=vertexPosition.z;

			if(vertexPosition.x>newMaxes.x)
				newMaxes.x=vertexPosition.x;

			if(vertexPosition.y>newMaxes.y)
				newMaxes.y=vertexPosition.y;

			if(vertexPosition.z>newMaxes.z)
				newMaxes.z=vertexPosition.z;
		}
	}

	//Loop through particles
	if(particleSystem)
	{
		for(int i=0; i<particleSystem->GetMaxParticles(); ++i)
		{
			VECTOR3D & particlePosition=particleSystem->GetParticlePosition(i);

			if(particlePosition.x<newMins.x)
			newMins.x=particlePosition.x;
		
			if(particlePosition.y<newMins.y)
				newMins.y=particlePosition.y;
		
			if(particlePosition.z<newMins.z)
				newMins.z=particlePosition.z;

			if(particlePosition.x>newMaxes.x)
				newMaxes.x=particlePosition.x;

			if(particlePosition.y>newMaxes.y)
				newMaxes.y=particlePosition.y;

			if(particlePosition.z>newMaxes.z)
				newMaxes.z=particlePosition.z;
		}
	}

	//Set zero box if no particle system or model instance
	if(!particleSystem && !modelInstance)
	{
		newMins.LoadZero();
		newMaxes.LoadZero();
	}

	boundingBox.SetFromMinsMaxes(newMins, newMaxes);
}
