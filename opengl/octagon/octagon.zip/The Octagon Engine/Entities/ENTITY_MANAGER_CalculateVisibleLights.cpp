//////////////////////////////////////////////////////////////////////////////////////////
//	ENTITY_MANAGER_CalculateVisibleLights.cpp
//	Fill a vector with the lights inside a given volume
//	Downloaded from: www.paulsprojects.net
//	Created:	11th February 2003
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <vector>
#include "../GL files/glee.h"
#include "../Maths/Maths.h"
#include "../Log/LOG.h"
#include "../Bounding Volumes/Bounding Volumes.h"
#include "../Render Manager/RENDER_MANAGER.h"
#include "../Console/CONSOLE.h"
#include "../Point Light/POINT_LIGHT.h"
#include "../Models/MODEL_MANAGER.h"
#include "ENTITY_MANAGER.h"

void ENTITY_MANAGER::CalculateVisibleLights(std::vector <POINT_LIGHT *> & visibleLights,
											const BOUNDING_VOLUME & volume)
{
	visibleLights.clear();

	for(std::size_t i=0; i<entities.size(); ++i)
	{
		if(!entities[i]->light)
			continue;

		//Skip this light if the bounding sphere does not intersect the frustum
		if(!volume.IsBoundingSphereInside(entities[i]->light->boundingSphere))
			continue;

		//Add this light to the list of visible lights
		visibleLights.push_back(entities[i]->light);
	}
}
