//////////////////////////////////////////////////////////////////////////////////////////
//	ENTITY_Update.cpp
//	Update vertices in the render manager
//	Downloaded from: www.paulsprojects.net
//	Created:	16th December 2002
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <vector>
#include "../GL files/glee.h"
#include "../Maths/Maths.h"
#include "../Log/LOG.h"
#include "../Bounding Volumes/Bounding Volumes.h"
#include "../Render Manager/RENDER_MANAGER.h"
#include "../Console/CONSOLE.h"
#include "../Point Light/POINT_LIGHT.h"
#include "../Models/MODEL_MANAGER.h"
#include "ENTITY_MANAGER.h"

void ENTITY::Update(double timePassed)
{
	//Calculate the new position and angleYaw
	distanceAlongPath+=float(timePassed*pathSpeed);
	
	//Check distance is in [0, 1]
	while(distanceAlongPath<0.0f)
		distanceAlongPath+=1.0f;
	while(distanceAlongPath>1.0f)
		distanceAlongPath-=1.0f;

	path.GetCurrentPosition(distanceAlongPath, position, angleYaw);
	
	//Calculate the new distance through the animation sequence
	distanceThroughAnimSequence+=float(timePassed*animSpeed);

	//make sure this is in [0, 1]
	while(distanceThroughAnimSequence>1.0f)
		distanceThroughAnimSequence-=1.0f;

	//Update model instance
	if(modelInstance)
		modelInstance->Update(animSequence, distanceThroughAnimSequence, position, angleYaw);

	//Update Particle System
	if(particleSystem)
		particleSystem->Update(timePassed, position, angleYaw);

	//Update light position
	if(light)
		light->boundingSphere.centre=lightPosition.GetRotatedY(angleYaw)+position;

	UpdateBoundingBox();
}

