//////////////////////////////////////////////////////////////////////////////////////////
//	ENTITY_MANAGER_Init.cpp
//	Initiate entities from a file
//	Downloaded from: www.paulsprojects.net
//	Created:	16th February 2003
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <vector>
#include "../GL files/glee.h"
#include "../Maths/Maths.h"
#include "../Log/LOG.h"
#include "../Bounding Volumes/Bounding Volumes.h"
#include "../Render Manager/RENDER_MANAGER.h"
#include "../Console/CONSOLE.h"
#include "../Point Light/POINT_LIGHT.h"
#include "../Models/MODEL_MANAGER.h"
#include "ENTITY_MANAGER.h"

bool ENTITY_MANAGER::Init(char * filename)
{
	//Open the file to read in the list of entities
	FILE * file=fopen(filename, "rt");
	if(!file)
	{
		LOG::Instance()->OutputError("Unable to open %s", filename);
		return false;
	}

	//Read in the number of entities
	int numEntities;
	fscanf(file, "Num Entities: %d ", &numEntities);

	//Read in the entities
	for(int i=0; i<numEntities; ++i)
	{
		char modelFilename[512];
		char animSequenceString[512];
		float animSpeed;
		VECTOR3D position;
		float angleYaw;
		char particleFilename[512];
		char lightFilename[512];
		char pathFilename[512];
		float pathSpeed;

		fscanf(file, "Model Filename: %s ", modelFilename);
		fscanf(file, "Anim Sequence: %s ", animSequenceString);
		fscanf(file, "Anim Speed: %f ", &animSpeed);
		fscanf(file, "Position: (%f, %f, %f) ", &position.x, &position.y, &position.z);
		fscanf(file, "Angle Yaw: %f ", &angleYaw);
		fscanf(file, "Particle Filename: %s ", particleFilename);
		fscanf(file, "Light Filename: %s ", lightFilename);
		fscanf(file, "Path Filename: %s ", pathFilename);
		fscanf(file, "Path Speed: %f ", &pathSpeed);
		
		ANIM_SEQUENCE animSequence;

		if(strcmp(animSequenceString, "FirstFrame")==0)
			animSequence=ANIMSEQ_FIRSTFRAME;
		if(strcmp(animSequenceString, "Idle")==0)
			animSequence=ANIMSEQ_IDLE;
		if(strcmp(animSequenceString, "Run")==0)
			animSequence=ANIMSEQ_RUN;

		CreateEntity(	modelFilename,
						animSequence,
						animSpeed,
						position,
						angleYaw,
						particleFilename,
						lightFilename,
						pathFilename,
						pathSpeed);
	}

	fclose(file);
	
	return true;
}