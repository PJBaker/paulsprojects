//////////////////////////////////////////////////////////////////////////////////////////
//	Point Light/CalculateScissorRectangle.cpp
//	Calculate the scissor rectangle for a point light
//	Downloaded from: www.paulsprojects.net
//	Created:	14th December 2002
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <vector>
#include "../GL files/glee.h"			//header for OpenGL 1.4
#include "../Maths/Maths.h"
#include "../Log/LOG.h"
#include "../Bounding Volumes/Bounding Volumes.h"
#include "../Camera/WALKING_CAMERA.h"
#include "POINT_LIGHT.h"

//This fails if the light is behind the near clip volume.
//Can we fix this? - todo

void POINT_LIGHT::CalculateScissorRectangle(const WALKING_CAMERA & camera)
{
	//Store the coordinates of the scissor rectangle
	//Start by setting them to the outside of the screen
	scissorLeft=-1.0f;
	float scissorRight=1.0f;
	
	scissorBottom=-1.0f;
	float scissorTop=1.0f;

	//r is the radius of the bounding sphere of the light
	float & r=boundingSphere.radius;

	//l is the light's position in eye space
	VECTOR3D l=camera.viewMatrix*boundingSphere.centre;

	//halfNearPlaneHeight is half the height of the near plane, i.e. from the centre to the top
	float halfNearPlaneHeight=camera.nearDistance*(float)tan(double(camera.fovy*M_PI/360));

	float halfNearPlaneWidth=halfNearPlaneHeight*camera.aspectRatio;

	//All calculations in eye space
	
	
	//We wish to find 2 planes parallel to the Y axis which are tangent to the bounding sphere
	//of the light and pass through the origin (camera position)

	//plane normal. Of the form (x, 0, z)
	VECTOR3D normal;

	//Calculate the discriminant of the quadratic we wish to solve to find nx(divided by 4)
	float d=(l.z*l.z) * ( (l.x*l.x) + (l.z*l.z) - r*r );

	//If d>0, solve the quadratic to get the normal to the plane
	if(d>0.0f)
	{
		float rootD=(float)sqrt(d);

		//Loop through the 2 solutions
		for(int i=0; i<2; ++i)
		{
			//Calculate the normal
			if(i==0)
				normal.x=r*l.x+rootD;
			else
				normal.x=r*l.x-rootD;

			normal.x/=(l.x*l.x + l.z*l.z);

			normal.z=r-normal.x*l.x;
			normal.z/=l.z;

			//We need to divide by normal.x. If ==0, no good
			if(normal.x==0.0f)
				continue;


			//p is the point of tangency
			VECTOR3D p;

			p.z=(l.x*l.x) + (l.z*l.z) - r*r;
			p.z/=l.z-((normal.z/normal.x)*l.x);

			//If the point of tangency is behind the camera, no good
			if(p.z>=0.0f)
				continue;

			p.x=-p.z * normal.z/normal.x;

			//Calculate where the plane meets the near plane
			//divide by the width to give a value in [-1, 1] for values on the screen
			float screenX=normal.z * camera.nearDistance / (normal.x*halfNearPlaneWidth);
			
			//If this is a left bounding value (p.x<l.x) and is further right than the
			//current value, update
			if(p.x<l.x && screenX>scissorLeft)
				scissorLeft=screenX;

			//Similarly, update the right value
			if(p.x>l.x && screenX<scissorRight)
				scissorRight=screenX;
		}
	}


	//Repeat for planes parallel to the x axis
	//normal is now of the form(0, y, z)
	normal.x=0.0f;

	//Calculate the discriminant of the quadratic we wish to solve to find ny(divided by 4)
	d=(l.z*l.z) * ( (l.y*l.y) + (l.z*l.z) - r*r );

	//If d>0, solve the quadratic to get the normal to the plane
	if(d>0.0f)
	{
		float rootD=(float)sqrt(d);

		//Loop through the 2 solutions
		for(int i=0; i<2; ++i)
		{
			//Calculate the normal
			if(i==0)
				normal.y=r*l.y+rootD;
			else
				normal.y=r*l.y-rootD;

			normal.y/=(l.y*l.y + l.z*l.z);

			normal.z=r-normal.y*l.y;
			normal.z/=l.z;

			//We need to divide by normal.y. If ==0, no good
			if(normal.y==0.0f)
				continue;


			//p is the point of tangency
			VECTOR3D p;

			p.z=(l.y*l.y) + (l.z*l.z) - r*r;
			p.z/=l.z-((normal.z/normal.y)*l.y);

			//If the point of tangency is behind the camera, no good
			if(p.z>=0.0f)
				continue;

			p.y=-p.z * normal.z/normal.y;

			//Calculate where the plane meets the near plane
			//divide by the height to give a value in [-1, 1] for values on the screen
			float screenY=normal.z * camera.nearDistance / (normal.y*halfNearPlaneHeight);
			
			//If this is a bottom bounding value (p.y<l.y) and is further up than the
			//current value, update
			if(p.y<l.y && screenY>scissorBottom)
				scissorBottom=screenY;

			//Similarly, update the top value
			if(p.y>l.y && screenY<scissorTop)
				scissorTop=screenY;
		}
	}

	//Store the width & height of the rectangle
	scissorWidth=scissorRight-scissorLeft;
	scissorHeight=scissorTop-scissorBottom;
}