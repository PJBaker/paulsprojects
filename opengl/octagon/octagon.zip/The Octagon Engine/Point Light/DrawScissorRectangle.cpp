//////////////////////////////////////////////////////////////////////////////////////////
//	Point Light/DrawScissorRectangle.cpp
//	Draw the scissor rectangle for a point light
//	Downloaded from: www.paulsprojects.net
//	Created:	14th December 2002
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <vector>
#include "../GL files/glee.h"			//header for OpenGL 1.4
#include "../Maths/Maths.h"
#include "../Log/LOG.h"
#include "POINT_LIGHT.h"

void POINT_LIGHT::DrawScissorRectangle()
{
	glColor4fv(color);
	
	glBegin(GL_LINE_LOOP);
	{
		glVertex2f(scissorLeft,					scissorBottom);
		glVertex2f(scissorLeft+scissorWidth,	scissorBottom);
		glVertex2f(scissorLeft+scissorWidth,	scissorBottom+scissorHeight);
		glVertex2f(scissorLeft,					scissorBottom+scissorHeight);
	}
	glEnd();
	
	glColor4fv(white);
}