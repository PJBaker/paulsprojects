//////////////////////////////////////////////////////////////////////////////////////////
//	POINT_LIGHT_Init.cpp
//	Initiate a point light from a file
//	Downloaded from: www.paulsprojects.net
//	Created:	15th February 2003
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <vector>
#include "../GL files/glee.h"			//header for OpenGL 1.4
#include "../Maths/Maths.h"
#include "../Log/LOG.h"
#include "../Render Manager/RENDER_MANAGER.h"
#include "POINT_LIGHT.h"

bool POINT_LIGHT::Init(char * filename)
{
	//Open the file to read in the properties of this light
	FILE * file=fopen(filename, "rt");
	if(!file)
	{
		LOG::Instance()->OutputError("Unable to open %s", filename);
		return false;
	}

	fscanf(file, "Position: (%f, %f, %f) ", &boundingSphere.centre.x,
											&boundingSphere.centre.y,
											&boundingSphere.centre.z);
	
	fscanf(file, "Radius: %f ", &boundingSphere.radius);
	
	fscanf(file, "Color: (%f, %f, %f) ",	&color.r,
											&color.g,
											&color.b);

	//Load in cubemap name
	char cubeMapName[512];

	fscanf(file, "Cube Map: %s", cubeMapName);

	if(strcmp(cubeMapName, "None")==0)
		hasCubeMap=false;
	else
	{
		cubeMapIndex=RENDER_MANAGER::Instance()->CreateTextureCubeMap(cubeMapName);
		if(cubeMapIndex==-1)
			hasCubeMap=false;
		else
			hasCubeMap=true;
	}

	fclose(file);
	
	return true;
}
