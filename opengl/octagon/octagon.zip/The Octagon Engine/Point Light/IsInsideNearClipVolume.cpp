//////////////////////////////////////////////////////////////////////////////////////////
//	Point Light/IsInsideNearClipVolume.cpp
//	Is something inside the near clip volume?
//	Downloaded from: www.paulsprojects.net
//	Created:	1st January 2003
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <vector>
#include "../GL files/glee.h"			//header for OpenGL 1.4
#include "../Maths/Maths.h"
#include "../Log/LOG.h"
#include "../Bounding Volumes/Bounding Volumes.h"
#include "../Camera/WALKING_CAMERA.h"
#include "POINT_LIGHT.h"

bool POINT_LIGHT::IsBoundingBoxInsideNearClipVolume(const AA_BOUNDING_BOX & boundingBox) const
{
	//If the light is on the near plane, return true since this is such a rare case
	if(lightOnNearPlane)
		return true;
	
	//Otherwise, if the box is behind any of the planes, it cannot be in the volume
	for(int i=0; i<6; ++i)
	{
		if(boundingBox.ClassifyByPlane(nearClipVolumePlanes[i])==BOX_BEHIND_PLANE)
			return false;
	}

	return true;
}

bool POINT_LIGHT::IsPolygonInsideNearClipVolume(const PLANE & planeEquation,
												int numVertices,
												VECTOR3D * vertices) const
{
	//If the light is on the near clip plane, return true
	if(lightOnNearPlane)
		return true;

	//Otherwise, if all the vertices are behind any plane, it cannot be in the volume
	for(int i=0; i<6; ++i)
	{
		//If all vertices are behind this plane, return false
		bool allBehind=true;
		
		for(int j=0; j<numVertices; ++j)
		{
			if(nearClipVolumePlanes[i].ClassifyPoint(vertices[j])!=POINT_BEHIND_PLANE)
			{
				allBehind=false;
				break;
			}
		}

		if(allBehind)
			return false;
	}

	return true;
}

