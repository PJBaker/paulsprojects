//////////////////////////////////////////////////////////////////////////////////////////
//	POINT_LIGHT.h
//	Class declaration for point light
//	Downloaded from: www.paulsprojects.net
//	Created:	12th December 2002
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	

#ifndef POINT_LIGHT_H
#define POINT_LIGHT_H

#include "../Bounding Volumes/Bounding Volumes.h"
#include "../Bitset/BITSET.h"
#include "../Camera/WALKING_CAMERA.h"

class POINT_LIGHT
{
public:
	bool Init(char * filename);

	COLOR color;
	
	BOUNDING_SPHERE boundingSphere;

	bool hasCubeMap;	//does this light have a projected cube map?
	int cubeMapIndex;	//the texture index for the cube map

	//Visible bsp faces
	BITSET visibleFaces;

	//Draw the bounding sphere for the light - for occlusion test
	void DrawBoundingSphere();

public:
	//Calculate the scissor rectangle
	void CalculateScissorRectangle(const WALKING_CAMERA & camera);

	//Set the scissor rectangle
	void SetScissor();

	//Draw the scissor rectangle for this light
	void DrawScissorRectangle();

protected:
	//Store the scissor parameters
	//in [-1, 1]x[-1, 1]
	float scissorLeft, scissorWidth;
	//in [0, 2]x[0, 2]
	float scissorBottom, scissorHeight;

public:
	//Calculate the near clip volume (if an entity is in this volume, zfail is required)
	void CalculateNearClipVolume(const WALKING_CAMERA & camera);

	//Is an entity within the volume?
	bool IsBoundingBoxInsideNearClipVolume(const AA_BOUNDING_BOX & boundingBox) const;

	//Is a polygon within the volume?
	bool IsPolygonInsideNearClipVolume(	const PLANE & planeEquation,
										int numVertices,
										VECTOR3D * vertices) const;

protected:
	bool lightOnNearPlane;	//is the light on (or v. near) the near plane?

	PLANE nearClipVolumePlanes[6];
};

#endif