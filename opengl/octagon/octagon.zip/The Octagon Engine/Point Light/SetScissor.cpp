//////////////////////////////////////////////////////////////////////////////////////////
//	Point Light/SetScissor.cpp
//	Set the scissor rectangle for a point light
//	Downloaded from: www.paulsprojects.net
//	Created:	14th December 2002
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <vector>
#include "../GL files/glee.h"			//header for OpenGL 1.4
#include "../Maths/Maths.h"
#include "../Log/LOG.h"
#include "../Window/WINDOW.h"
#include "POINT_LIGHT.h"

void POINT_LIGHT::SetScissor()
{
	int windowWidth=WINDOW::Instance()->width;
	int windowHeight=WINDOW::Instance()->height;

	//convert from [-1, 1]x[-1, 1] to [0, width-1]x[0, height-1]
	int left=	int(windowWidth*(scissorLeft+1.0f)/2);
	int bottom=	int(windowHeight*(scissorBottom+1.0f)/2);
	int width=	int(windowWidth*(scissorWidth)/2);
	int height=	int(windowHeight*(scissorHeight)/2);

	//Clamp these values to the edge of the screen
	if(left<0)
		left=0;
	if(bottom<0)
		bottom=0;

	if(left+width>windowWidth-1)
		width=windowWidth-1-left;

	if(bottom+height>windowHeight-1)
		height=windowHeight-1-bottom;

	glScissor(left, bottom, width, height);
}