//////////////////////////////////////////////////////////////////////////////////////////
//	Point Light/CalculateNearClipVolume.cpp
//	Calculate the near clip volume. If an entity is inside this, zFail shadows are required
//	Downloaded from: www.paulsprojects.net
//	Created:	1st January 2003
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <vector>
#include "../GL files/glee.h"			//header for OpenGL 1.4
#include "../Maths/Maths.h"
#include "../Log/LOG.h"
#include "../Bounding Volumes/Bounding Volumes.h"
#include "../Camera/WALKING_CAMERA.h"
#include "POINT_LIGHT.h"

void POINT_LIGHT::CalculateNearClipVolume(const WALKING_CAMERA & camera)
{
	//Calculate the light's position in eye space
	VECTOR4D eyeSpaceLightPosition=camera.viewMatrix*boundingSphere.centre;

	//Get the signed distance from the light source to the near plane
	float distance=-eyeSpaceLightPosition.z-camera.nearDistance;

	int lightClassification;
	if(distance>EPSILON)
		lightClassification=POINT_IN_FRONT_OF_PLANE;
	else if(distance<-EPSILON)
		lightClassification=POINT_BEHIND_PLANE;
	else
		lightClassification=POINT_ON_PLANE;

	
	//Calculate the vertices of the near clip rectangle (in eye space)
	VECTOR3D nearClipVertices[4];

	float top=camera.nearDistance*tanf(camera.fovy*(float)M_PI/360);
	float bottom=-top;

	float left=camera.aspectRatio*bottom;
	float right=camera.aspectRatio*top;

	nearClipVertices[0].Set(right, top, -camera.nearDistance);
	nearClipVertices[1].Set(left, top, -camera.nearDistance);
	nearClipVertices[2].Set(left, bottom, -camera.nearDistance);
	nearClipVertices[3].Set(right, bottom, -camera.nearDistance);

	//Convert the near clip vertices to world space
	MATRIX4X4 inverseViewMatrix=camera.viewMatrix.GetAffineInverse();
	for(int i=0; i<4; ++i)
		nearClipVertices[i]=inverseViewMatrix*nearClipVertices[i];

	
	//Calculate plane 0 - the near clip plane
	nearClipVolumePlanes[0].SetFromPoints(	nearClipVertices[0],
											nearClipVertices[2],
											nearClipVertices[1]);


	//Calculate the next 4 planes. Include 2 adjacent corners and the light position
	for(int i=0; i<4; ++i)
	{
		nearClipVolumePlanes[i+1].SetFromPoints(nearClipVertices[i],
												nearClipVertices[(i+1)%4],
												boundingSphere.centre);
	}

	//set plane 5 to pass through the light position and have a normal pointing to the centre
	//of the near clip rectangle
	nearClipVolumePlanes[5].normal=((nearClipVertices[0]+nearClipVertices[1]+
									 nearClipVertices[2]+nearClipVertices[3])/4)
									-boundingSphere.centre;
	nearClipVolumePlanes[5].normal.Normalize();
	
	nearClipVolumePlanes[5].CalculateIntercept(boundingSphere.centre);


	//Set a flag if the light is on the near plane
	if(lightClassification==POINT_ON_PLANE)
		lightOnNearPlane=true;
	else
		lightOnNearPlane=false;

	//If the light source is behind the near plane, negate planes 0-4
	if(lightClassification==POINT_BEHIND_PLANE)
	{
		for(int i=0; i<5; ++i)
			nearClipVolumePlanes[i]=-nearClipVolumePlanes[i];
	}
}
