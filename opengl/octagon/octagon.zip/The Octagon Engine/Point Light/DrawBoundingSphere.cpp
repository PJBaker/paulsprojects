//////////////////////////////////////////////////////////////////////////////////////////
//	Point Light/DrawBoundingSphere.cpp
//	Draw the bounding sphere for a point light
//	Downloaded from: www.paulsprojects.net
//	Created:	20th December 2002
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <vector>
#include "../GL files/glee.h"			//header for OpenGL 1.4
#include <GL/glu.h>
#include "../Maths/Maths.h"
#include "../Log/LOG.h"
#include "POINT_LIGHT.h"

void POINT_LIGHT::DrawBoundingSphere()
{
	static GLUquadricObj * sphere=gluNewQuadric();

	glPushMatrix();
	glTranslatef(	boundingSphere.centre.x,
					boundingSphere.centre.y, 
					boundingSphere.centre.z);
	gluSphere(sphere, boundingSphere.radius, 12, 12);
	glPopMatrix();
}