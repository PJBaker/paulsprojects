//////////////////////////////////////////////////////////////////////////////////////////
//	PATH_Init.cpp
//	Initiate a path
//	Downloaded from: www.paulsprojects.net
//	Created:	11th February 2003
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <vector>
#include "../GL files/glee.h"
#include "../Maths/Maths.h"
#include "../Log/LOG.h"
#include "PATH.h"

bool PATH::Init(char * pathFilename, const VECTOR3D & position, float angleYaw)
{
	FILE * file=fopen(pathFilename, "rt");
	if(!file)
	{
		LOG::Instance()->OutputError("Unable to open %s", pathFilename);
		return false;
	}

	//Read in the number of control points
	fscanf(file, " %d ", &numControlPoints);

	//Create space for the control points
	controlPoints=new PATH_CONTROL_POINT[numControlPoints];
	if(!controlPoints)
	{
		LOG::Instance()->OutputError("Unable to allocate space for path control points");
		return false;
	}

	//Loop through and read in the control points
	for(int i=0; i<numControlPoints; ++i)
	{
		fscanf(file, " ( %f , %f , %f ) ",	&controlPoints[i].position.x,
											&controlPoints[i].position.y,
											&controlPoints[i].position.z);
		fscanf(file, " %f ", &controlPoints[i].angleYaw);
		fscanf(file, " %f ", &controlPoints[i].distance);		
	}
	
	fclose(file);

	//Scale and bias distance to within [0, 1]
	for(int i=0; i<numControlPoints; ++i)
		controlPoints[i].distance-=controlPoints[0].distance;

	for(int i=0; i<numControlPoints; ++i)
		controlPoints[i].distance/=controlPoints[numControlPoints-1].distance;	

	//Convert positions and angles based on the offsets
	for(int i=0; i<numControlPoints; ++i)
	{
		controlPoints[i].position=controlPoints[i].position.GetRotatedY(angleYaw)+position;
		controlPoints[i].angleYaw+=angleYaw;
	}
	
	return true;
}
