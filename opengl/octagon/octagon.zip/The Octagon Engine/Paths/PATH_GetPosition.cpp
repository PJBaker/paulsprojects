//////////////////////////////////////////////////////////////////////////////////////////
//	PATH_GetPosition.cpp
//	Get position on a path
//	Downloaded from: www.paulsprojects.net
//	Created:	11th February 2003
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <vector>
#include "../GL files/glee.h"
#include "../Maths/Maths.h"
#include "../Log/LOG.h"
#include "PATH.h"

void PATH::GetCurrentPosition(float distance, VECTOR3D & positionResult, float & angleYawResult)
{
	//Check distance is in [0, 1]
	while(distance<0.0f)
		distance+=1.0f;
	while(distance>1.0f)
		distance-=1.0f;

	//Find the 2 control points to lerp between
	PATH_CONTROL_POINT * p1=NULL;
	PATH_CONTROL_POINT * p2=NULL;

	for(int i=1; i<numControlPoints; ++i)
	{
		if(controlPoints[i].distance>distance)
		{
			p1=&controlPoints[i-1];
			p2=&controlPoints[i];
			break;
		}
	}

	//check we got 2 points
	if(p1==NULL)
		return;

	//Calculate the interpolation factor
	float factor=(distance-p1->distance)/(p2->distance-p1->distance);

	//Fill in the results
	positionResult=p1->position.lerp(p2->position, factor);
	angleYawResult=(1.0f-factor)*p1->angleYaw + factor*p2->angleYaw;
}