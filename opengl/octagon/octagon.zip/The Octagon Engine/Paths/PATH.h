//////////////////////////////////////////////////////////////////////////////////////////
//	PATH.h
//	The path followed by an entity
//	Downloaded from: www.paulsprojects.net
//	Created:	11th February 2003
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	

#ifndef PATH_H
#define PATH_H

class PATH_CONTROL_POINT
{
public:
	VECTOR3D position;
	float angleYaw;

	float distance;	//the distance along the path in [0, 1]
};

class PATH
{
public:
	void GetCurrentPosition(float distance, VECTOR3D & positionResult, float & angleYawResult);
																			//distance <- [0, 1]
	
	bool Init(char * pathFilename, const VECTOR3D & position, float angleYaw);

protected:
	int numControlPoints;
	PATH_CONTROL_POINT * controlPoints;

public:
	PATH()	:	controlPoints(NULL)
	{}
	~PATH()
	{
		if(controlPoints)
			delete [] controlPoints;
		controlPoints=NULL;
	}
};

#endif	//PATH_H

