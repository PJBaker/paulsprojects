//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Resolution.rc
//
#define IDD_RESOLUTION                  101
#define IDC_FULLSCREEN                  1000
#define IDC_640                         1001
#define IDC_800                         1002
#define IDC_1024                        1003
#define IDC_NOAA                        1005
#define IDC_2AA                         1006
#define IDC_3AA                         1007
#define IDC_4AA                         1008
#define IDC_5AA                         1009
#define IDC_6AA                         1010
#define IDC_7AA                         1011
#define IDC_8AA                         1012
#define IDC_9AA                         1013
#define IDC_10AA                        1014
#define IDC_11AA                        1015
#define IDC_12AA                        1016
#define IDC_13AA                        1017
#define IDC_14AA                        1018
#define IDC_15AA                        1019
#define IDC_16AA                        1020
#define IDC_ANTIALIAS                   -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1009
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
