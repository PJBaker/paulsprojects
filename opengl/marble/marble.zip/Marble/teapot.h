//////////////////////////////////////////////////////////////////////////////////////////
//	Teapot.h
//	Draw Teapot
//	Downloaded from: www.paulsprojects.net
//	Created:	25th August 2003
//
//	Copyright (c) 2006, Paul Baker
//	Distributed under the New BSD Licence. (See accompanying file License.txt or copy at
//	http://www.paulsprojects.net/NewBSDLicense.txt)
//////////////////////////////////////////////////////////////////////////////////////////	

#ifndef TEAPOT_H
#define TEAPOT_H

void Teapot(GLint grid, GLenum type);

#endif