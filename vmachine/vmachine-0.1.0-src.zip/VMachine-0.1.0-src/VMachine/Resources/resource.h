//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by VMachine.rc
//
#define IDR_MAINMENU                    101
#define IDR_BIOS                        102
#define IDR_VGABIOS                     103
#define IDR_HELPER                      104
#define IDR_BINARITHINSTR               105
#define IDR_BITBYTEINSTR                106
#define IDR_DATATRANSFERINSTR           107
#define IDR_DECARITHINSTR               108
#define IDR_FLAGCONTROLINSTR            109
#define IDR_FPUINSTR                    110
#define IDR_MISCINSTR                   111
#define IDR_NEARCONTROLINSTR            112
#define IDR_SEGREGINSTR                 113
#define IDR_SHIFTINSTR                  114
#define IDR_STRINGINSTR                 115
#define ID_FILE_EXIT                    40001
#define ID_FLOPPY_INSERT                40002
#define ID_FLOPPY_EJECT                 40003
#define ID_HELP_ABOUTVMACHINE           40004

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        116
#define _APS_NEXT_COMMAND_VALUE         40005
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
