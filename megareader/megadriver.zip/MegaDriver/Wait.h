//Wait.h
//Function to wait for a given number of microseconds

#ifndef WAIT_H
#define WAIT_H

void Wait(Dword numMicroseconds);

#endif