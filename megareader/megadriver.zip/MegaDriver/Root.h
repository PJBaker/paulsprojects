//Root.h
//Header file containing most basic definitions

#ifndef ROOT_H
#define ROOT_H

typedef unsigned char Byte;
typedef unsigned short Word;
typedef unsigned long Dword;
typedef unsigned __int64 Qword;

#endif