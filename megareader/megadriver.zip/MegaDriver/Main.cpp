//MegaRead
//Dump a cartridge to a file using the MegaReader

#define WIN32_LEAN_AND_MEAN
#include <windows.h>

#include <iostream>
#include <fstream>
#include <string>
#include <vector>

using namespace std;

#include "winio.h"
#pragma comment(lib, "winio.lib")

#include "Root.h"
#include "Wait.h"

int main()
{
	//Initialise the WinIo library
	if(!InitializeWinIo())
	{
		cout << "Unable to initialise WinIo library" << endl;
		return 0;
	}

	//Get the filename to save the data as
	string filename;
	cout << "Filename: ";
	getline(cin, filename);

	//Buffer for data
	vector <Word> data;

	//Initialise the MegaReader
	//Set control signals:
	//Direction	= 1 (read)
	//IRQ Enable= 0
	//~P17		= 1 (read upper byte of word)
	//P16		= 0 (unused)
	//~P14		= 1 (4040 resets = 0)
	//~P1		= 1 (4040 clock = 0)
	SetPortVal(0x37A, 0x2B, 1);
	Wait(1);

	//Reset the counters by pulsing P14
	SetPortVal(0x37A, 0x29, 1);
	Wait(1);
	SetPortVal(0x37A, 0x2B, 1);
	Wait(1);

	//Read in the data (in 64K blocks)
	for(Word block=0; block<0x40; ++block)
	{
		//Data for this block
		vector <Word> blockData;

		for(Word word=0; word<0x8000; ++word)
		{
			//Read the upper byte of the current word
			Dword upperByte;
			GetPortVal(0x378, &upperByte, 1);

			//Assert P17 (read lower byte)
			SetPortVal(0x37A, 0x23, 1);
			Wait(1);

			//Read the lower byte of the current word
			Dword lowerByte;
			GetPortVal(0x378, &lowerByte, 1);

			//Deassert P17
			SetPortVal(0x37A, 0x2B, 1);
			Wait(1);

			//Add this word to the block buffer
			blockData.push_back(static_cast<Word>(((upperByte & 0xFF) << 8) | (lowerByte & 0xFF)));

			//Increment the counters by pulsing P1
			SetPortVal(0x37A, 0x2A, 1);
			Wait(1);
			SetPortVal(0x37A, 0x2B, 1);
			Wait(1);
		}

		//If this is not the first block, but the data is the same as that from the first block,
		//then finished
		if(block!=0)
		{
			bool blockMatch=true;
		
			for(size_t i=0; i<blockData.size(); ++i)
			{
				if(blockData[i]!=data[i])
				{
					blockMatch=false;
					break;
				}
			}

			if(blockMatch)
				break;
		}

		//Otherwise, add the data to the buffer
		for(vector<Word>::const_iterator i=blockData.begin(); i!=blockData.end(); ++i)
			data.push_back(*i);

		//Print a progress report
		cout << (block+1)*64 << "K" << endl;
	}

    //Open the file
	ofstream file(filename.c_str(), ios::binary | ios::out);
	if(!file)
	{
		cout << "Unable to open " << filename << endl;
		return 0;
	}

	//Output the date
	file.write(reinterpret_cast<char *>(&data[0]), static_cast<streamsize>(data.size()*2));

	//Close the file
	file.close();

	//Shutdown the WinIo library
	ShutdownWinIo();

	return 0;
}