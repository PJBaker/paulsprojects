//Wait.cpp
//Function to wait for a given number of microseconds

#define WIN32_LEAN_AND_MEAN
#include <windows.h>

#include "Root.h"
#include "Wait.h"

void Wait(Dword numMicroseconds)
{
	static LONGLONG countsPerMicrosecond=0;

	//If this is the first call to Wait, calculate countsPerMicrosecond
	if(countsPerMicrosecond==0)
	{
		LARGE_INTEGER performanceFrequency;
		QueryPerformanceFrequency(&performanceFrequency);

		countsPerMicrosecond=performanceFrequency.QuadPart/1000000;

		//Round the division up
		++countsPerMicrosecond;
	}

	//Get the current value of the counter
	LARGE_INTEGER startCounterValue;
	QueryPerformanceCounter(&startCounterValue);

	//Wait until the counter reaches startCounterValue+numMicroseconds*countsPerMicrosecond
	LARGE_INTEGER currentCounterValue;

	do
	{
		QueryPerformanceCounter(&currentCounterValue);
	}
	while(currentCounterValue.QuadPart < startCounterValue.QuadPart +
											numMicroseconds*countsPerMicrosecond);
}